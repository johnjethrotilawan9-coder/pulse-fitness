import { useEffect, type ReactNode } from 'react';
import { RouterProvider, matchPath, useRouter } from './router';
import { AuthProvider, useAuth } from './hooks/useAuth';
import { DataProvider, useData } from './hooks/useData';
import { ToastProvider } from './hooks/useToast';
import { useTheme } from './hooks/useTheme';
import { ConfirmProvider } from './components/ui/Confirm';
import { AppShell } from './components/layout/AppShell';
import { Spinner, EmptyState } from './components/ui/Misc';
import { Button } from './components/ui/Button';
import { isConfigured } from './services/supabase';
import LoginPage from './pages/Login';
import SetupPage from './pages/Setup';
import Dashboard from './pages/Dashboard';
import WorkoutsPage from './pages/Workouts';
import WorkoutDetailPage from './pages/WorkoutDetail';
import WorkoutEditPage from './pages/WorkoutEdit';
import LiveWorkoutPage from './pages/LiveWorkout';
import CalendarPage from './pages/Calendar';
import RunPage from './pages/Run';
import ExercisesPage from './pages/Exercises';
import ProgramsPage from './pages/Programs';
import NutritionPage from './pages/Nutrition';
import MealPlannerPage from './pages/MealPlanner';
import WaterPage from './pages/Water';
import HabitsPage from './pages/Habits';
import ProgressPage from './pages/Progress';
import StatsPage from './pages/Stats';
import RecordsPage from './pages/Records';
import TimersPage from './pages/Timers';
import SettingsPage from './pages/Settings';
import MorePage from './pages/More';

type Page = (p: Record<string, string>) => ReactNode;

const ROUTES: [string, Page][] = [
  ['/', () => <Dashboard />],
  ['/workouts', () => <WorkoutsPage />],
  ['/workouts/new', () => <WorkoutEditPage />],
  ['/workouts/:id', (p) => <WorkoutDetailPage id={p.id} />],
  ['/workouts/:id/edit', (p) => <WorkoutEditPage id={p.id} />],
  ['/calendar', () => <CalendarPage />],
  ['/run', () => <RunPage />],
  ['/exercises', () => <ExercisesPage />],
  ['/programs', () => <ProgramsPage />],
  ['/nutrition', () => <NutritionPage />],
  ['/meals', () => <MealPlannerPage />],
  ['/water', () => <WaterPage />],
  ['/habits', () => <HabitsPage />],
  ['/progress', () => <ProgressPage />],
  ['/stats', () => <StatsPage />],
  ['/records', () => <RecordsPage />],
  ['/timers', () => <TimersPage />],
  ['/settings', () => <SettingsPage />],
  ['/more', () => <MorePage />],
];

function NotFound() {
  const { navigate } = useRouter();
  return <EmptyState icon="info" title="Page not found" message="That page doesn't exist." action={<Button variant="primary" onClick={() => navigate('/')}>Go to dashboard</Button>} />;
}

function Redirect({ to }: { to: string }) {
  const { navigate } = useRouter();
  useEffect(() => navigate(to, { replace: true }), [navigate, to]);
  return null;
}

function Routes() {
  const { path } = useRouter();
  const { loaded, loadError, refresh, profile } = useData();
  useTheme(profile?.theme);

  if (!loaded) {
    if (loadError)
      return (
        <div className="auth">
          <EmptyState icon="wifiOff" title="Couldn't load your data" message={loadError} action={<Button variant="primary" icon="refresh" onClick={() => void refresh()}>Try again</Button>} />
        </div>
      );
    return <Spinner label="Loading your data" />;
  }

  if (path === '/login') return <Redirect to="/" />;

  // Live workout mode is full-screen (no navigation chrome)
  const live = matchPath('/live/:id', path);
  if (live) return <LiveWorkoutPage id={live.id} />;

  for (const [pattern, render] of ROUTES) {
    const params = matchPath(pattern, path);
    if (params) return <AppShell>{render(params)}</AppShell>;
  }
  return (
    <AppShell>
      <NotFound />
    </AppShell>
  );
}

function Gate() {
  const { user, loading, recovering } = useAuth();
  useTheme(undefined);
  if (!isConfigured) return <SetupPage />;
  if (loading) return <Spinner label="Checking your session" />;
  if (!user || recovering) return <LoginPage />;
  return (
    <DataProvider>
      <Routes />
    </DataProvider>
  );
}

export default function App() {
  return (
    <RouterProvider>
      <ToastProvider>
        <ConfirmProvider>
          <AuthProvider>
            <Gate />
          </AuthProvider>
        </ConfirmProvider>
      </ToastProvider>
    </RouterProvider>
  );
}
