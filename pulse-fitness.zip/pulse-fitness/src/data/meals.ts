import type { PlanMealType } from '../types';
import type { MealFocus } from './goals';

export interface MealIdea {
  title: string;
  description: string;
  slot: PlanMealType;
  focus: MealFocus[];
  calories: number;
  protein_g: number;
  carbs_g: number;
  fat_g: number;
  filipino?: boolean;
}

const ALL: MealFocus[] = ['weight_loss', 'muscle', 'general', 'high_protein', 'balanced'];

// Approximate values for typical home portions — use as a guide, not exact figures.
export const MEAL_IDEAS: MealIdea[] = [
  // Breakfast
  { slot: 'breakfast', title: 'Oatmeal with banana & peanut butter', description: '½ cup oats cooked in milk or water, 1 sliced banana, 1 tbsp peanut butter.', focus: ['general', 'balanced', 'muscle'], calories: 420, protein_g: 14, carbs_g: 62, fat_g: 13, filipino: true },
  { slot: 'breakfast', title: 'Tortang talong with egg whites + ½ cup rice', description: 'Eggplant omelette made with 1 egg + 2 egg whites, cooked in a little oil, with half a cup of rice and tomatoes.', focus: ['weight_loss', 'high_protein', 'balanced'], calories: 330, protein_g: 20, carbs_g: 34, fat_g: 11, filipino: true },
  { slot: 'breakfast', title: 'Tapsilog, lighter version', description: 'Lean beef tapa (100 g) pan-seared, 1 fried egg in minimal oil, ¾ cup garlic rice or plain rice, sliced tomato.', focus: ['muscle', 'high_protein'], calories: 560, protein_g: 36, carbs_g: 52, fat_g: 20, filipino: true },
  { slot: 'breakfast', title: 'Greek yogurt bowl', description: '1 cup Greek yogurt, papaya or mango cubes, a spoon of oats and a few nuts.', focus: ['weight_loss', 'high_protein', 'general'], calories: 310, protein_g: 24, carbs_g: 34, fat_g: 8 },
  { slot: 'breakfast', title: 'Scrambled eggs on whole-grain toast', description: '2–3 eggs scrambled with tomatoes and onions, 2 slices whole-grain bread (pandesal works too).', focus: ['general', 'balanced', 'muscle'], calories: 430, protein_g: 24, carbs_g: 32, fat_g: 22, filipino: true },
  { slot: 'breakfast', title: 'Boiled kamote + 2 boiled eggs', description: 'A medium boiled sweet potato with two hard-boiled eggs and a cup of black coffee or tea.', focus: ['weight_loss', 'general', 'balanced'], calories: 290, protein_g: 14, carbs_g: 30, fat_g: 10, filipino: true },
  { slot: 'breakfast', title: 'Champorado made lighter', description: 'Oat-based champorado with cocoa, sweetened lightly, topped with milk; add a boiled egg for protein.', focus: ['general'], calories: 360, protein_g: 14, carbs_g: 55, fat_g: 9, filipino: true },
  { slot: 'breakfast', title: 'Protein smoothie', description: 'Milk, banana, oats, a scoop of protein powder (optional) or ½ cup yogurt, blended with ice.', focus: ['muscle', 'high_protein'], calories: 450, protein_g: 32, carbs_g: 58, fat_g: 9 },

  // Lunch
  { slot: 'lunch', title: 'Inihaw na bangus + ensaladang talong', description: 'Grilled milkfish (150 g), eggplant-tomato-onion salad, 1 cup rice.', focus: ['general', 'balanced', 'muscle'], calories: 560, protein_g: 36, carbs_g: 55, fat_g: 20, filipino: true },
  { slot: 'lunch', title: 'Chicken tinola', description: 'Chicken breast or skinless thigh simmered with ginger, sayote/papaya and malunggay; ¾ cup rice.', focus: ['weight_loss', 'general', 'balanced', 'high_protein'], calories: 430, protein_g: 35, carbs_g: 42, fat_g: 11, filipino: true },
  { slot: 'lunch', title: 'Ginisang monggo with fish', description: 'Mung bean stew with malunggay/ampalaya leaves and a piece of fried or grilled fish; ¾ cup rice.', focus: ['general', 'balanced', 'high_protein'], calories: 520, protein_g: 32, carbs_g: 62, fat_g: 14, filipino: true },
  { slot: 'lunch', title: 'Chicken adobo (lean) + vegetables', description: 'Skinless chicken adobo with less oil, a side of steamed kangkong or pechay, 1 cup rice.', focus: ['muscle', 'general'], calories: 580, protein_g: 40, carbs_g: 58, fat_g: 18, filipino: true },
  { slot: 'lunch', title: 'Tuna rice bowl', description: 'Canned tuna in water (1 can), cucumber, tomato, egg, a little soy-calamansi dressing over ¾ cup rice.', focus: ['weight_loss', 'high_protein', 'balanced'], calories: 440, protein_g: 38, carbs_g: 46, fat_g: 10, filipino: true },
  { slot: 'lunch', title: 'Grilled chicken salad wrap', description: 'Grilled chicken breast, lettuce, tomato and yogurt dressing in a whole-wheat wrap.', focus: ['weight_loss', 'high_protein'], calories: 410, protein_g: 38, carbs_g: 36, fat_g: 12 },
  { slot: 'lunch', title: 'Lean beef & vegetable stir-fry', description: 'Thin-sliced lean beef with broccoli, carrots and bell pepper; 1 cup rice.', focus: ['muscle', 'high_protein'], calories: 620, protein_g: 42, carbs_g: 64, fat_g: 18 },
  { slot: 'lunch', title: 'Tofu & vegetable stir-fry', description: 'Firm tofu with mixed vegetables in garlic-soy sauce; ¾ cup rice.', focus: ['weight_loss', 'general', 'balanced'], calories: 430, protein_g: 22, carbs_g: 50, fat_g: 15, filipino: true },

  // Dinner
  { slot: 'dinner', title: 'Pinakbet with grilled tilapia', description: 'Pinakbet-style vegetables (squash, okra, eggplant, ampalaya, sitaw) with little bagoong, grilled tilapia, ½–¾ cup rice.', focus: ['weight_loss', 'general', 'balanced'], calories: 450, protein_g: 34, carbs_g: 44, fat_g: 14, filipino: true },
  { slot: 'dinner', title: 'Sinigang na isda or hipon', description: 'Tamarind soup with fish or shrimp, kangkong, radish, sitaw and tomato; ½–¾ cup rice.', focus: ['weight_loss', 'general', 'balanced', 'high_protein'], calories: 380, protein_g: 32, carbs_g: 40, fat_g: 8, filipino: true },
  { slot: 'dinner', title: 'Lean pork & vegetable nilaga', description: 'Lean pork (trimmed), cabbage, pechay, corn and potato in clear broth; ¾ cup rice.', focus: ['general', 'muscle'], calories: 540, protein_g: 36, carbs_g: 55, fat_g: 17, filipino: true },
  { slot: 'dinner', title: 'Baked salmon, potatoes & greens', description: 'Salmon fillet, roasted potatoes and a large side of green vegetables.', focus: ['muscle', 'general', 'balanced'], calories: 600, protein_g: 38, carbs_g: 45, fat_g: 28 },
  { slot: 'dinner', title: 'Chicken breast, kamote & broccoli', description: 'Grilled or air-fried chicken breast (150 g), a medium sweet potato and steamed broccoli.', focus: ['weight_loss', 'muscle', 'high_protein'], calories: 480, protein_g: 46, carbs_g: 48, fat_g: 9, filipino: true },
  { slot: 'dinner', title: 'Tokwa\'t gulay with egg', description: 'Pan-fried tofu with sautéed chopsuey vegetables and a boiled egg; ½ cup rice.', focus: ['weight_loss', 'balanced'], calories: 410, protein_g: 26, carbs_g: 38, fat_g: 17, filipino: true },
  { slot: 'dinner', title: 'Beef & bean chili bowl', description: 'Lean ground beef with beans, tomatoes and spices, topped with yogurt; 1 cup rice or bread.', focus: ['muscle', 'high_protein'], calories: 650, protein_g: 45, carbs_g: 68, fat_g: 18 },

  // Snacks
  { slot: 'snack', title: 'Banana + a handful of peanuts', description: 'Quick energy before or after training.', focus: ALL, calories: 260, protein_g: 8, carbs_g: 30, fat_g: 13, filipino: true },
  { slot: 'snack', title: 'Boiled eggs', description: '2 hard-boiled eggs with a pinch of salt.', focus: ['weight_loss', 'high_protein', 'muscle'], calories: 150, protein_g: 12, carbs_g: 1, fat_g: 10 },
  { slot: 'snack', title: 'Greek yogurt with fruit', description: '¾ cup Greek yogurt with papaya or berries.', focus: ['weight_loss', 'high_protein', 'general'], calories: 170, protein_g: 15, carbs_g: 20, fat_g: 3 },
  { slot: 'snack', title: 'Nilagang mais or kamote', description: 'A boiled corn on the cob or small sweet potato.', focus: ['general', 'balanced'], calories: 150, protein_g: 4, carbs_g: 32, fat_g: 2, filipino: true },
  { slot: 'snack', title: 'Tuna on crackers', description: '½ can tuna in water on whole-grain crackers or pandesal.', focus: ['high_protein', 'muscle'], calories: 230, protein_g: 20, carbs_g: 22, fat_g: 6, filipino: true },
  { slot: 'snack', title: 'Glass of milk + fruit', description: 'Low-fat milk with an apple, banana or a slice of papaya.', focus: ['general', 'muscle', 'balanced'], calories: 200, protein_g: 9, carbs_g: 32, fat_g: 4 },
  { slot: 'snack', title: 'Fresh fruit cup', description: 'Papaya, pineapple, watermelon or mango — a cup of whatever is in season.', focus: ['weight_loss', 'general', 'balanced'], calories: 100, protein_g: 1, carbs_g: 25, fat_g: 0, filipino: true },
  { slot: 'snack', title: 'Protein shake', description: 'One scoop protein powder in milk or water after training (optional).', focus: ['muscle', 'high_protein'], calories: 180, protein_g: 25, carbs_g: 8, fat_g: 4 },
];

export const MEAL_FOCUS_LABEL: Record<MealFocus, string> = {
  weight_loss: 'Weight loss',
  muscle: 'Muscle building',
  general: 'General fitness',
  high_protein: 'High protein',
  balanced: 'Balanced diet',
};

export const NUTRITION_TIPS: Record<MealFocus, string[]> = {
  weight_loss: [
    'Use the plate method: ½ vegetables, ¼ protein, ¼ rice or other carbs.',
    'Rice portion guide: about ½–¾ cup cooked rice per meal (roughly a fist).',
    'Choose grilled, steamed, boiled or soup-based dishes (inihaw, sinigang, tinola, nilaga) more often than deep-fried.',
    'Aim for a modest deficit — lose weight gradually rather than skipping meals.',
    'Swap sugary drinks for water or unsweetened tea/coffee.',
  ],
  muscle: [
    'Include a palm-sized serving of protein at every meal (chicken, fish, eggs, tofu, lean pork or beef).',
    'Rice portion guide: 1–1½ cups cooked rice per meal to fuel training.',
    'Eat a carb + protein meal or snack within a few hours after training.',
    'Spread protein across 3–5 meals rather than one big meal.',
  ],
  general: [
    'Build meals around whole foods: rice or kamote, a protein, and lots of vegetables.',
    'Rice portion guide: about ¾–1 cup cooked rice per meal.',
    'Eat fruit daily — banana, papaya, mango and pineapple are easy local options.',
    'Home-cooked meals make it easier to control oil, salt and sugar.',
  ],
  high_protein: [
    'Prioritise eggs, fish (tilapia, bangus, tuna), chicken, tofu, Greek yogurt and mongo.',
    'Keep quick protein snacks ready: boiled eggs, canned tuna, milk.',
    'Rice portion guide: ¾ cup cooked rice per meal, more on training days.',
  ],
  balanced: [
    'Mix carbs, protein and healthy fats at each meal.',
    'Rice portion guide: about ¾–1 cup cooked rice per meal.',
    'Include vegetables at lunch and dinner — pinakbet, chopsuey, ginisang gulay.',
    'Healthy fats: nuts, avocado, fish, a little cooking oil.',
  ],
};

export const MEAL_DISCLAIMER =
  'These are general healthy-eating suggestions, not medical or dietetic advice. If you have a medical condition, allergies or specific needs, check with a qualified professional.';
