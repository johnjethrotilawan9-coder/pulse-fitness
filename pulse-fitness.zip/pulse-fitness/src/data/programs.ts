import type { ProgramDay, ProgramExercise, WorkoutProgram } from '../types';
import { EXERCISE_BY_KEY } from './exercises';

type E = [key: string, sets: number, reps: string, rest?: number];

function day(name: string, focus: string, type: string, list: E[] = []): ProgramDay {
  return {
    name,
    focus,
    type,
    exercises: list.map(([key, sets, reps, rest]): ProgramExercise => {
      const ex = EXERCISE_BY_KEY[key];
      return { exercise_key: key, name: ex?.name ?? key, muscle_group: ex?.muscle_group ?? null, sets, reps, rest_seconds: rest ?? ex?.rest_seconds ?? 60 };
    }),
  };
}
const rest = (n = 'Rest & recovery') => day(n, 'Rest, walk or gentle stretching', 'rest');

function program(id: string, name: string, goal: string, level: string, description: string, days: ProgramDay[]): WorkoutProgram {
  return {
    id: `builtin:${id}`,
    name,
    goal,
    level,
    description,
    days_per_week: days.filter((d) => d.type !== 'rest').length,
    days,
    builtin: true,
  };
}

const push = day('Push Day', 'Chest, shoulders, triceps', 'strength', [
  ['bench-press', 4, '6–8', 120],
  ['incline-db-press', 3, '8–12'],
  ['db-shoulder-press', 3, '8–12'],
  ['lateral-raise', 3, '12–15'],
  ['tricep-pushdown', 3, '10–15'],
  ['overhead-tricep-ext', 2, '10–12'],
]);
const pull = day('Pull Day', 'Back, biceps, rear delts', 'strength', [
  ['pull-up', 3, '5–10', 120],
  ['barbell-row', 4, '6–10', 120],
  ['lat-pulldown', 3, '10–12'],
  ['face-pull', 3, '12–15'],
  ['db-curl', 3, '10–12'],
  ['hammer-curl', 2, '10–12'],
]);
const legs = day('Leg Day', 'Quads, hamstrings, glutes, calves', 'strength', [
  ['back-squat', 4, '5–8', 150],
  ['romanian-deadlift', 3, '8–10', 120],
  ['leg-press', 3, '10–12'],
  ['leg-curl', 3, '10–12'],
  ['hip-thrust', 3, '8–12'],
  ['calf-raise', 4, '12–15'],
]);
const upper = day('Upper Body', 'Chest, back, shoulders, arms', 'strength', [
  ['bench-press', 4, '6–8', 120],
  ['barbell-row', 4, '6–10', 120],
  ['db-shoulder-press', 3, '8–12'],
  ['lat-pulldown', 3, '10–12'],
  ['db-curl', 2, '10–12'],
  ['tricep-pushdown', 2, '10–15'],
]);
const lower = day('Lower Body', 'Quads, hamstrings, glutes, core', 'strength', [
  ['back-squat', 4, '6–8', 150],
  ['romanian-deadlift', 3, '8–10', 120],
  ['walking-lunge', 3, '10 each'],
  ['leg-curl', 3, '10–12'],
  ['calf-raise', 3, '15'],
  ['plank', 3, '45 s'],
]);

export const BUILTIN_PROGRAMS: WorkoutProgram[] = [
  program('beginner-full-body', 'Beginner Full Body', 'Become Physically Fit', 'Beginner',
    'Three full-body sessions a week to learn the main movement patterns and build a base of strength.', [
      day('Full Body A', 'Squat, push, pull', 'strength', [['kb-goblet-squat', 3, '10–12'], ['db-bench-press', 3, '8–12'], ['db-row', 3, '10 each'], ['glute-bridge', 3, '12–15'], ['plank', 3, '30 s']]),
      rest(),
      day('Full Body B', 'Hinge, press, pull', 'strength', [['db-rdl', 3, '10–12'], ['db-shoulder-press', 3, '8–12'], ['lat-pulldown', 3, '10–12'], ['step-up', 3, '10 each'], ['dead-bug', 3, '8 each']]),
      rest(),
      day('Full Body C', 'Legs, push, core', 'strength', [['leg-press', 3, '10–12'], ['push-up', 3, '8–15'], ['seated-cable-row', 3, '10–12'], ['walking-lunge', 2, '10 each'], ['side-plank', 2, '30 s each']]),
      rest(),
      rest('Active recovery'),
    ]),
  program('fat-loss', 'Fat Loss Program', 'Lose Weight', 'Beginner',
    'Strength training to keep muscle, plus cardio and daily walking to raise energy expenditure. Pair with a moderate calorie deficit.', [
      day('Strength Circuit A', 'Full body circuit', 'circuit', [['kb-goblet-squat', 3, '12'], ['push-up', 3, '10–15'], ['db-row', 3, '12 each'], ['kb-swing', 3, '15'], ['mountain-climber', 3, '30 s']]),
      day('Cardio', 'Zone 2 run or brisk walk', 'cardio', [['easy-run', 1, '30 min']]),
      day('Strength Circuit B', 'Full body circuit', 'circuit', [['db-rdl', 3, '12'], ['db-shoulder-press', 3, '10–12'], ['walking-lunge', 3, '10 each'], ['inverted-row', 3, '10'], ['plank', 3, '45 s']]),
      day('Intervals', 'Run intervals', 'hiit', [['intervals', 6, '1 min hard / 2 min easy']]),
      day('Strength Circuit C', 'Full body + core', 'circuit', [['thruster', 3, '10'], ['step-up', 3, '10 each'], ['band-row', 3, '15'], ['burpee', 3, '10'], ['bicycle-crunch', 3, '20']]),
      day('Long Walk', '45–60 min walk', 'cardio', [['brisk-walk', 1, '45–60 min']]),
      rest(),
    ]),
  program('muscle-building', 'Muscle Building Program', 'Build Muscle', 'Intermediate',
    'Four-day upper/lower hypertrophy block. Add a little weight or a rep each week (progressive overload).', [
      upper, lower, rest(),
      day('Upper Body (Volume)', 'Chest, back, shoulders, arms', 'strength', [['incline-db-press', 4, '8–12'], ['seated-cable-row', 4, '10–12'], ['arnold-press', 3, '10–12'], ['db-fly', 3, '12–15'], ['barbell-curl', 3, '10–12'], ['skull-crusher', 3, '10–12']]),
      day('Lower Body (Volume)', 'Glutes, hamstrings, quads', 'strength', [['hip-thrust', 4, '10–12'], ['bulgarian-split-squat', 3, '8–10 each'], ['leg-extension', 3, '12–15'], ['leg-curl', 3, '12–15'], ['seated-calf-raise', 4, '12–15']]),
      rest(), rest(),
    ]),
  program('abs-core', 'Abs & Core Program', 'Build Abs', 'Beginner',
    'Three short core sessions a week. Visible abs also depend on overall body fat, so combine with regular training and good nutrition.', [
      day('Core A', 'Anti-extension & abs', 'core', [['plank', 3, '45 s'], ['dead-bug', 3, '10 each'], ['reverse-crunch', 3, '12'], ['bicycle-crunch', 3, '20']]),
      rest(),
      day('Core B', 'Obliques & rotation', 'core', [['side-plank', 3, '30 s each'], ['russian-twist', 3, '20'], ['pallof-press', 3, '10 each'], ['mountain-climber', 3, '30 s']]),
      rest(),
      day('Core C', 'Strength & control', 'core', [['hanging-knee-raise', 3, '10–12'], ['hollow-hold', 3, '30 s'], ['bird-dog', 3, '10 each'], ['leg-raise', 3, '10–12']]),
      rest(), rest(),
    ]),
  program('home-workout', 'Home Workout Program', 'General Health', 'Beginner',
    'Dumbbells, a band and your bodyweight — three strength days and two cardio days at home.', [
      day('Home Upper', 'Push & pull', 'strength', [['push-up', 3, '8–15'], ['db-row', 3, '10 each'], ['db-shoulder-press', 3, '10–12'], ['band-row', 3, '15'], ['db-curl', 2, '12'], ['tricep-dip-bench', 2, '12']]),
      day('Home Cardio', 'Jump rope & bodyweight', 'hiit', [['jump-rope', 5, '60 s'], ['high-knees', 3, '30 s'], ['jumping-jack', 3, '45 s']]),
      day('Home Lower', 'Legs & glutes', 'strength', [['kb-goblet-squat', 3, '12'], ['db-rdl', 3, '12'], ['bulgarian-split-squat', 3, '8 each'], ['glute-bridge', 3, '15'], ['calf-raise', 3, '20']]),
      rest(),
      day('Home Full Body', 'Full body & core', 'circuit', [['thruster', 3, '10'], ['inverted-row', 3, '10'], ['walking-lunge', 3, '10 each'], ['plank', 3, '45 s'], ['russian-twist', 3, '20']]),
      day('Walk / Jog', '30–45 min easy', 'cardio', [['brisk-walk', 1, '30–45 min']]),
      rest(),
    ]),
  program('no-equipment', 'No Equipment Program', 'Become Physically Fit', 'Beginner',
    'Bodyweight only — do it anywhere, including a small room or while travelling.', [
      day('Bodyweight Upper', 'Push, pull, core', 'strength', [['push-up', 4, '8–15'], ['pike-push-up', 3, '6–10'], ['inverted-row', 3, '8–12'], ['superman', 3, '12'], ['plank', 3, '45 s']]),
      rest(),
      day('Bodyweight Lower', 'Legs & glutes', 'strength', [['bodyweight-squat', 4, '20'], ['walking-lunge', 3, '12 each'], ['glute-bridge', 3, '15'], ['wall-sit', 3, '45 s'], ['calf-raise', 3, '20']]),
      rest(),
      day('Bodyweight HIIT', 'Conditioning', 'hiit', [['burpee', 4, '10'], ['mountain-climber', 4, '30 s'], ['jump-squat', 4, '12'], ['high-knees', 4, '30 s']]),
      day('Mobility', 'Stretch & recover', 'mobility', [['worlds-greatest-stretch', 2, '5 each'], ['cat-cow', 2, '10'], ['hip-flexor-stretch', 2, '30 s each'], ['childs-pose', 2, '60 s']]),
      rest(),
    ]),
  program('gym-workout', 'Gym Workout Program', 'Gain Strength', 'Intermediate',
    'A classic three-day gym routine built around the big compound lifts.', [
      day('Gym A', 'Squat & bench', 'strength', [['back-squat', 4, '5', 150], ['bench-press', 4, '5', 150], ['barbell-row', 3, '8'], ['tricep-pushdown', 3, '12']]),
      rest(),
      day('Gym B', 'Deadlift & press', 'strength', [['deadlift', 3, '5', 180], ['overhead-press', 4, '5', 150], ['lat-pulldown', 3, '10'], ['barbell-curl', 3, '10']]),
      rest(),
      day('Gym C', 'Volume day', 'strength', [['front-squat', 3, '6', 150], ['incline-db-press', 3, '10'], ['seated-cable-row', 3, '10'], ['leg-curl', 3, '12'], ['cable-crunch', 3, '15']]),
      rest(), rest(),
    ]),
  program('upper-body', 'Upper Body', 'Build Muscle', 'Intermediate', 'A single complete upper-body session.', [upper]),
  program('lower-body', 'Lower Body', 'Build Muscle', 'Intermediate', 'A single complete lower-body session.', [lower]),
  program('push-day', 'Push Day', 'Build Muscle', 'Intermediate', 'Chest, shoulders and triceps.', [push]),
  program('pull-day', 'Pull Day', 'Build Muscle', 'Intermediate', 'Back, biceps and rear shoulders.', [pull]),
  program('leg-day', 'Leg Day', 'Build Muscle', 'Intermediate', 'Quads, hamstrings, glutes and calves.', [legs]),
  program('ppl', 'Push Pull Legs', 'Build Muscle', 'Intermediate',
    'Six-day split: each muscle group trained twice a week. Take the rest day seriously.', [push, pull, legs, push, pull, legs, rest()]),
  program('upper-lower', 'Upper / Lower Split', 'Gain Strength', 'Intermediate',
    'Four days a week, alternating upper and lower body sessions.', [upper, lower, rest(), upper, lower, rest(), rest()]),
  program('cardio-conditioning', 'Cardio Conditioning', 'Improve Endurance', 'Beginner',
    'Build your aerobic engine with a mix of steady cardio, intervals and circuits.', [
      day('Steady Cardio', '30–40 min easy', 'cardio', [['easy-run', 1, '30–40 min']]),
      day('Circuit', 'Full-body conditioning', 'circuit', [['kb-swing', 4, '15'], ['burpee', 4, '10'], ['jump-rope', 4, '60 s'], ['mountain-climber', 4, '30 s']]),
      rest(),
      day('Intervals', 'Hard/easy repeats', 'hiit', [['intervals', 8, '1 min hard / 90 s easy']]),
      day('Bike or Incline Walk', '30 min', 'cardio', [['stationary-bike', 1, '30 min']]),
      day('Long Easy Session', '45–60 min', 'cardio', [['brisk-walk', 1, '45–60 min']]),
      rest(),
    ]),
  program('running-beginner', 'Running Beginner Program', 'Improve Running', 'Beginner',
    'Walk-run intervals that build up to continuous running. Repeat a week if it feels too hard — progress gradually.', [
      day('Run/Walk 1', '6× (1 min run + 2 min walk)', 'run', [['intervals', 6, '1 min run / 2 min walk']]),
      rest(),
      day('Run/Walk 2', '6× (90 s run + 2 min walk)', 'run', [['intervals', 6, '90 s run / 2 min walk']]),
      day('Strength for Runners', 'Legs & core', 'strength', [['bodyweight-squat', 3, '15'], ['glute-bridge', 3, '15'], ['single-leg-rdl', 3, '8 each'], ['calf-raise', 3, '20'], ['side-plank', 2, '30 s each']]),
      day('Run/Walk 3', '5× (2 min run + 1 min walk)', 'run', [['intervals', 5, '2 min run / 1 min walk']]),
      rest(),
      day('Easy Long Walk', '40 min walk', 'cardio', [['brisk-walk', 1, '40 min']]),
    ]),
];
