export interface GoalInfo {
  id: string;
  label: string;
  plan: string;
  weekly: string[];
  programs: string[]; // built-in program ids
  mealFocus: MealFocus;
}

export type MealFocus = 'weight_loss' | 'muscle' | 'general' | 'high_protein' | 'balanced';

export const GOALS: GoalInfo[] = [
  {
    id: 'Lose Weight', label: 'Lose Weight', mealFocus: 'weight_loss',
    plan: 'Combine 2–3 strength sessions with 2–3 cardio sessions and plenty of daily walking. A moderate calorie deficit with enough protein works better long-term than crash dieting.',
    weekly: ['2–3 full-body strength sessions', '2 cardio sessions (run, bike, brisk walk)', 'Daily steps goal (e.g. 8,000+)', '1–2 rest or mobility days'],
    programs: ['fat-loss', 'beginner-full-body', 'running-beginner'],
  },
  {
    id: 'Lose Body Fat', label: 'Lose Body Fat', mealFocus: 'high_protein',
    plan: 'Keep lifting to preserve muscle while in a small deficit. Prioritise protein, sleep and consistency; add intervals once or twice a week.',
    weekly: ['3 strength sessions', '1–2 interval sessions', 'Daily walking', 'Protein at every meal'],
    programs: ['fat-loss', 'upper-lower', 'cardio-conditioning'],
  },
  {
    id: 'Build Muscle', label: 'Build Muscle', mealFocus: 'muscle',
    plan: 'Progressive resistance training: train each muscle about twice a week and add a rep or a little weight over time. Eat enough overall, with protein spread across the day.',
    weekly: ['4–6 resistance sessions (split routine)', 'Track weights and reps to progress', 'Light cardio 1–2× for health', '7–9 hours of sleep'],
    programs: ['muscle-building', 'ppl', 'upper-lower'],
  },
  {
    id: 'Build Abs', label: 'Build Abs', mealFocus: 'high_protein',
    plan: 'Train your core 2–3 times a week, but also train the whole body and manage nutrition — visible abs depend largely on overall body fat.',
    weekly: ['2–3 core sessions', '3 full-body or split strength sessions', '2 cardio sessions', 'Consistent nutrition'],
    programs: ['abs-core', 'fat-loss', 'beginner-full-body'],
  },
  {
    id: 'Improve Core Strength', label: 'Improve Core Strength', mealFocus: 'balanced',
    plan: 'Focus on bracing and control: anti-extension (planks), anti-rotation (Pallof press) and loaded carries, plus compound lifts.',
    weekly: ['3 core-focused sessions', 'Carries and compound lifts', 'Mobility work'],
    programs: ['abs-core', 'no-equipment'],
  },
  {
    id: 'Become Physically Fit', label: 'Become Physically Fit', mealFocus: 'general',
    plan: 'A balanced mix of strength, cardio, flexibility and recovery. Start easy and build up gradually.',
    weekly: ['2–3 strength sessions', '2 cardio sessions', '1 mobility session', '1–2 rest days'],
    programs: ['beginner-full-body', 'home-workout', 'no-equipment'],
  },
  {
    id: 'Improve Endurance', label: 'Improve Endurance', mealFocus: 'balanced',
    plan: 'Mostly easy aerobic work with one or two harder sessions each week. Keep 1–2 strength days to stay injury-resistant.',
    weekly: ['3–4 cardio sessions (mostly easy)', '1 interval session', '1–2 strength sessions'],
    programs: ['cardio-conditioning', 'running-beginner'],
  },
  {
    id: 'Improve Running', label: 'Improve Running', mealFocus: 'balanced',
    plan: 'Run 3–4 times a week, mostly at an easy conversational pace. Increase weekly distance gradually and include runner-specific strength work.',
    weekly: ['3–4 runs (mostly easy)', '1 longer run', '1–2 leg and core strength sessions', 'Rest day before long runs'],
    programs: ['running-beginner', 'cardio-conditioning'],
  },
  {
    id: 'Gain Strength', label: 'Gain Strength', mealFocus: 'muscle',
    plan: 'Low-to-moderate reps on big compound lifts with longer rest periods. Add weight gradually and track your top sets.',
    weekly: ['3–4 heavy compound sessions', 'Accessory work for weak points', 'Plenty of recovery'],
    programs: ['gym-workout', 'upper-lower'],
  },
  {
    id: 'Maintain Weight', label: 'Maintain Weight', mealFocus: 'balanced',
    plan: 'Keep a consistent routine and eat around maintenance. Weigh in weekly and adjust gradually.',
    weekly: ['3 strength sessions', '2 cardio sessions', 'Weekly weigh-in'],
    programs: ['beginner-full-body', 'upper-lower'],
  },
  {
    id: 'General Health', label: 'General Health', mealFocus: 'general',
    plan: 'Move every day, lift a couple of times a week, sleep well, drink water and eat mostly whole foods.',
    weekly: ['150+ minutes of moderate activity', '2 strength sessions', 'Daily walks', 'Stretching'],
    programs: ['home-workout', 'beginner-full-body', 'no-equipment'],
  },
];

export const GOAL_BY_ID: Record<string, GoalInfo> = Object.fromEntries(GOALS.map((g) => [g.id, g]));

export const WORKOUT_TYPES = ['strength', 'cardio', 'hiit', 'circuit', 'core', 'mobility', 'yoga', 'stretching', 'sports', 'cycling', 'swimming', 'walking', 'other'];

export const MOODS = ['😫 Drained', '😐 Okay', '🙂 Good', '😄 Great', '🔥 Unstoppable'];

export const DEFAULT_HABITS = [
  { name: 'Workout', icon: 'dumbbell' },
  { name: 'Walk', icon: 'footprints' },
  { name: 'Run', icon: 'run' },
  { name: 'Drink enough water', icon: 'droplet' },
  { name: 'Eat healthy', icon: 'utensils' },
  { name: 'Stretch', icon: 'heart' },
  { name: 'Take vitamins', icon: 'sparkle' },
  { name: 'Sleep target', icon: 'moon' },
  { name: 'No sugary drinks', icon: 'x' },
];
