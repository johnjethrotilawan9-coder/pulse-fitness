import { useMemo, useState } from 'react';
import { useData } from '../hooks/useData';
import { useConfirm } from '../components/ui/Confirm';
import { PageHeader, Card, EmptyState, Badge } from '../components/ui/Misc';
import { Button, IconButton } from '../components/ui/Button';
import { Input } from '../components/ui/Field';
import { Modal } from '../components/ui/Modal';
import { Icon, type IconName } from '../components/Icon';
import { addDays, fmtDate, fmtLongDate, relativeDay, todayISO } from '../utils/date';
import { uuid } from '../utils/id';
import { DEFAULT_HABITS } from '../data/goals';
import type { Habit } from '../types';

function streakOf(dates: Set<string>, today: string) {
  let d = dates.has(today) ? today : addDays(today, -1);
  let n = 0;
  while (dates.has(d)) {
    n++;
    d = addDays(d, -1);
  }
  return n;
}

export default function HabitsPage() {
  const data = useData();
  const { habits, habit_logs } = data.tables;
  const confirm = useConfirm();
  const [date, setDate] = useState(todayISO());
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState<Habit | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const today = todayISO();

  const active = [...habits].filter((h) => h.active).sort((a, b) => a.position - b.position || a.name.localeCompare(b.name));
  const logsByHabit = useMemo(() => {
    const m: Record<string, Set<string>> = {};
    habit_logs.forEach((l) => (m[l.habit_id] ??= new Set()).add(l.date));
    return m;
  }, [habit_logs]);
  const doneToday = active.filter((h) => logsByHabit[h.id]?.has(date)).length;
  const week = Array.from({ length: 7 }, (_, i) => addDays(date, i - 6));

  async function toggle(h: Habit) {
    if (busy) return;
    setBusy(h.id);
    const existing = habit_logs.find((l) => l.habit_id === h.id && l.date === date);
    if (existing) await data.remove('habit_logs', existing);
    else await data.save('habit_logs', { id: uuid(), habit_id: h.id, date });
    setBusy(null);
  }

  async function addHabit(name: string, icon: string) {
    const trimmed = name.trim();
    if (!trimmed) return false;
    const r = await data.save('habits', { id: uuid(), name: trimmed, icon, position: habits.length, active: true }, { toast: `Habit “${trimmed}” added` });
    return r.ok;
  }

  return (
    <div className="stack">
      <PageHeader title="Habits" subtitle="Small daily wins add up" actions={<Button variant="primary" icon="plus" onClick={() => setAdding(true)}>Add habit</Button>} />
      <div className="row">
        <IconButton icon="left" label="Previous day" variant="secondary" onClick={() => setDate(addDays(date, -1))} />
        <div className="grow center">
          <div className="strong">{relativeDay(date)}</div>
          <div className="xs muted">{fmtLongDate(date)}</div>
        </div>
        <IconButton icon="right" label="Next day" variant="secondary" disabled={date >= today} onClick={() => setDate(addDays(date, 1))} />
      </div>

      {active.length === 0 ? (
        <Card>
          <EmptyState icon="checkSquare" title="No habits yet" message="Add a few daily habits — workout, water, stretching, sleep — and check them off each day." action={<Button variant="primary" icon="plus" onClick={() => setAdding(true)}>Add your first habit</Button>} />
        </Card>
      ) : (
        <Card title={`${doneToday} of ${active.length} done`} icon="checkSquare" action={doneToday === active.length ? <Badge tone="success">All done 🎉</Badge> : undefined}>
          <div>
            {active.map((h) => {
              const set = logsByHabit[h.id] ?? new Set<string>();
              const on = set.has(date);
              const streak = streakOf(set, today);
              return (
                <div key={h.id} className="habit-row">
                  <button className={`habit-check ${on ? 'on' : ''}`} aria-pressed={on} aria-label={`${h.name}: ${on ? 'done' : 'not done'} on ${fmtDate(date)}`} onClick={() => toggle(h)} disabled={busy === h.id}>
                    <Icon name={on ? 'check' : ((h.icon as IconName) ?? 'check')} size={22} strokeWidth={on ? 3 : 2} />
                  </button>
                  <div className="grow" style={{ minWidth: 0 }}>
                    <div className="strong ellipsis" style={on ? { textDecoration: 'line-through', color: 'var(--muted)' } : undefined}>
                      {h.name}
                    </div>
                    <div className="row" style={{ gap: 8, marginTop: 4 }}>
                      <div className="habit-week" aria-label="Last 7 days">
                        {week.map((d) => (
                          <span key={d} className={set.has(d) ? 'on' : ''} title={`${fmtDate(d)}${set.has(d) ? ' ✓' : ''}`}>
                            {fmtDate(d, { weekday: 'narrow' })}
                          </span>
                        ))}
                      </div>
                      {streak > 0 && <span className="xs strong accent-text">🔥 {streak}</span>}
                    </div>
                  </div>
                  <IconButton icon="edit" size="sm" label={`Edit ${h.name}`} onClick={() => setEditing(h)} />
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {habits.some((h) => !h.active) && (
        <Card title="Archived" icon="list">
          <div className="row-wrap">
            {habits
              .filter((h) => !h.active)
              .map((h) => (
                <Button key={h.id} size="sm" icon="rotate" onClick={() => data.save('habits', { ...h, active: true }, { toast: `“${h.name}” restored` })}>
                  {h.name}
                </Button>
              ))}
          </div>
          <p className="xs muted" style={{ marginTop: 8 }}>
            Tap to restore. History is kept while archived.
          </p>
        </Card>
      )}

      <AddHabit open={adding} onClose={() => setAdding(false)} existing={habits.map((h) => h.name.toLowerCase())} onAdd={addHabit} />
      <EditHabit
        habit={editing}
        onClose={() => setEditing(null)}
        onDelete={async (h) => {
          if (await confirm({ title: 'Delete habit?', message: `“${h.name}” and its entire check-in history will be permanently deleted.`, confirmLabel: 'Delete', danger: true })) if ((await data.remove('habits', h, { toast: 'Habit deleted' })).ok) setEditing(null);
        }}
      />
    </div>
  );
}

function AddHabit({ open, onClose, existing, onAdd }: { open: boolean; onClose: () => void; existing: string[]; onAdd: (n: string, icon: string) => Promise<boolean> }) {
  const [name, setName] = useState('');
  const [err, setErr] = useState<string | undefined>();
  const [busy, setBusy] = useState(false);
  const suggestions = DEFAULT_HABITS.filter((h) => !existing.includes(h.name.toLowerCase()));
  return (
    <Modal open={open} title="Add habit" size="sm" onClose={onClose}>
      {suggestions.length > 0 && (
        <>
          <p className="field-label">Suggestions</p>
          <div className="chips">
            {suggestions.map((s) => (
              <button
                key={s.name}
                className="chip"
                disabled={busy}
                onClick={async () => {
                  setBusy(true);
                  await onAdd(s.name, s.icon);
                  setBusy(false);
                }}
              >
                + {s.name}
              </button>
            ))}
          </div>
        </>
      )}
      <form
        className="stack-sm"
        onSubmit={async (e) => {
          e.preventDefault();
          if (!name.trim()) return setErr('Enter a habit name.');
          if (existing.includes(name.trim().toLowerCase())) return setErr('You already have this habit.');
          setBusy(true);
          const ok = await onAdd(name, 'check');
          setBusy(false);
          if (ok) {
            setName('');
            setErr(undefined);
            onClose();
          }
        }}
      >
        <Input label="Custom habit" value={name} onChange={(e) => setName(e.target.value)} error={err} placeholder="e.g. 10 min meditation" />
        <Button type="submit" variant="primary" loading={busy}>
          Add custom habit
        </Button>
      </form>
    </Modal>
  );
}

function EditHabit({ habit, onClose, onDelete }: { habit: Habit | null; onClose: () => void; onDelete: (h: Habit) => void }) {
  const data = useData();
  const [name, setName] = useState('');
  const [err, setErr] = useState<string | undefined>();
  const [saving, setSaving] = useState(false);
  const [last, setLast] = useState<Habit | null>(null);
  if (habit !== last) {
    setLast(habit);
    setName(habit?.name ?? '');
    setErr(undefined);
  }
  if (!habit) return null;
  return (
    <Modal
      open
      title="Edit habit"
      size="sm"
      onClose={onClose}
      footer={
        <>
          <Button variant="ghost" icon="trash" onClick={() => onDelete(habit)}>
            Delete
          </Button>
          <Button
            onClick={async () => {
              setSaving(true);
              const r = await data.save('habits', { ...habit, active: false }, { toast: 'Habit archived (history kept)' });
              setSaving(false);
              if (r.ok) onClose();
            }}
          >
            Archive
          </Button>
          <Button
            variant="primary"
            loading={saving}
            onClick={async () => {
              if (!name.trim()) return setErr('Enter a name.');
              setSaving(true);
              const r = await data.save('habits', { ...habit, name: name.trim() }, { toast: 'Saved' });
              setSaving(false);
              if (r.ok) onClose();
            }}
          >
            Save
          </Button>
        </>
      }
    >
      <Input label="Name" value={name} onChange={(e) => setName(e.target.value)} error={err} />
    </Modal>
  );
}
