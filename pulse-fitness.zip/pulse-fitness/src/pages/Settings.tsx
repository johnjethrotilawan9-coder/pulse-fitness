import { useState } from 'react';
import { useData, useProfile, clearLocalData, TABLES } from '../hooks/useData';
import { useAuth } from '../hooks/useAuth';
import { useUnits } from '../hooks/useUnits';
import { useToast } from '../hooks/useToast';
import { useOnline } from '../hooks/useOnline';
import { useConfirm } from '../components/ui/Confirm';
import { useSignOut } from '../components/layout/AppShell';
import { PageHeader, Card } from '../components/ui/Misc';
import { Button } from '../components/ui/Button';
import { Input, NumberInput, Select, Toggle, Segmented, ChipSelect } from '../components/ui/Field';
import { Modal } from '../components/ui/Modal';
import { GOALS } from '../data/goals';
import { Validator } from '../utils/validate';
import { round } from '../utils/units';
import { supabase } from '../services/supabase';
import { toApiError } from '../services/api';
import { deleteProgressPhoto } from '../services/storage';
import { applyTheme } from '../hooks/useTheme';
import type { Profile, ThemeMode } from '../types';

export default function SettingsPage() {
  const data = useData();
  const profile = useProfile();
  const u = useUnits();
  const { user } = useAuth();
  const toast = useToast();
  const online = useOnline();
  const confirm = useConfirm();
  const signOut = useSignOut();

  const [p, setP] = useState(() => ({
    name: profile.name ?? '',
    height: profile.height_cm == null ? '' : String(u.len(profile.height_cm)),
    weight: profile.weight_kg == null ? '' : String(u.weight(profile.weight_kg)),
    start: profile.start_weight_kg == null ? '' : String(u.weight(profile.start_weight_kg)),
    goal: profile.goal_weight_kg == null ? '' : String(u.weight(profile.goal_weight_kg)),
    dob: profile.date_of_birth ?? '',
    sex: profile.sex ?? '',
  }));
  const [t, setT] = useState(() => ({
    calorie_target: String(profile.calorie_target),
    protein_target: String(profile.protein_target),
    carbs_target: String(profile.carbs_target),
    fat_target: String(profile.fat_target),
    fiber_target: String(profile.fiber_target),
    water_target_ml: String(profile.water_target_ml),
    weekly_workout_target: String(profile.weekly_workout_target),
    weekly_run_km_target: String(u.dist(profile.weekly_run_km_target)),
    step_target: String(profile.step_target),
    default_rest_seconds: String(profile.default_rest_seconds),
  }));
  const [pErr, setPErr] = useState<Record<string, string>>({});
  const [tErr, setTErr] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState<string | null>(null);
  const [pwOpen, setPwOpen] = useState(false);
  const [wipeOpen, setWipeOpen] = useState(false);

  async function saveProfileSection() {
    const v = new Validator();
    const maxW = u.w === 'kg' ? 499 : 1100;
    const height = v.number('height', p.height, { min: 30, max: u.l === 'cm' ? 272 : 107, label: 'Height' });
    const weight = v.number('weight', p.weight, { min: 1, max: maxW, label: 'Weight' });
    const start = v.number('start', p.start, { min: 1, max: maxW, label: 'Starting weight' });
    const goal = v.number('goal', p.goal, { min: 1, max: maxW, label: 'Goal weight' });
    if (p.dob) v.date('dob', p.dob);
    if (p.dob && p.dob > new Date().toISOString().slice(0, 10)) v.check('dob', false, 'Date of birth is in the future.');
    setPErr(v.errors);
    if (!v.ok) return;
    setBusy('profile');
    await data.saveProfile(
      {
        name: p.name.trim() || null,
        height_cm: u.fromLen(height),
        weight_kg: u.fromWeight(weight),
        start_weight_kg: u.fromWeight(start),
        goal_weight_kg: u.fromWeight(goal),
        date_of_birth: p.dob || null,
        sex: (p.sex || null) as Profile['sex'],
      },
      { toast: 'Profile saved' },
    );
    setBusy(null);
  }

  async function saveTargets() {
    const v = new Validator();
    const n = (k: keyof typeof t, label: string, max: number, int = true, min = 0) => v.number(k, t[k], { min, max, int, label, required: true });
    const vals = {
      calorie_target: n('calorie_target', 'Calories', 10000),
      protein_target: n('protein_target', 'Protein', 1000),
      carbs_target: n('carbs_target', 'Carbs', 2000),
      fat_target: n('fat_target', 'Fat', 1000),
      fiber_target: n('fiber_target', 'Fiber', 500),
      water_target_ml: n('water_target_ml', 'Water', 20000),
      weekly_workout_target: n('weekly_workout_target', 'Weekly workouts', 21),
      weekly_run_km_target: n('weekly_run_km_target', 'Weekly distance', 1000, false),
      step_target: n('step_target', 'Steps', 200000),
      default_rest_seconds: n('default_rest_seconds', 'Rest', 3600),
    };
    setTErr(v.errors);
    if (!v.ok) return;
    setBusy('targets');
    await data.saveProfile({ ...(vals as unknown as Partial<Profile>), weekly_run_km_target: round(u.fromDist(vals.weekly_run_km_target) ?? 0, 3) }, { toast: 'Targets saved' });
    setBusy(null);
  }

  /** Mifflin–St Jeor estimate × light-activity factor — general guidance only. */
  function suggestTargets() {
    const w = profile.weight_kg, h = profile.height_cm;
    const age = profile.date_of_birth ? Math.floor((Date.now() - new Date(profile.date_of_birth).getTime()) / 3.156e10) : null;
    if (!w || !h || !age || !profile.sex) return toast.info('Save your weight, height, date of birth and sex first to get a suggestion.');
    const bmr = 10 * w + 6.25 * h - 5 * age + (profile.sex === 'male' ? 5 : profile.sex === 'female' ? -161 : -78);
    let kcal = bmr * 1.45;
    const goals = profile.goals;
    if (goals.some((g) => g === 'Lose Weight' || g === 'Lose Body Fat')) kcal -= 400;
    else if (goals.some((g) => g === 'Build Muscle' || g === 'Gain Strength')) kcal += 250;
    kcal = Math.round(kcal / 50) * 50;
    const protein = Math.round(w * (goals.some((g) => ['Build Muscle', 'Gain Strength', 'Lose Body Fat'].includes(g)) ? 1.8 : 1.4));
    const fat = Math.round((kcal * 0.28) / 9);
    const carbs = Math.max(0, Math.round((kcal - protein * 4 - fat * 9) / 4));
    setT((x) => ({ ...x, calorie_target: String(kcal), protein_target: String(protein), fat_target: String(fat), carbs_target: String(carbs), water_target_ml: String(Math.round((w * 35) / 50) * 50) }));
    toast.info('Suggested targets filled in — review and tap “Save targets”.');
  }

  async function exportData() {
    const payload = { exported_at: new Date().toISOString(), account: user?.email, profile: data.profile, workouts: data.workouts, ...data.tables };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pulse-fitness-export-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    toast.success('Export downloaded');
  }

  async function wipeAll() {
    if (!user) return;
    setBusy('wipe');
    try {
      for (const ph of data.tables.progress_photos) await deleteProgressPhoto(ph.storage_path).catch(() => undefined);
      const order = ['workouts', ...TABLES.filter((t) => t !== 'habit_logs'), 'habit_logs'];
      for (const table of order) {
        const { error } = await supabase.from(table).delete().eq('user_id', user.id);
        if (error) throw error;
      }
      clearLocalData(user.id);
      toast.success('All your fitness data was deleted.');
      setWipeOpen(false);
      await data.refresh();
    } catch (e) {
      toast.error(`Delete failed: ${toApiError(e).message}`);
    } finally {
      setBusy(null);
    }
  }

  const theme = profile.theme;

  return (
    <div className="stack">
      <PageHeader title="Settings" subtitle={user?.email} />

      <Card title="Profile" icon="settings">
        <div className="form-grid">
          <Input label="Name" className="full" value={p.name} onChange={(e) => setP({ ...p, name: e.target.value })} />
          <NumberInput label="Height" suffix={u.l} value={p.height} onChange={(e) => setP({ ...p, height: e.target.value })} error={pErr.height} />
          <NumberInput label="Current weight" suffix={u.w} value={p.weight} onChange={(e) => setP({ ...p, weight: e.target.value })} error={pErr.weight} hint="Updated automatically by weigh-ins" />
          <NumberInput label="Starting weight" suffix={u.w} value={p.start} onChange={(e) => setP({ ...p, start: e.target.value })} error={pErr.start} hint="Blank = your first weigh-in" />
          <NumberInput label="Goal weight" suffix={u.w} value={p.goal} onChange={(e) => setP({ ...p, goal: e.target.value })} error={pErr.goal} />
          <Input label="Date of birth (optional)" type="date" value={p.dob} onChange={(e) => setP({ ...p, dob: e.target.value })} error={pErr.dob} />
          <Select label="Sex (optional, for estimates)" value={p.sex} onChange={(e) => setP({ ...p, sex: e.target.value })}>
            <option value="">Prefer not to say</option>
            <option value="female">Female</option>
            <option value="male">Male</option>
            <option value="other">Other</option>
          </Select>
        </div>
        <div style={{ marginTop: 14 }}>
          <Button variant="primary" loading={busy === 'profile'} onClick={saveProfileSection}>
            Save profile
          </Button>
        </div>
      </Card>

      <Card title="Units" icon="scale">
        <div className="stack">
          <div className="row between" style={{ flexWrap: 'wrap' }}>
            <span className="strong">Weight</span>
            <Segmented label="Weight unit" value={profile.weight_unit} onChange={(v) => void data.saveProfile({ weight_unit: v }, { toast: `Weights in ${v}` }).then(() => window.location.reload())} options={[{ value: 'kg', label: 'kg' }, { value: 'lb', label: 'lb' }]} />
          </div>
          <div className="row between" style={{ flexWrap: 'wrap' }}>
            <span className="strong">Distance</span>
            <Segmented label="Distance unit" value={profile.distance_unit} onChange={(v) => void data.saveProfile({ distance_unit: v }, { toast: `Distances in ${v}` }).then(() => window.location.reload())} options={[{ value: 'km', label: 'km' }, { value: 'mi', label: 'miles' }]} />
          </div>
          <div className="row between" style={{ flexWrap: 'wrap' }}>
            <span className="strong">Body measurements</span>
            <Segmented label="Length unit" value={profile.length_unit} onChange={(v) => void data.saveProfile({ length_unit: v }, { toast: `Measurements in ${v}` }).then(() => window.location.reload())} options={[{ value: 'cm', label: 'cm' }, { value: 'in', label: 'inches' }]} />
          </div>
          <p className="xs faint">Values are stored in metric and converted for display, so switching units never changes your data.</p>
        </div>
      </Card>

      <Card title="Fitness goals" icon="target">
        <ChipSelect label="Your goals" values={profile.goals} options={GOALS.map((g) => g.id)} onChange={(v) => void data.saveProfile({ goals: v }, { toast: 'Goals saved' })} />
      </Card>

      <Card title="Daily & weekly targets" icon="flag" action={<Button size="sm" icon="sparkle" onClick={suggestTargets}>Suggest</Button>}>
        <div className="form-grid cols-3">
          <NumberInput label="Calories" suffix="kcal" decimal={false} value={t.calorie_target} onChange={(e) => setT({ ...t, calorie_target: e.target.value })} error={tErr.calorie_target} />
          <NumberInput label="Protein" suffix="g" decimal={false} value={t.protein_target} onChange={(e) => setT({ ...t, protein_target: e.target.value })} error={tErr.protein_target} />
          <NumberInput label="Carbs" suffix="g" decimal={false} value={t.carbs_target} onChange={(e) => setT({ ...t, carbs_target: e.target.value })} error={tErr.carbs_target} />
          <NumberInput label="Fat" suffix="g" decimal={false} value={t.fat_target} onChange={(e) => setT({ ...t, fat_target: e.target.value })} error={tErr.fat_target} />
          <NumberInput label="Fiber" suffix="g" decimal={false} value={t.fiber_target} onChange={(e) => setT({ ...t, fiber_target: e.target.value })} error={tErr.fiber_target} />
          <NumberInput label="Water" suffix="ml" decimal={false} value={t.water_target_ml} onChange={(e) => setT({ ...t, water_target_ml: e.target.value })} error={tErr.water_target_ml} />
          <NumberInput label="Workouts per week" decimal={false} value={t.weekly_workout_target} onChange={(e) => setT({ ...t, weekly_workout_target: e.target.value })} error={tErr.weekly_workout_target} />
          <NumberInput label="Running per week" suffix={u.d} value={t.weekly_run_km_target} onChange={(e) => setT({ ...t, weekly_run_km_target: e.target.value })} error={tErr.weekly_run_km_target} />
          <NumberInput label="Daily steps" decimal={false} value={t.step_target} onChange={(e) => setT({ ...t, step_target: e.target.value })} error={tErr.step_target} />
          <NumberInput label="Default rest" suffix="sec" decimal={false} value={t.default_rest_seconds} onChange={(e) => setT({ ...t, default_rest_seconds: e.target.value })} error={tErr.default_rest_seconds} />
        </div>
        <p className="xs faint" style={{ marginTop: 10 }}>“Suggest” gives a general estimate from your profile and goals — not medical or dietetic advice.</p>
        <div style={{ marginTop: 12 }}>
          <Button variant="primary" loading={busy === 'targets'} onClick={saveTargets}>
            Save targets
          </Button>
        </div>
      </Card>

      <Card title="Appearance & alerts" icon="sun">
        <div className="stack">
          <div className="row between" style={{ flexWrap: 'wrap' }}>
            <span className="strong">Theme</span>
            <Segmented<ThemeMode>
              label="Theme"
              value={theme}
              onChange={(v) => {
                applyTheme(v);
                void data.saveProfile({ theme: v });
              }}
              options={[{ value: 'light', label: 'Light' }, { value: 'dark', label: 'Dark' }, { value: 'system', label: 'System' }]}
            />
          </div>
          <Toggle
            label="Notifications"
            description="Alert when a rest timer finishes while the app is in the background (where the browser supports it)."
            checked={profile.notifications_enabled}
            onChange={async (v) => {
              if (v && 'Notification' in window && Notification.permission === 'default') await Notification.requestPermission().catch(() => undefined);
              if (v && 'Notification' in window && Notification.permission === 'denied') toast.warning('Notifications are blocked in your browser settings.');
              void data.saveProfile({ notifications_enabled: v });
            }}
          />
          <Toggle label="Timer sound" description="Play a short chime when a rest timer ends." checked={profile.sound_enabled} onChange={(v) => void data.saveProfile({ sound_enabled: v })} />
          <Toggle label="Show meal plans in calendar" checked={profile.show_meals_in_calendar} onChange={(v) => void data.saveProfile({ show_meals_in_calendar: v })} />
        </div>
      </Card>

      <Card title="Data" icon="cloud">
        <div className="stack-sm">
          <p className="small muted">
            Your data lives in your private Supabase account and syncs across your devices.
            {data.lastSync ? ` Last synced ${new Date(data.lastSync).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}.` : ''}
            {data.pending ? ` ${data.pending} change(s) waiting to sync.` : ''}
          </p>
          <div className="row-wrap">
            <Button icon="refresh" loading={data.syncing} disabled={!online} onClick={() => void data.refresh()}>
              Sync now
            </Button>
            <Button icon="download" onClick={exportData}>
              Export all data (JSON)
            </Button>
            <Button
              icon="trash"
              onClick={async () => {
                if (!user) return;
                if (data.pending && !(await confirm({ title: 'Unsynced changes', message: `${data.pending} change(s) haven't synced and would be lost.`, confirmLabel: 'Clear anyway', danger: true }))) return;
                clearLocalData(user.id);
                window.location.reload();
              }}
            >
              Clear this device's cache
            </Button>
          </div>
          <div className="divider" style={{ margin: '10px 0' }} />
          <Button variant="danger" icon="alert" onClick={() => setWipeOpen(true)} disabled={!online}>
            Delete all my fitness data…
          </Button>
        </div>
      </Card>

      <Card title="Account" icon="logout">
        <div className="row-wrap">
          <Button onClick={() => setPwOpen(true)} disabled={!online}>
            Change password
          </Button>
          <Button variant="primary" icon="logout" onClick={() => void signOut()}>
            Log out
          </Button>
        </div>
      </Card>

      <p className="xs faint center">Pulse Fitness · general fitness guidance only, not medical advice.</p>

      <ChangePassword open={pwOpen} onClose={() => setPwOpen(false)} />
      <WipeDialog open={wipeOpen} busy={busy === 'wipe'} onClose={() => setWipeOpen(false)} onConfirm={wipeAll} />
    </div>
  );
}

function ChangePassword({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { updatePassword } = useAuth();
  const toast = useToast();
  const [a, setA] = useState('');
  const [b, setB] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  return (
    <Modal
      open={open}
      title="Change password"
      size="sm"
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button
            variant="primary"
            loading={busy}
            onClick={async () => {
              if (a.length < 8) return setErr('Use at least 8 characters.');
              if (a !== b) return setErr('Passwords do not match.');
              setBusy(true);
              const e = await updatePassword(a);
              setBusy(false);
              if (e) setErr(e);
              else {
                toast.success('Password updated');
                setA('');
                setB('');
                setErr(null);
                onClose();
              }
            }}
          >
            Update
          </Button>
        </>
      }
    >
      <Input label="New password" type="password" autoComplete="new-password" value={a} onChange={(e) => setA(e.target.value)} />
      <Input label="Confirm new password" type="password" autoComplete="new-password" value={b} onChange={(e) => setB(e.target.value)} error={err ?? undefined} />
    </Modal>
  );
}

function WipeDialog({ open, busy, onClose, onConfirm }: { open: boolean; busy: boolean; onClose: () => void; onConfirm: () => void }) {
  const [text, setText] = useState('');
  return (
    <Modal
      open={open}
      title="Delete all fitness data?"
      size="sm"
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="danger" loading={busy} disabled={text !== 'DELETE'} onClick={onConfirm}>
            Delete everything
          </Button>
        </>
      }
    >
      <p>This permanently deletes every workout, run, meal, measurement, photo, habit and record in your account. Your login and settings remain. Consider exporting first.</p>
      <Input label='Type "DELETE" to confirm' value={text} onChange={(e) => setText(e.target.value)} autoComplete="off" />
    </Modal>
  );
}
