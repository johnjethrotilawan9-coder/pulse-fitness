import { useEffect, useMemo, useState } from 'react';
import { useData } from '../hooks/useData';
import { useExercises, customKey } from '../hooks/useExercises';
import { useRouter } from '../router';
import { useConfirm } from '../components/ui/Confirm';
import { PageHeader, SearchBox, Badge, EmptyState } from '../components/ui/Misc';
import { Button } from '../components/ui/Button';
import { Input, NumberInput, Select, Textarea } from '../components/ui/Field';
import { Modal } from '../components/ui/Modal';
import { Icon } from '../components/Icon';
import { BUILTIN_EXERCISES, EQUIPMENT, HOME_EQUIPMENT, MUSCLE_GROUPS } from '../data/exercises';
import { uuid } from '../utils/id';
import { Validator } from '../utils/validate';
import type { CustomExercise, Exercise } from '../types';

const TONES = ['accent', 'info', 'success', 'violet', 'warning', 'water'];
const toneFor = (g: string) => TONES[Math.abs([...g].reduce((a, c) => a + c.charCodeAt(0), 0)) % TONES.length];

export default function ExercisesPage() {
  const data = useData();
  const { all, byKey, favorites } = useExercises();
  const { query, navigate } = useRouter();
  const confirm = useConfirm();
  const [q, setQ] = useState('');
  const [group, setGroup] = useState('All');
  const [equipment, setEquipment] = useState('all');
  const [difficulty, setDifficulty] = useState('all');
  const [scope, setScope] = useState<'all' | 'favorites' | 'custom' | 'home' | 'noequip'>('all');
  const [open, setOpen] = useState<Exercise | null>(null);
  const [editing, setEditing] = useState<CustomExercise | null>(null);
  const [favBusy, setFavBusy] = useState(false);

  useEffect(() => {
    const k = query.get('ex');
    if (k && byKey[k]) {
      setOpen(byKey[k]);
      navigate('/exercises', { replace: true });
    }
  }, [query, byKey, navigate]);

  const list = useMemo(() => {
    const term = q.trim().toLowerCase();
    return all
      .filter((e) => group === 'All' || e.muscle_group === group || e.secondary_muscles.includes(group))
      .filter((e) => equipment === 'all' || e.equipment === equipment)
      .filter((e) => difficulty === 'all' || e.difficulty === difficulty)
      .filter((e) => scope === 'all' || (scope === 'favorites' ? favorites.has(e.key) : scope === 'custom' ? e.custom : scope === 'home' ? HOME_EQUIPMENT.has(e.equipment) : e.equipment === 'Bodyweight'))
      .filter((e) => !term || [e.name, e.muscle_group, e.equipment, ...e.secondary_muscles].some((s) => s.toLowerCase().includes(term)))
      .sort((a, b) => Number(favorites.has(b.key)) - Number(favorites.has(a.key)) || a.name.localeCompare(b.name));
  }, [all, q, group, equipment, difficulty, scope, favorites]);

  async function toggleFav(e: Exercise) {
    if (favBusy) return;
    setFavBusy(true);
    const existing = data.tables.favorite_exercises.find((f) => f.exercise_key === e.key);
    if (existing) await data.remove('favorite_exercises', existing, { toast: 'Removed from favorites' });
    else await data.save('favorite_exercises', { id: uuid(), exercise_key: e.key }, { toast: 'Added to favorites ★' });
    setFavBusy(false);
  }

  async function removeCustom(e: Exercise) {
    const row = data.tables.custom_exercises.find((c) => customKey(c.id) === e.key);
    if (!row) return;
    if (!(await confirm({ title: 'Delete custom exercise?', message: `“${e.name}” will be removed from your library. Past workouts keep their logged sets.`, confirmLabel: 'Delete', danger: true }))) return;
    const r = await data.remove('custom_exercises', row, { toast: 'Exercise deleted' });
    const fav = data.tables.favorite_exercises.find((f) => f.exercise_key === e.key);
    if (fav) await data.remove('favorite_exercises', fav);
    if (r.ok) setOpen(null);
  }

  return (
    <div className="stack">
      <PageHeader
        title="Exercise library"
        subtitle={`${BUILTIN_EXERCISES.length} built-in · ${data.tables.custom_exercises.length} custom · ${favorites.size} favorites`}
        actions={
          <Button variant="primary" icon="plus" onClick={() => setEditing(blankCustom())}>
            Custom exercise
          </Button>
        }
      />
      <SearchBox value={q} onChange={setQ} placeholder="Search by name, muscle or equipment" />
      <div className="chip-scroll">
        {['All', ...MUSCLE_GROUPS].map((g) => (
          <button key={g} className={`chip ${group === g ? 'chip-on' : ''}`} aria-pressed={group === g} onClick={() => setGroup(g)}>
            {g}
          </button>
        ))}
      </div>
      <div className="form-grid cols-3">
        <Select label="Show" value={scope} onChange={(e) => setScope(e.target.value as typeof scope)}>
          <option value="all">All exercises</option>
          <option value="favorites">★ Favorites</option>
          <option value="custom">My custom exercises</option>
          <option value="home">Home workout friendly</option>
          <option value="noequip">No equipment</option>
        </Select>
        <Select label="Equipment" value={equipment} onChange={(e) => setEquipment(e.target.value)}>
          <option value="all">Any equipment</option>
          {EQUIPMENT.map((e) => (
            <option key={e}>{e}</option>
          ))}
        </Select>
        <Select label="Difficulty" value={difficulty} onChange={(e) => setDifficulty(e.target.value)}>
          <option value="all">Any level</option>
          <option>Beginner</option>
          <option>Intermediate</option>
          <option>Advanced</option>
        </Select>
      </div>

      {list.length === 0 ? (
        <EmptyState icon="search" title={scope === 'favorites' ? 'No favorites yet' : scope === 'custom' ? 'No custom exercises yet' : 'No exercises match'} message={scope === 'favorites' ? 'Tap the ☆ on any exercise to save it here.' : 'Try another search or filter.'} />
      ) : (
        <div className="ex-grid">
          {list.map((e) => (
            <div key={e.key} className="ex-tile" role="button" tabIndex={0} onClick={() => setOpen(e)} onKeyDown={(ev) => (ev.key === 'Enter' || ev.key === ' ') && (ev.preventDefault(), setOpen(e))}>
              <span className={`ex-mono tone-${toneFor(e.muscle_group)}`} aria-hidden>
                {e.name
                  .split(/\s+/)
                  .slice(0, 2)
                  .map((w) => w[0])
                  .join('')
                  .toUpperCase()}
              </span>
              <span className="grow" style={{ minWidth: 0 }}>
                <span className="list-title" style={{ display: 'block' }}>
                  {e.name}
                </span>
                <span className="list-sub" style={{ display: 'block' }}>
                  {e.muscle_group} · {e.equipment} · {e.difficulty}
                </span>
              </span>
              <button
                className={`star-btn ${favorites.has(e.key) ? 'on' : ''}`}
                aria-pressed={favorites.has(e.key)}
                aria-label={favorites.has(e.key) ? `Remove ${e.name} from favorites` : `Add ${e.name} to favorites`}
                onClick={(ev) => {
                  ev.stopPropagation();
                  void toggleFav(e);
                }}
              >
                <Icon name="star" size={20} />
              </button>
            </div>
          ))}
        </div>
      )}

      <Modal
        open={!!open}
        title={open?.name ?? ''}
        onClose={() => setOpen(null)}
        size="md"
        footer={
          open && (
            <>
              {open.custom && (
                <>
                  <Button variant="ghost" icon="trash" onClick={() => removeCustom(open)}>
                    Delete
                  </Button>
                  <Button
                    icon="edit"
                    onClick={() => {
                      const row = data.tables.custom_exercises.find((c) => customKey(c.id) === open.key);
                      if (row) {
                        setEditing(row);
                        setOpen(null);
                      }
                    }}
                  >
                    Edit
                  </Button>
                </>
              )}
              <Button icon="star" variant={favorites.has(open.key) ? 'secondary' : 'primary'} onClick={() => toggleFav(open)} loading={favBusy}>
                {favorites.has(open.key) ? 'Unfavorite' : 'Favorite'}
              </Button>
            </>
          )
        }
      >
        {open && (
          <>
            <div className="row-wrap">
              <Badge tone="accent">{open.muscle_group}</Badge>
              <Badge>{open.equipment}</Badge>
              <Badge tone={open.difficulty === 'Beginner' ? 'success' : open.difficulty === 'Advanced' ? 'danger' : 'warning'}>{open.difficulty}</Badge>
              {open.custom && <Badge tone="violet">Custom</Badge>}
            </div>
            <dl className="kv">
              <div>
                <dt>Recommended sets</dt>
                <dd>{open.sets ?? '–'}</dd>
              </div>
              <div>
                <dt>Reps</dt>
                <dd>{open.reps || '–'}</dd>
              </div>
              <div>
                <dt>Rest</dt>
                <dd>{open.rest_seconds != null ? `${open.rest_seconds}s` : '–'}</dd>
              </div>
              <div>
                <dt>Secondary muscles</dt>
                <dd>{open.secondary_muscles.join(', ') || '–'}</dd>
              </div>
            </dl>
            {open.instructions && (
              <div className="detail-section">
                <h4>How to do it</h4>
                <p>{open.instructions}</p>
              </div>
            )}
            {open.mistakes && (
              <div className="detail-section">
                <h4>Common mistakes</h4>
                <p>{open.mistakes}</p>
              </div>
            )}
            {open.tips && (
              <div className="detail-section">
                <h4>Tips</h4>
                <p>{open.tips}</p>
              </div>
            )}
          </>
        )}
      </Modal>

      <CustomExerciseForm row={editing} onClose={() => setEditing(null)} />
    </div>
  );
}

function blankCustom(): CustomExercise {
  return { id: '', name: '', muscle_group: 'Chest', secondary_muscles: [], equipment: 'Bodyweight', difficulty: 'Beginner', instructions: null, sets: 3, reps: '10', rest_seconds: 60, mistakes: null, tips: null };
}

function CustomExerciseForm({ row, onClose }: { row: CustomExercise | null; onClose: () => void }) {
  const data = useData();
  const [f, setF] = useState<Record<string, string>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [last, setLast] = useState<CustomExercise | null>(null);
  if (row !== last) {
    setLast(row);
    setErrors({});
    if (row)
      setF({
        name: row.name,
        muscle_group: row.muscle_group,
        secondary: row.secondary_muscles.join(', '),
        equipment: row.equipment,
        difficulty: row.difficulty,
        instructions: row.instructions ?? '',
        sets: row.sets == null ? '' : String(row.sets),
        reps: row.reps ?? '',
        rest: row.rest_seconds == null ? '' : String(row.rest_seconds),
        mistakes: row.mistakes ?? '',
        tips: row.tips ?? '',
      });
  }
  if (!row) return null;
  const set = (k: string, v: string) => setF((p) => ({ ...p, [k]: v }));

  async function save() {
    if (!row || saving) return;
    const v = new Validator();
    v.required('name', f.name.trim(), 'Please enter a name.');
    const sets = v.number('sets', f.sets, { min: 0, max: 100, int: true, label: 'Sets' });
    const rest = v.number('rest', f.rest, { min: 0, max: 3600, int: true, label: 'Rest' });
    setErrors(v.errors);
    if (!v.ok) return;
    setSaving(true);
    const out: CustomExercise = {
      ...row,
      id: row.id || uuid(),
      name: f.name.trim(),
      muscle_group: f.muscle_group,
      secondary_muscles: f.secondary.split(',').map((s) => s.trim()).filter(Boolean),
      equipment: f.equipment,
      difficulty: f.difficulty,
      instructions: f.instructions.trim() || null,
      sets,
      reps: f.reps.trim() || null,
      rest_seconds: rest,
      mistakes: f.mistakes.trim() || null,
      tips: f.tips.trim() || null,
    };
    const r = await data.save('custom_exercises', out, { toast: row.id ? 'Exercise updated' : 'Custom exercise added' });
    setSaving(false);
    if (r.ok) onClose();
  }

  return (
    <Modal
      open
      title={row.id ? 'Edit exercise' : 'New custom exercise'}
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" loading={saving} onClick={save}>
            Save
          </Button>
        </>
      }
    >
      <Input label="Name" value={f.name} onChange={(e) => set('name', e.target.value)} error={errors.name} />
      <div className="form-grid">
        <Select label="Target muscle" value={f.muscle_group} onChange={(e) => set('muscle_group', e.target.value)}>
          {MUSCLE_GROUPS.map((m) => (
            <option key={m}>{m}</option>
          ))}
        </Select>
        <Select label="Equipment" value={f.equipment} onChange={(e) => set('equipment', e.target.value)}>
          {EQUIPMENT.map((m) => (
            <option key={m}>{m}</option>
          ))}
        </Select>
        <Select label="Difficulty" value={f.difficulty} onChange={(e) => set('difficulty', e.target.value)}>
          <option>Beginner</option>
          <option>Intermediate</option>
          <option>Advanced</option>
        </Select>
        <Input label="Secondary muscles" value={f.secondary} onChange={(e) => set('secondary', e.target.value)} placeholder="comma separated" />
        <NumberInput label="Recommended sets" decimal={false} value={f.sets} onChange={(e) => set('sets', e.target.value)} error={errors.sets} />
        <Input label="Recommended reps" value={f.reps} onChange={(e) => set('reps', e.target.value)} placeholder="e.g. 8–12 or 30 s" />
        <NumberInput label="Rest" suffix="sec" decimal={false} value={f.rest} onChange={(e) => set('rest', e.target.value)} error={errors.rest} />
      </div>
      <Textarea label="Instructions" value={f.instructions} onChange={(e) => set('instructions', e.target.value)} />
      <Textarea label="Common mistakes" value={f.mistakes} onChange={(e) => set('mistakes', e.target.value)} />
      <Textarea label="Tips" value={f.tips} onChange={(e) => set('tips', e.target.value)} />
    </Modal>
  );
}
