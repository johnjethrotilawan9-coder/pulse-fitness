import { useEffect, useMemo, useRef, useState } from 'react';
import { useData, useProfile } from '../hooks/useData';
import { useUnits } from '../hooks/useUnits';
import { useStopwatch, type StopwatchState } from '../hooks/useTimer';
import { useRouter } from '../router';
import { useConfirm } from '../components/ui/Confirm';
import { PageHeader, Card, EmptyState, Stat, Badge, Tabs } from '../components/ui/Misc';
import { Button, IconButton } from '../components/ui/Button';
import { Input, NumberInput, Select, Textarea, Toggle } from '../components/ui/Field';
import { Modal } from '../components/ui/Modal';
import { Icon } from '../components/Icon';
import { BarChart } from '../components/charts/Charts';
import { estimateRunCalories, haversineKm, paceSecPerKm, speedKmh } from '../utils/calc';
import { autoRecords, latestWeight, weeklySeries } from '../utils/stats';
import { endOfMonth, fmtDate, fmtLongDate, isValidISO, nowTime, relativeDay, startOfMonth, startOfWeek, endOfWeek, todayISO, minutesBetween } from '../utils/date';
import { durationInput, fmtDuration, fmtMinutes, fmtNum, parseDuration, cap } from '../utils/format';
import { Validator } from '../utils/validate';
import { uuid } from '../utils/id';
import { primeAudio } from '../utils/sound';
import type { GeoPoint, RunningSession, Split } from '../types';

const ACTIVITY: RunningSession['activity_type'][] = ['run', 'jog', 'walk', 'trail', 'treadmill'];

// ------------------------------------------------------------ live run state
interface LiveRun {
  timer: StopwatchState;
  gps: boolean;
  points: GeoPoint[];
  distKm: number;
  splits: Split[];
  startTime: string;
  date: string;
  plannedId: string | null;
  activity: RunningSession['activity_type'];
}
const LIVE_KEY = 'pulse.liverun.v1';
function loadLive(): LiveRun | null {
  try {
    const r = localStorage.getItem(LIVE_KEY);
    return r ? (JSON.parse(r) as LiveRun) : null;
  } catch {
    return null;
  }
}
function saveLive(l: LiveRun | null) {
  try {
    if (l) localStorage.setItem(LIVE_KEY, JSON.stringify(l));
    else localStorage.removeItem(LIVE_KEY);
  } catch {
    /* ignore */
  }
}

function RouteSvg({ points }: { points: GeoPoint[] }) {
  if (points.length < 2) return null;
  const lats = points.map((p) => p.lat), lngs = points.map((p) => p.lng);
  const [minLat, maxLat, minLng, maxLng] = [Math.min(...lats), Math.max(...lats), Math.min(...lngs), Math.max(...lngs)];
  const W = 300, H = 180, pad = 14;
  const kx = Math.cos(((minLat + maxLat) / 2) * (Math.PI / 180));
  const spanX = (maxLng - minLng) * kx || 1e-6, spanY = maxLat - minLat || 1e-6;
  const scale = Math.min((W - pad * 2) / spanX, (H - pad * 2) / spanY);
  const ox = (W - spanX * scale) / 2, oy = (H - spanY * scale) / 2;
  const d = points.map((p, i) => `${i ? 'L' : 'M'}${(ox + (p.lng - minLng) * kx * scale).toFixed(1)},${(H - oy - (p.lat - minLat) * scale).toFixed(1)}`).join(' ');
  const first = points[0], last = points[points.length - 1];
  const xy = (p: GeoPoint) => [ox + (p.lng - minLng) * kx * scale, H - oy - (p.lat - minLat) * scale];
  return (
    <svg className="route-svg" viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Route map">
      <path d={d} fill="none" strokeWidth={3.5} strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={xy(first)[0]} cy={xy(first)[1]} r={5} fill="var(--success)" />
      <circle cx={xy(last)[0]} cy={xy(last)[1]} r={5} fill="var(--danger)" />
    </svg>
  );
}

// ------------------------------------------------------------ page
export default function RunPage() {
  const data = useData();
  const runs = data.tables.running_sessions;
  const profile = useProfile();
  const u = useUnits();
  const { query, navigate } = useRouter();
  const confirm = useConfirm();
  const today = todayISO();
  const [tab, setTab] = useState<'track' | 'history' | 'stats'>('track');
  const [editing, setEditing] = useState<RunningSession | null>(null);
  const [viewing, setViewing] = useState<RunningSession | null>(null);

  // deep links: ?id=, ?plan=date
  useEffect(() => {
    const id = query.get('id');
    const plan = query.get('plan');
    if (id) {
      const r = runs.find((x) => x.id === id);
      if (r) setViewing(r);
      navigate('/run', { replace: true });
    } else if (plan && isValidISO(plan)) {
      setEditing(blankRun({ date: plan, status: 'planned' }));
      navigate('/run', { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  const done = runs.filter((r) => r.status === 'completed');
  const planned = runs.filter((r) => r.status === 'planned' && r.date >= today).sort((a, b) => a.date.localeCompare(b.date));
  const weekKm = done.filter((r) => r.date >= startOfWeek(today) && r.date <= endOfWeek(today)).reduce((a, r) => a + (r.distance_km ?? 0), 0);
  const monthKm = done.filter((r) => r.date >= startOfMonth(today) && r.date <= endOfMonth(today)).reduce((a, r) => a + (r.distance_km ?? 0), 0);
  const totalSec = done.reduce((a, r) => a + (r.duration_sec ?? 0), 0);

  async function remove(r: RunningSession) {
    const ok = await confirm({ title: 'Delete this run?', message: `${r.route_name || cap(r.activity_type)} on ${fmtDate(r.date)} will be permanently deleted.`, confirmLabel: 'Delete', danger: true });
    if (ok && (await data.remove('running_sessions', r, { toast: 'Run deleted' })).ok) setViewing(null);
  }

  return (
    <div className="stack">
      <PageHeader
        title="Run"
        subtitle={`${fmtNum(u.dist(weekKm), 1)} ${u.d} this week · ${fmtNum(u.dist(monthKm), 1)} ${u.d} this month`}
        actions={
          <>
            <Button icon="calendar" onClick={() => setEditing(blankRun({ status: 'planned', date: today }))}>
              Plan run
            </Button>
            <Button icon="plus" variant="primary" onClick={() => setEditing(blankRun({}))}>
              Log manually
            </Button>
          </>
        }
      />
      <Tabs
        label="Run sections"
        value={tab}
        onChange={setTab}
        tabs={[
          { value: 'track', label: 'Track', icon: 'play' },
          { value: 'history', label: `History (${done.length})`, icon: 'list' },
          { value: 'stats', label: 'Stats & PBs', icon: 'trophy' },
        ]}
      />

      {tab === 'track' && (
        <>
          <LiveTracker planned={planned} />
          {planned.length > 0 && (
            <Card title="Planned runs" icon="calendar" padded={false}>
              <div className="list">
                {planned.map((r) => (
                  <div key={r.id} className="list-item" style={{ cursor: 'default' }}>
                    <span className="list-icon tone-info">
                      <Icon name="clock" size={18} />
                    </span>
                    <button className="grow" style={{ border: 0, background: 'none', textAlign: 'left', cursor: 'pointer', padding: 0, minWidth: 0 }} onClick={() => setEditing(r)}>
                      <span className="list-title" style={{ display: 'block' }}>
                        {r.route_name || `Planned ${r.activity_type}`}
                      </span>
                      <span className="list-sub" style={{ display: 'block' }}>
                        {relativeDay(r.date)}
                        {r.distance_km ? ` · target ${u.fmtDist(r.distance_km, 1)}` : ''}
                      </span>
                    </button>
                    <IconButton icon="trash" label="Delete planned run" size="sm" onClick={() => remove(r)} />
                  </div>
                ))}
              </div>
            </Card>
          )}
        </>
      )}

      {tab === 'history' &&
        (done.length === 0 ? (
          <Card>
            <EmptyState icon="run" title="No runs recorded yet." message="Track a run live (GPS optional) or log one manually." action={<Button variant="primary" icon="plus" onClick={() => setEditing(blankRun({}))}>Log your first run</Button>} />
          </Card>
        ) : (
          <Card padded={false}>
            <div className="list">
              {[...done]
                .sort((a, b) => b.date.localeCompare(a.date) || (b.start_time ?? '').localeCompare(a.start_time ?? ''))
                .map((r) => (
                  <button key={r.id} className="list-item" onClick={() => setViewing(r)}>
                    <span className="list-icon tone-accent">
                      <Icon name="run" size={18} />
                    </span>
                    <span className="grow">
                      <span className="list-title" style={{ display: 'block' }}>
                        {r.route_name || cap(r.activity_type)}
                      </span>
                      <span className="list-sub" style={{ display: 'block' }}>
                        {fmtDate(r.date, { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })} · {fmtDuration(r.duration_sec)}
                      </span>
                    </span>
                    <span className="list-meta">
                      <div className="strong" style={{ color: 'var(--text)' }}>
                        {u.fmtDist(r.distance_km)}
                      </div>
                      <div>{u.fmtPace(r.avg_pace_sec_per_km ?? paceSecPerKm(r.duration_sec, r.distance_km))}</div>
                    </span>
                  </button>
                ))}
            </div>
          </Card>
        ))}

      {tab === 'stats' && <RunStats runs={done} totalSec={totalSec} weekKm={weekKm} monthKm={monthKm} target={profile.weekly_run_km_target} />}

      <RunForm run={editing} onClose={() => setEditing(null)} />

      <Modal
        open={!!viewing}
        title={viewing ? viewing.route_name || cap(viewing.activity_type) : ''}
        onClose={() => setViewing(null)}
        footer={
          viewing && (
            <>
              <Button icon="trash" variant="ghost" onClick={() => remove(viewing)}>
                Delete
              </Button>
              <Button
                icon="edit"
                onClick={() => {
                  setEditing(viewing);
                  setViewing(null);
                }}
              >
                Edit
              </Button>
            </>
          )
        }
      >
        {viewing && (
          <>
            <p className="muted">
              {fmtLongDate(viewing.date)}
              {viewing.start_time ? ` · ${viewing.start_time}${viewing.end_time ? `–${viewing.end_time}` : ''}` : ''}
            </p>
            <div className="grid g2-keep">
              <Stat label="Distance" value={fmtNum(u.dist(viewing.distance_km), 2)} unit={u.d} />
              <Stat label="Time" value={fmtDuration(viewing.duration_sec)} />
              <Stat label="Avg pace" value={u.fmtPace(viewing.avg_pace_sec_per_km ?? paceSecPerKm(viewing.duration_sec, viewing.distance_km))} />
              <Stat label="Avg speed" value={u.fmtSpeed(speedKmh(viewing.duration_sec, viewing.distance_km))} />
              <Stat label="Calories" value={viewing.calories ?? '–'} unit={viewing.calories ? 'kcal' : undefined} />
              <Stat label="Tracking" value={viewing.gps_used ? 'GPS' : 'Manual'} />
            </div>
            {viewing.route && viewing.route.length > 1 && <RouteSvg points={viewing.route} />}
            {viewing.splits && viewing.splits.length > 0 && (
              <div>
                <h4 className="section-title">Splits</h4>
                <table className="table">
                  <thead>
                    <tr>
                      <th>Km</th>
                      <th>Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    {viewing.splits.map((s, i) => (
                      <tr key={i}>
                        <td>{i + 1}</td>
                        <td>{fmtDuration(s.sec)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            {viewing.notes && <p style={{ whiteSpace: 'pre-wrap' }}>{viewing.notes}</p>}
          </>
        )}
      </Modal>
    </div>
  );
}

function blankRun(p: Partial<RunningSession>): RunningSession {
  return {
    id: '',
    date: todayISO(),
    activity_type: 'run',
    status: 'completed',
    start_time: null,
    end_time: null,
    distance_km: null,
    duration_sec: null,
    avg_pace_sec_per_km: null,
    calories: null,
    route_name: null,
    notes: null,
    gps_used: false,
    route: null,
    splits: null,
    ...p,
  };
}

// ------------------------------------------------------------ live tracker
function LiveTracker({ planned }: { planned: RunningSession[] }) {
  const data = useData();
  const profile = useProfile();
  const u = useUnits();
  const confirm = useConfirm();
  const saved = useMemo(loadLive, []);
  const [live, setLive] = useState<LiveRun | null>(saved);
  const sw = useStopwatch(saved?.timer, 500);
  const [gpsWanted, setGpsWanted] = useState(saved?.gps ?? false);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const [accuracy, setAccuracy] = useState<number | null>(null);
  const [finish, setFinish] = useState<RunningSession | null>(null);
  const watchId = useRef<number | null>(null);
  const liveRef = useRef(live);
  liveRef.current = live;
  const swRef = useRef(sw);
  swRef.current = sw;

  const gpsAvailable = typeof navigator !== 'undefined' && 'geolocation' in navigator;

  // persist
  useEffect(() => {
    saveLive(live ? { ...live, timer: sw.state } : null);
  }, [live, sw.state]);

  // GPS watch while running
  useEffect(() => {
    if (!live?.gps || !sw.running || !gpsAvailable) return;
    watchId.current = navigator.geolocation.watchPosition(
      (pos) => {
        setGpsError(null);
        setAccuracy(pos.coords.accuracy);
        if (pos.coords.accuracy > 40) return; // too imprecise
        const p: GeoPoint = { lat: pos.coords.latitude, lng: pos.coords.longitude, t: pos.timestamp, acc: Math.round(pos.coords.accuracy) };
        setLive((l) => {
          if (!l) return l;
          const last = l.points[l.points.length - 1];
          if (!last) return { ...l, points: [p] };
          const d = haversineKm(last, p);
          const dt = (p.t - last.t) / 1000;
          if (d < 0.003) return l; // jitter
          if (dt > 0 && d / dt > 0.012) return { ...l, points: [...l.points.slice(0, -1), p] }; // >43 km/h: GPS jump
          const distKm = l.distKm + d;
          const splits = [...l.splits];
          const elapsed = swRef.current.elapsed / 1000;
          if (Math.floor(distKm) > Math.floor(l.distKm)) {
            const prevTotal = splits.reduce((a, s) => a + s.sec, 0);
            splits.push({ km: 1, sec: Math.round(elapsed - prevTotal) });
          }
          return { ...l, points: [...l.points, p], distKm, splits };
        });
      },
      (err) => setGpsError(err.code === err.PERMISSION_DENIED ? 'Location permission denied — distance will be entered manually.' : 'Waiting for GPS signal…'),
      { enableHighAccuracy: true, maximumAge: 2000, timeout: 20000 },
    );
    return () => {
      if (watchId.current !== null) navigator.geolocation.clearWatch(watchId.current);
    };
  }, [live?.gps, sw.running, gpsAvailable]);

  // wake lock while running
  useEffect(() => {
    if (!sw.running) return;
    let lock: { release: () => Promise<void> } | null = null;
    const nav = navigator as Navigator & { wakeLock?: { request: (t: 'screen') => Promise<{ release: () => Promise<void> }> } };
    nav.wakeLock?.request('screen').then((l) => (lock = l)).catch(() => undefined);
    return () => void lock?.release().catch(() => undefined);
  }, [sw.running]);

  function start(plannedRun?: RunningSession) {
    primeAudio();
    setLive({ timer: { startedAt: null, accumulated: 0 }, gps: gpsWanted && gpsAvailable, points: [], distKm: 0, splits: [], startTime: nowTime(), date: todayISO(), plannedId: plannedRun?.id ?? null, activity: plannedRun?.activity_type ?? 'run' });
    sw.reset();
    setTimeout(() => sw.start(), 0);
  }

  function stop() {
    sw.pause();
    const l = liveRef.current;
    if (!l) return;
    const sec = Math.round(sw.elapsed / 1000);
    const dist = l.distKm > 0 ? Math.round(l.distKm * 1000) / 1000 : null;
    const weight = latestWeight(data.tables.body_measurements)?.value ?? profile.weight_kg;
    const plannedRun = l.plannedId ? data.tables.running_sessions.find((r) => r.id === l.plannedId) : undefined;
    setFinish({
      ...blankRun({}),
      ...(plannedRun ?? {}),
      id: plannedRun?.id ?? '',
      status: 'completed',
      date: l.date,
      activity_type: l.activity,
      start_time: l.startTime,
      end_time: nowTime(),
      duration_sec: sec,
      distance_km: dist,
      calories: estimateRunCalories(l.activity, dist, weight),
      gps_used: l.gps && l.points.length > 1,
      route: l.points.length > 1 ? l.points.map((p) => ({ lat: Math.round(p.lat * 1e6) / 1e6, lng: Math.round(p.lng * 1e6) / 1e6, t: p.t })) : null,
      splits: l.splits.length ? l.splits : null,
    });
  }

  async function discard() {
    if (!(await confirm({ title: 'Discard this run?', message: 'The timer and any GPS track will be cleared.', confirmLabel: 'Discard', danger: true }))) return;
    setLive(null);
    sw.reset();
    setFinish(null);
  }

  const elapsedSec = sw.elapsed / 1000;
  const avgPace = live && live.distKm > 0.01 ? elapsedSec / live.distKm : null;
  const currentPace = useMemo(() => {
    if (!live || live.points.length < 3) return null;
    const pts = live.points;
    const lastT = pts[pts.length - 1].t;
    let d = 0, i = pts.length - 1;
    while (i > 0 && lastT - pts[i - 1].t <= 30000) {
      d += haversineKm(pts[i - 1], pts[i]);
      i--;
    }
    const dt = (lastT - pts[i].t) / 1000;
    return d > 0.01 && dt > 5 ? dt / d : null;
  }, [live]);
  const weight = latestWeight(data.tables.body_measurements)?.value ?? profile.weight_kg;

  if (!live)
    return (
      <Card>
        <div className="run-live">
          <div className="big-timer" aria-hidden>
            0:00
          </div>
          <p className="muted">Start a live run. Distance comes from GPS if you allow it — otherwise you can enter it when you finish.</p>
          {gpsAvailable ? (
            <div style={{ maxWidth: 420, margin: '0 auto', width: '100%', textAlign: 'left' }}>
              <Toggle label="Track with GPS" description="Needs location permission. Keep the screen on — most phone browsers pause GPS when locked." checked={gpsWanted} onChange={setGpsWanted} />
            </div>
          ) : (
            <p className="small faint">GPS isn't available on this device/browser — manual distance entry will be used.</p>
          )}
          <div className="timer-controls">
            <Button size="lg" variant="primary" icon="play" onClick={() => start()}>
              Start run
            </Button>
          </div>
          {planned.filter((p) => p.date === todayISO()).map((p) => (
            <Button key={p.id} icon="play" onClick={() => start(p)}>
              Start planned: {p.route_name || `${p.activity_type}`}
            </Button>
          ))}
        </div>
      </Card>
    );

  return (
    <Card>
      <div className="run-live">
        <div className="row between">
          <Badge tone={sw.running ? 'accent' : 'warning'} icon={sw.running ? 'play' : 'pause'}>
            {sw.running ? 'Recording' : 'Paused'}
          </Badge>
          <Select label="Activity" hideLabel value={live.activity} onChange={(e) => setLive({ ...live, activity: e.target.value as RunningSession['activity_type'] })} style={{ height: 36, width: 130 }}>
            {ACTIVITY.map((a) => (
              <option key={a} value={a}>
                {cap(a)}
              </option>
            ))}
          </Select>
        </div>
        <div className="big-timer" role="timer" aria-label="Elapsed time">
          {fmtDuration(Math.floor(elapsedSec))}
        </div>
        <div className="run-metrics">
          <div className="run-metric">
            <div className="v">{live.gps ? fmtNum(u.dist(live.distKm), 2) : '—'}</div>
            <div className="l">Distance ({u.d})</div>
          </div>
          <div className="run-metric">
            <div className="v">{live.gps ? u.fmtPace(avgPace).replace(/ \/(km|mi)/, '') : '—'}</div>
            <div className="l">Avg pace /{u.d}</div>
          </div>
          <div className="run-metric">
            <div className="v">{live.gps ? u.fmtPace(currentPace).replace(/ \/(km|mi)/, '') : '—'}</div>
            <div className="l">Current pace</div>
          </div>
        </div>
        <div className="small muted">
          Est. calories: {live.gps && live.distKm > 0 ? estimateRunCalories(live.activity, live.distKm, weight) : '—'}
          {live.gps && accuracy != null && ` · GPS ±${Math.round(accuracy)} m`}
        </div>
        {gpsError && <div className="alert alert-warning">{gpsError}</div>}
        {live.gps && live.points.length > 1 && <RouteSvg points={live.points} />}
        <div className="timer-controls">
          {sw.running ? (
            <Button size="lg" icon="pause" onClick={sw.pause}>
              Pause
            </Button>
          ) : (
            <Button size="lg" variant="primary" icon="play" onClick={sw.start}>
              Resume
            </Button>
          )}
          <Button size="lg" variant="danger" icon="stop" onClick={stop}>
            Stop
          </Button>
        </div>
        <button className="link-btn" onClick={discard}>
          Discard run
        </button>
      </div>
      <RunForm
        run={finish}
        onClose={() => setFinish(null)}
        onSaved={() => {
          setLive(null);
          sw.reset();
        }}
        title="Save your run"
      />
    </Card>
  );
}

// ------------------------------------------------------------ add / edit form
function RunForm({ run, onClose, onSaved, title }: { run: RunningSession | null; onClose: () => void; onSaved?: () => void; title?: string }) {
  const data = useData();
  const profile = useProfile();
  const u = useUnits();
  const [f, setF] = useState<Record<string, string> & { activity_type: RunningSession['activity_type']; status: RunningSession['status'] }>({} as never);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [last, setLast] = useState<RunningSession | null>(null);
  if (run !== last) {
    setLast(run);
    setErrors({});
    if (run)
      setF({
        date: run.date,
        activity_type: run.activity_type,
        status: run.status,
        start_time: run.start_time ?? '',
        end_time: run.end_time ?? '',
        distance: run.distance_km == null ? '' : String(u.dist(run.distance_km)),
        duration: durationInput(run.duration_sec),
        pace: '',
        calories: run.calories == null ? '' : String(run.calories),
        route_name: run.route_name ?? '',
        notes: run.notes ?? '',
      });
  }
  if (!run) return null;
  const isPlanned = f.status === 'planned';

  const weight = latestWeight(data.tables.body_measurements)?.value ?? profile.weight_kg;

  async function save() {
    if (!run || saving) return;
    const v = new Validator();
    v.date('date', f.date);
    const dist = v.number('distance', f.distance, { min: 0, max: 1000, label: 'Distance' });
    let dur = parseDuration(f.duration);
    if (dur === undefined) v.check('duration', false, 'Use h:mm:ss, mm:ss or minutes.');
    const paceSec = parseDuration(f.pace);
    if (paceSec === undefined) v.check('pace', false, 'Use m:ss per ' + u.d + '.');
    const cal = v.number('calories', f.calories, { min: 0, max: 20000, int: true, label: 'Calories' });
    let distKm = u.fromDist(dist);
    // pace is typed as minutes:seconds, parseDuration treats 'm:ss' correctly; plain numbers mean minutes
    const paceKm = paceSec ? (u.d === 'mi' ? paceSec / 1.609344 : paceSec) : null;
    if (dur == null && paceKm && distKm) dur = Math.round(paceKm * distKm);
    if (!distKm && paceKm && dur) distKm = Math.round((dur / paceKm) * 1000) / 1000;
    if (!dur && f.start_time && f.end_time) dur = (minutesBetween(f.start_time, f.end_time) ?? 0) * 60 || null;
    if (!isPlanned) {
      v.check('distance', !!distKm || !!dur, 'Enter a distance or a duration.');
      if (dur != null) v.check('duration', dur > 0 && dur < 86400 * 2, 'Duration must be positive.');
    }
    setErrors(v.errors);
    if (!v.ok) return;
    setSaving(true);
    const row: RunningSession = {
      ...run,
      id: run.id || uuid(),
      date: f.date,
      activity_type: f.activity_type,
      status: f.status,
      start_time: f.start_time || null,
      end_time: f.end_time || null,
      distance_km: distKm ?? null,
      duration_sec: dur ?? null,
      avg_pace_sec_per_km: paceSecPerKm(dur ?? null, distKm ?? null),
      calories: cal ?? (isPlanned ? null : estimateRunCalories(f.activity_type, distKm ?? null, weight)),
      route_name: f.route_name.trim() || null,
      notes: f.notes.trim() || null,
    };
    const r = await data.save('running_sessions', row, { toast: isPlanned ? 'Run planned' : run.id ? 'Run updated' : 'Run saved 🏃' });
    setSaving(false);
    if (r.ok) {
      onSaved?.();
      onClose();
    }
  }

  const set = (k: string, val: string) => setF((p) => ({ ...p, [k]: val }));
  const previewPace = (() => {
    const d = u.fromDist(Number(f.distance?.replace(',', '.')) || null);
    const s = parseDuration(f.duration ?? '');
    return s && d ? paceSecPerKm(s, d) : null;
  })();

  return (
    <Modal
      open
      title={title ?? (run.id ? 'Edit run' : isPlanned ? 'Plan a run' : 'Log a run')}
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" icon="check" loading={saving} onClick={save}>
            Save
          </Button>
        </>
      }
    >
      <div className="form-grid">
        <Input label="Date" type="date" value={f.date} onChange={(e) => set('date', e.target.value)} error={errors.date} />
        <Select label="Status" value={f.status} onChange={(e) => set('status', e.target.value)}>
          <option value="completed">Completed</option>
          <option value="planned">Planned</option>
          <option value="skipped">Skipped</option>
        </Select>
        <Select label="Activity" value={f.activity_type} onChange={(e) => set('activity_type', e.target.value)}>
          {ACTIVITY.map((a) => (
            <option key={a} value={a}>
              {cap(a)}
            </option>
          ))}
        </Select>
        <Input label="Route name" value={f.route_name} onChange={(e) => set('route_name', e.target.value)} placeholder="e.g. Park loop" />
        <NumberInput label={isPlanned ? 'Target distance' : 'Distance'} suffix={u.d} value={f.distance} onChange={(e) => set('distance', e.target.value)} error={errors.distance} />
        <Input label="Duration" value={f.duration} onChange={(e) => set('duration', e.target.value)} error={errors.duration} placeholder="h:mm:ss or minutes" inputMode="numeric" />
        {!isPlanned && (
          <Input label={`Pace (optional)`} value={f.pace} onChange={(e) => set('pace', e.target.value)} error={errors.pace} placeholder={`m:ss /${u.d}`} hint={previewPace ? `Calculated: ${u.fmtPace(previewPace)}` : 'Used to fill distance or duration if one is missing'} />
        )}
        {!isPlanned && <NumberInput label="Calories" suffix="kcal" decimal={false} value={f.calories} onChange={(e) => set('calories', e.target.value)} error={errors.calories} hint="Leave blank to estimate" />}
        <Input label="Start time" type="time" value={f.start_time} onChange={(e) => set('start_time', e.target.value)} />
        <Input label="End time" type="time" value={f.end_time} onChange={(e) => set('end_time', e.target.value)} />
      </div>
      <Textarea label="Notes" value={f.notes} onChange={(e) => set('notes', e.target.value)} placeholder="How did it feel? Weather, shoes, route…" />
    </Modal>
  );
}

// ------------------------------------------------------------ stats
function RunStats({ runs, totalSec, weekKm, monthKm, target }: { runs: RunningSession[]; totalSec: number; weekKm: number; monthKm: number; target: number }) {
  const u = useUnits();
  const { workouts } = useData();
  const series = weeklySeries(10, (from, to) => u.dist(runs.filter((r) => r.date >= from && r.date <= to).reduce((a, r) => a + (r.distance_km ?? 0), 0)) ?? 0);
  const prs = autoRecords(workouts, runs).general.filter((p) => ['longest-run', 'fastest-1k', 'fastest-5k'].includes(p.id));
  const fastestPace = runs.filter((r) => (r.distance_km ?? 0) >= 1 && r.duration_sec).map((r) => ({ r, p: paceSecPerKm(r.duration_sec, r.distance_km)! })).sort((a, b) => a.p - b.p)[0];
  const totalKm = runs.reduce((a, r) => a + (r.distance_km ?? 0), 0);

  if (!runs.length) return <Card><EmptyState icon="trophy" title="No stats yet" message="Your distances, pace and personal bests appear after your first run." /></Card>;

  return (
    <div className="stack">
      <div className="grid g4">
        <div className="card stat-card"><Stat label="This week" icon="run" value={fmtNum(u.dist(weekKm), 1)} unit={u.d} sub={`target ${fmtNum(u.dist(target), 0)} ${u.d}`} /></div>
        <div className="card stat-card"><Stat label="This month" icon="calendar" tone="info" value={fmtNum(u.dist(monthKm), 1)} unit={u.d} /></div>
        <div className="card stat-card"><Stat label="Total distance" icon="pin" tone="success" value={fmtNum(u.dist(totalKm), 1)} unit={u.d} sub={`${runs.length} runs`} /></div>
        <div className="card stat-card"><Stat label="Total time" icon="clock" tone="violet" value={fmtMinutes(totalSec / 60)} /></div>
      </div>
      <Card title={`Weekly distance (${u.d})`} icon="chart">
        <BarChart data={series} digits={1} unit={u.d} target={u.dist(target)} ariaLabel="Weekly running distance, last 10 weeks" />
      </Card>
      <Card title="Personal bests" icon="trophy" padded={false}>
        <div className="list">
          {prs.map((p) => (
            <div key={p.id} className="list-item" style={{ cursor: 'default' }}>
              <span className="list-icon tone-warning"><Icon name="trophy" size={18} /></span>
              <span className="grow">
                <span className="list-title" style={{ display: 'block' }}>{p.title}</span>
                <span className="list-sub" style={{ display: 'block' }}>{fmtDate(p.date, { month: 'short', day: 'numeric', year: 'numeric' })}{p.detail ? ` · ${p.detail}` : ''}</span>
              </span>
              <span className="list-meta strong" style={{ color: 'var(--text)', fontSize: 16 }}>
                {p.kind === 'distance' ? u.fmtDist(p.value) : fmtDuration(p.value)}
              </span>
            </div>
          ))}
          {fastestPace && (
            <div className="list-item" style={{ cursor: 'default' }}>
              <span className="list-icon tone-warning"><Icon name="zap" size={18} /></span>
              <span className="grow">
                <span className="list-title" style={{ display: 'block' }}>Fastest average pace</span>
                <span className="list-sub" style={{ display: 'block' }}>{fmtDate(fastestPace.r.date, { month: 'short', day: 'numeric', year: 'numeric' })} · {u.fmtDist(fastestPace.r.distance_km)}</span>
              </span>
              <span className="list-meta strong" style={{ color: 'var(--text)', fontSize: 16 }}>{u.fmtPace(fastestPace.p)}</span>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}
