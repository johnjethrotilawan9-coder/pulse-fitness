import { useEffect, useMemo, useState } from 'react';
import { useData, useProfile } from '../hooks/useData';
import { useRouter } from '../router';
import { useConfirm } from '../components/ui/Confirm';
import { PageHeader, Card, Badge, EmptyState, Tabs } from '../components/ui/Misc';
import { Button, IconButton } from '../components/ui/Button';
import { Input, NumberInput, Select, Textarea, Toggle, ChipSelect } from '../components/ui/Field';
import { Modal } from '../components/ui/Modal';
import { Icon } from '../components/Icon';
import { ExercisePicker } from '../components/workout/ExercisePicker';
import { BUILTIN_PROGRAMS } from '../data/programs';
import { GOALS, GOAL_BY_ID, WORKOUT_TYPES } from '../data/goals';
import { addDays, fmtDate, isValidISO, todayISO } from '../utils/date';
import { uuid } from '../utils/id';
import { label } from '../utils/format';
import { workoutFromProgramDay } from '../utils/workout';
import { Validator } from '../utils/validate';
import type { CalendarEvent, ProgramDay, Workout, WorkoutProgram } from '../types';

export default function ProgramsPage() {
  const data = useData();
  const profile = useProfile();
  const { query, navigate } = useRouter();
  const confirm = useConfirm();
  const [tab, setTab] = useState<'goals' | 'programs'>(profile.goals.length ? 'programs' : 'goals');
  const [goalFilter, setGoalFilter] = useState('all');
  const [open, setOpen] = useState<WorkoutProgram | null>(null);
  const [scheduling, setScheduling] = useState<WorkoutProgram | null>(null);
  const [editing, setEditing] = useState<WorkoutProgram | null>(null);
  const [savingGoals, setSavingGoals] = useState(false);
  const startParam = query.get('start');

  const all = useMemo(() => [...data.tables.workout_programs, ...BUILTIN_PROGRAMS], [data.tables.workout_programs]);

  useEffect(() => {
    const id = query.get('id');
    if (id) {
      const p = all.find((x) => x.id === id);
      if (p) {
        setOpen(p);
        setTab('programs');
      }
      navigate('/programs', { replace: true });
    } else if (startParam) setTab('programs');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  const recommended = new Set(profile.goals.flatMap((g) => GOAL_BY_ID[g]?.programs ?? []).map((id) => `builtin:${id}`));
  const list = all.filter((p) => goalFilter === 'all' || (goalFilter === 'recommended' ? recommended.has(p.id) : goalFilter === 'custom' ? !p.builtin : p.goal === goalFilter));

  async function saveGoals(goals: string[]) {
    setSavingGoals(true);
    await data.saveProfile({ goals }, { toast: 'Goals updated' });
    setSavingGoals(false);
  }

  async function removeProgram(p: WorkoutProgram) {
    if (!(await confirm({ title: 'Delete program?', message: `“${p.name}” will be deleted. Workouts already added to your calendar are kept.`, confirmLabel: 'Delete', danger: true }))) return;
    if ((await data.remove('workout_programs', p, { toast: 'Program deleted' })).ok) setOpen(null);
  }

  return (
    <div className="stack">
      <PageHeader title="Goals & programs" subtitle="Pick your goals, then follow a plan" actions={<Button variant="primary" icon="plus" onClick={() => setEditing(blankProgram())}>Create program</Button>} />
      {startParam && isValidISO(startParam) && <div className="alert alert-info"><Icon name="calendar" size={18} /> Choose a program to schedule starting {fmtDate(startParam, { weekday: 'long', month: 'short', day: 'numeric' })}.</div>}
      <Tabs
        label="Sections"
        value={tab}
        onChange={setTab}
        tabs={[
          { value: 'goals', label: 'My goals', icon: 'target' },
          { value: 'programs', label: 'Programs', icon: 'layers' },
        ]}
      />

      {tab === 'goals' && (
        <>
          <Card title="What are you working toward?" icon="target">
            <ChipSelect label="Choose one or more goals" values={profile.goals} options={GOALS.map((g) => g.id)} onChange={(v) => void saveGoals(v)} />
            {savingGoals && <p className="xs muted" style={{ marginTop: 8 }}>Saving…</p>}
          </Card>
          {profile.goals.length === 0 ? (
            <EmptyState icon="target" title="No goals selected" message="Select a goal above to see a suggested weekly plan and matching programs." />
          ) : (
            profile.goals.map((gid) => {
              const g = GOAL_BY_ID[gid];
              if (!g) return null;
              return (
                <Card key={g.id} title={g.label} icon="flag">
                  <div className="stack-sm">
                    <p>{g.plan}</p>
                    <h4 className="section-title">Suggested week</h4>
                    <ul className="stack-sm">
                      {g.weekly.map((w) => (
                        <li key={w} className="row" style={{ alignItems: 'flex-start' }}>
                          <Icon name="check" size={16} className="success-text" style={{ marginTop: 3, flexShrink: 0 }} />
                          <span>{w}</span>
                        </li>
                      ))}
                    </ul>
                    <h4 className="section-title">Matching programs</h4>
                    <div className="row-wrap">
                      {g.programs.map((pid) => {
                        const p = BUILTIN_PROGRAMS.find((x) => x.id === `builtin:${pid}`);
                        return p ? (
                          <Button key={pid} size="sm" icon="layers" onClick={() => setOpen(p)}>
                            {p.name}
                          </Button>
                        ) : null;
                      })}
                    </div>
                  </div>
                </Card>
              );
            })
          )}
          <p className="xs faint">These are general fitness suggestions, not medical advice. Check with a health professional before starting a new program if you have health concerns.</p>
        </>
      )}

      {tab === 'programs' && (
        <>
          <div className="chip-scroll">
            {[['all', 'All'], ['recommended', '★ For my goals'], ['custom', 'My programs'], ...[...new Set(BUILTIN_PROGRAMS.map((p) => p.goal!))].map((g) => [g, g])].map(([v, l]) => (
              <button key={v} className={`chip ${goalFilter === v ? 'chip-on' : ''}`} aria-pressed={goalFilter === v} onClick={() => setGoalFilter(v)}>
                {l}
              </button>
            ))}
          </div>
          {list.length === 0 ? (
            <EmptyState icon="layers" title={goalFilter === 'custom' ? 'No custom programs yet' : goalFilter === 'recommended' ? 'Pick a goal first' : 'No programs'} action={goalFilter === 'custom' ? <Button variant="primary" icon="plus" onClick={() => setEditing(blankProgram())}>Create program</Button> : goalFilter === 'recommended' ? <Button onClick={() => setTab('goals')}>Choose goals</Button> : undefined} />
          ) : (
            <div className="grid g3">
              {list.map((p) => (
                <button key={p.id} className="card program-card" onClick={() => setOpen(p)}>
                  <div className="row between" style={{ width: '100%' }}>
                    <span className="strong" style={{ fontSize: 16 }}>
                      {p.name}
                    </span>
                    {!p.builtin && <Badge tone="violet">Custom</Badge>}
                    {recommended.has(p.id) && <Badge tone="accent">★ Goal</Badge>}
                  </div>
                  <span className="small muted" style={{ display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                    {p.description}
                  </span>
                  <div className="program-days" aria-label={`${p.days_per_week} training days`}>
                    {p.days.map((d, i) => (
                      <span key={i} className={d.type === 'rest' ? 'rest' : ''} />
                    ))}
                  </div>
                  <div className="row-wrap">
                    {p.level && <Badge>{p.level}</Badge>}
                    <Badge tone="info">{p.days_per_week} day{p.days_per_week === 1 ? '' : 's'}{p.days.length === 7 ? '/week' : ''}</Badge>
                    {p.goal && <Badge tone="success">{p.goal}</Badge>}
                  </div>
                </button>
              ))}
            </div>
          )}
        </>
      )}

      <Modal
        open={!!open}
        title={open?.name ?? ''}
        size="lg"
        onClose={() => setOpen(null)}
        footer={
          open && (
            <>
              {!open.builtin && (
                <>
                  <Button variant="ghost" icon="trash" onClick={() => removeProgram(open)}>
                    Delete
                  </Button>
                  <Button icon="edit" onClick={() => { setEditing(open); setOpen(null); }}>
                    Edit
                  </Button>
                </>
              )}
              {open.builtin && (
                <Button icon="copy" onClick={() => { setEditing({ ...open, id: '', builtin: false, name: `${open.name} (my version)` }); setOpen(null); }}>
                  Customize
                </Button>
              )}
              <Button variant="primary" icon="calendar" onClick={() => { setScheduling(open); setOpen(null); }}>
                Add to calendar
              </Button>
            </>
          )
        }
      >
        {open && (
          <>
            <p>{open.description}</p>
            <div className="row-wrap">
              {open.level && <Badge>{open.level}</Badge>}
              {open.goal && <Badge tone="success">{open.goal}</Badge>}
              <Badge tone="info">{open.days_per_week} training days</Badge>
            </div>
            {open.days.map((d, i) => (
              <div key={i} className="ex-card">
                <div className="row between">
                  <div>
                    <div className="strong">
                      {open.days.length > 1 ? `Day ${i + 1}: ` : ''}
                      {d.name}
                    </div>
                    <div className="small muted">{d.focus}</div>
                  </div>
                  <Badge tone={d.type === 'rest' ? 'violet' : 'accent'}>{d.type === 'rest' ? 'Rest' : label(d.type)}</Badge>
                </div>
                {d.exercises.length > 0 && (
                  <ul className="small" style={{ display: 'grid', gap: 4 }}>
                    {d.exercises.map((e, j) => (
                      <li key={j} className="row between">
                        <span>{e.name}</span>
                        <span className="muted nowrap">
                          {e.sets} × {e.reps}
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </>
        )}
      </Modal>

      <ScheduleDialog program={scheduling} initialStart={startParam && isValidISO(startParam) ? startParam : undefined} onClose={() => setScheduling(null)} />
      <ProgramEditor program={editing} onClose={() => setEditing(null)} />
    </div>
  );
}

function blankProgram(): WorkoutProgram {
  return { id: '', name: '', description: '', goal: null, level: 'Beginner', days_per_week: 1, days: [{ name: 'Day 1', focus: '', type: 'strength', exercises: [] }] };
}

// ------------------------------------------------------------ schedule
function ScheduleDialog({ program, initialStart, onClose }: { program: WorkoutProgram | null; initialStart?: string; onClose: () => void }) {
  const data = useData();
  const { navigate } = useRouter();
  const [start, setStart] = useState(todayISO());
  const [weeks, setWeeks] = useState('4');
  const [rest, setRest] = useState(true);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [last, setLast] = useState<WorkoutProgram | null>(null);
  if (program !== last) {
    setLast(program);
    setStart(initialStart ?? todayISO());
    setWeeks(program && program.days.length === 1 ? '1' : '4');
    setErr(null);
  }
  if (!program) return null;
  const single = program.days.length < 7;
  const nWeeks = Math.max(1, Math.min(16, Number(weeks) || 1));
  const training = program.days.filter((d) => d.type !== 'rest').length;

  async function go() {
    if (!program || busy) return;
    if (!isValidISO(start)) return setErr('Please choose a valid start date.');
    const w = Number(weeks);
    if (!Number.isInteger(w) || w < 1 || w > 16) return setErr('Weeks must be between 1 and 16.');
    setBusy(true);
    const workouts: Workout[] = [];
    const events: CalendarEvent[] = [];
    for (let wk = 0; wk < w; wk++) {
      program.days.forEach((d, i) => {
        const date = addDays(start, wk * 7 + i);
        if (d.type === 'rest') {
          if (rest) events.push({ id: uuid(), date, title: d.name || 'Rest day', event_type: 'rest', start_time: null, notes: `${program.name}`, completed: false });
        } else workouts.push(workoutFromProgramDay(d, date, program.name));
      });
    }
    const r1 = await data.saveWorkouts(workouts);
    const r2 = events.length ? await data.saveMany('calendar_events', events) : { ok: true };
    setBusy(false);
    if (r1.ok && r2.ok) {
      onClose();
      navigate(`/calendar?date=${start}`);
    }
  }

  return (
    <Modal
      open
      title={`Schedule “${program.name}”`}
      size="sm"
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" icon="calendar" loading={busy} onClick={go}>
            Add {training * nWeeks} workout{training * nWeeks === 1 ? '' : 's'}
          </Button>
        </>
      }
    >
      <Input label="Start date" type="date" value={start} onChange={(e) => setStart(e.target.value)} />
      <NumberInput label="Repeat for" suffix="weeks" decimal={false} value={weeks} onChange={(e) => setWeeks(e.target.value)} hint={single ? 'The session(s) repeat once a week on the same weekday.' : 'Each program week runs 7 days from the start date.'} />
      {program.days.some((d) => d.type === 'rest') && <Toggle label="Add rest days to calendar" checked={rest} onChange={setRest} />}
      {err && <p className="field-msg">{err}</p>}
    </Modal>
  );
}

// ------------------------------------------------------------ builder
function ProgramEditor({ program, onClose }: { program: WorkoutProgram | null; onClose: () => void }) {
  const data = useData();
  const [p, setP] = useState<WorkoutProgram | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [pickerDay, setPickerDay] = useState<number | null>(null);
  const [last, setLast] = useState<WorkoutProgram | null>(null);
  if (program !== last) {
    setLast(program);
    setP(program ? JSON.parse(JSON.stringify(program)) : null);
    setErrors({});
  }
  if (!p) return null;

  const setDay = (i: number, d: Partial<ProgramDay>) => setP({ ...p, days: p.days.map((x, j) => (j === i ? { ...x, ...d } : x)) });

  async function save() {
    if (!p || saving) return;
    const v = new Validator();
    v.required('name', p.name.trim(), 'Please name your program.');
    v.check('days', p.days.length > 0, 'Add at least one day.');
    p.days.forEach((d, i) => {
      v.required(`day${i}`, d.name.trim(), 'Each day needs a name.');
      d.exercises.forEach((e, j) => {
        if (!Number.isInteger(e.sets) || e.sets < 1 || e.sets > 50) v.check(`ex${i}-${j}`, false, 'Sets must be 1–50.');
        if (!Number.isInteger(e.rest_seconds) || e.rest_seconds < 0 || e.rest_seconds > 3600) v.check(`ex${i}-${j}`, false, 'Rest must be 0–3600 seconds.');
      });
    });
    setErrors(v.errors);
    if (!v.ok) return;
    setSaving(true);
    const { builtin: _b, ...rest } = p;
    const row: WorkoutProgram = { ...rest, id: p.id || uuid(), name: p.name.trim(), days_per_week: Math.max(1, Math.min(7, p.days.filter((d) => d.type !== 'rest').length)) };
    const r = await data.save('workout_programs', row, { toast: p.id ? 'Program updated' : 'Program created' });
    setSaving(false);
    if (r.ok) onClose();
  }

  return (
    <Modal
      open
      size="lg"
      title={p.id ? 'Edit program' : 'Create program'}
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" loading={saving} onClick={save}>
            Save program
          </Button>
        </>
      }
    >
      <div className="form-grid">
        <Input label="Program name" className="full" value={p.name} onChange={(e) => setP({ ...p, name: e.target.value })} error={errors.name} />
        <Select label="Goal" value={p.goal ?? ''} onChange={(e) => setP({ ...p, goal: e.target.value || null })}>
          <option value="">—</option>
          {GOALS.map((g) => (
            <option key={g.id}>{g.id}</option>
          ))}
        </Select>
        <Select label="Level" value={p.level ?? ''} onChange={(e) => setP({ ...p, level: e.target.value || null })}>
          <option>Beginner</option>
          <option>Intermediate</option>
          <option>Advanced</option>
        </Select>
      </div>
      <Textarea label="Description" value={p.description ?? ''} onChange={(e) => setP({ ...p, description: e.target.value })} />
      <p className="small muted">Add up to 7 days. A 7-day program repeats weekly; include rest days to keep the weekly rhythm.</p>
      {errors.days && <p className="field-msg">{errors.days}</p>}
      {p.days.map((d, i) => (
        <div key={i} className="ex-card">
          <div className="row">
            <span className="set-num">{i + 1}</span>
            <input className="input grow" style={{ height: 40 }} value={d.name} aria-label={`Day ${i + 1} name`} onChange={(e) => setDay(i, { name: e.target.value })} />
            <select className="input select" style={{ height: 40, width: 130 }} value={d.type} aria-label={`Day ${i + 1} type`} onChange={(e) => setDay(i, { type: e.target.value, exercises: e.target.value === 'rest' ? [] : d.exercises })}>
              <option value="rest">Rest</option>
              {WORKOUT_TYPES.map((t) => (
                <option key={t} value={t}>
                  {label(t)}
                </option>
              ))}
            </select>
            <IconButton icon="trash" label={`Remove day ${i + 1}`} size="sm" onClick={() => setP({ ...p, days: p.days.filter((_, j) => j !== i) })} />
          </div>
          {errors[`day${i}`] && <p className="field-msg">{errors[`day${i}`]}</p>}
          {d.type !== 'rest' && (
            <>
              <input className="input" style={{ height: 38, fontSize: 14 }} placeholder="Focus (e.g. Chest & triceps)" aria-label={`Day ${i + 1} focus`} value={d.focus} onChange={(e) => setDay(i, { focus: e.target.value })} />
              {d.exercises.map((e, j) => (
                <div key={j}>
                  <div className="row" style={{ gap: 6 }}>
                    <span className="grow small strong ellipsis">{e.name}</span>
                    <input className="input" style={{ width: 52, height: 36, textAlign: 'center', padding: 0 }} inputMode="numeric" aria-label={`${e.name} sets`} value={e.sets} onChange={(ev) => setDay(i, { exercises: d.exercises.map((x, k) => (k === j ? { ...x, sets: Number(ev.target.value.replace(/\D/g, '')) || 0 } : x)) })} />
                    <span className="xs muted">×</span>
                    <input className="input" style={{ width: 72, height: 36, textAlign: 'center', padding: 0 }} aria-label={`${e.name} reps`} value={e.reps} onChange={(ev) => setDay(i, { exercises: d.exercises.map((x, k) => (k === j ? { ...x, reps: ev.target.value } : x)) })} />
                    <input className="input" style={{ width: 60, height: 36, textAlign: 'center', padding: 0 }} inputMode="numeric" aria-label={`${e.name} rest seconds`} title="Rest (s)" value={e.rest_seconds} onChange={(ev) => setDay(i, { exercises: d.exercises.map((x, k) => (k === j ? { ...x, rest_seconds: Number(ev.target.value.replace(/\D/g, '')) || 0 } : x)) })} />
                    <IconButton icon="x" label={`Remove ${e.name}`} size="sm" onClick={() => setDay(i, { exercises: d.exercises.filter((_, k) => k !== j) })} />
                  </div>
                  {errors[`ex${i}-${j}`] && <p className="field-msg">{errors[`ex${i}-${j}`]}</p>}
                </div>
              ))}
              {d.exercises.length > 0 && <p className="xs faint">sets × reps · rest (s)</p>}
              <Button size="sm" icon="plus" onClick={() => setPickerDay(i)}>
                Add exercises
              </Button>
            </>
          )}
        </div>
      ))}
      {p.days.length < 7 && (
        <Button icon="plus" onClick={() => setP({ ...p, days: [...p.days, { name: `Day ${p.days.length + 1}`, focus: '', type: 'strength', exercises: [] }] })}>
          Add day
        </Button>
      )}
      <ExercisePicker
        open={pickerDay !== null}
        onClose={() => setPickerDay(null)}
        onPick={(list) => {
          if (pickerDay === null) return;
          const d = p.days[pickerDay];
          setDay(pickerDay, { exercises: [...d.exercises, ...list.map((e) => ({ exercise_key: e.key || null, name: e.name, muscle_group: e.muscle_group || null, sets: e.sets ?? 3, reps: e.reps ?? '10', rest_seconds: e.rest_seconds ?? 60 }))] });
        }}
      />
    </Modal>
  );
}
