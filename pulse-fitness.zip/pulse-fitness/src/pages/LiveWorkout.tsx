import { useEffect, useMemo, useRef, useState } from 'react';
import { useData, useProfile } from '../hooks/useData';
import { useUnits } from '../hooks/useUnits';
import { useStopwatch, type StopwatchState } from '../hooks/useTimer';
import { useRouter, Link } from '../router';
import { useConfirm } from '../components/ui/Confirm';
import { Button, IconButton } from '../components/ui/Button';
import { Modal } from '../components/ui/Modal';
import { EmptyState, Card, Badge, Stat } from '../components/ui/Misc';
import { Select, Textarea, Rating } from '../components/ui/Field';
import { Icon } from '../components/Icon';
import { RestTimer } from '../components/RestTimer';
import { ExercisePicker } from '../components/workout/ExercisePicker';
import { draftSetFrom, fromDraft, toDraft, type DraftExercise } from '../components/workout/draft';
import { exerciseFromLibrary, previousPerformance } from '../utils/workout';
import { estimateWorkoutCalories, workoutTotals } from '../utils/calc';
import { latestWeight } from '../utils/stats';
import { fmtDuration, fmtNum } from '../utils/format';
import { nowTime, todayISO } from '../utils/date';
import { primeAudio } from '../utils/sound';
import { MOODS } from '../data/goals';
import type { Workout } from '../types';

interface LiveState {
  exercises: DraftExercise[];
  exIdx: number;
  setIdx: number;
  timer: StopwatchState;
  startTime: string | null;
  started: boolean;
}

const liveKey = (id: string) => `pulse.live.v1.${id}`;
function loadLive(id: string): LiveState | null {
  try {
    const raw = localStorage.getItem(liveKey(id));
    return raw ? (JSON.parse(raw) as LiveState) : null;
  } catch {
    return null;
  }
}
function saveLive(id: string, s: LiveState) {
  try {
    localStorage.setItem(liveKey(id), JSON.stringify(s));
  } catch {
    /* ignore */
  }
}
function clearLive(id: string) {
  try {
    localStorage.removeItem(liveKey(id));
  } catch {
    /* ignore */
  }
}

export default function LiveWorkoutPage({ id }: { id: string }) {
  const { workouts } = useData();
  const w = workouts.find((x) => x.id === id);
  if (!w)
    return (
      <div className="auth">
        <EmptyState icon="info" title="Workout not found" message="It may have been deleted." action={<Link to="/workouts" className="btn btn-primary btn-md">Back to workouts</Link>} />
      </div>
    );
  return <Live key={id} workout={w} />;
}

function Stepper({ label, value, onChange, step, unit }: { label: string; value: string; onChange: (v: string) => void; step: number; unit?: string }) {
  const bump = (d: number) => {
    const n = Number(String(value).replace(',', '.')) || 0;
    const next = Math.max(0, Math.round((n + d) * 100) / 100);
    onChange(String(next));
  };
  return (
    <div className="stepper">
      <div className="stepper-label">
        {label}
        {unit ? ` (${unit})` : ''}
      </div>
      <div className="stepper-ctrl">
        <button type="button" aria-label={`Decrease ${label}`} onClick={() => bump(-step)}>
          <Icon name="minus" size={22} />
        </button>
        <input value={value} onChange={(e) => onChange(e.target.value)} inputMode="decimal" aria-label={label} placeholder="0" onFocus={(e) => e.target.select()} />
        <button type="button" aria-label={`Increase ${label}`} onClick={() => bump(step)}>
          <Icon name="plus" size={22} />
        </button>
      </div>
    </div>
  );
}

function Live({ workout }: { workout: Workout }) {
  const { saveWorkout, workouts, tables } = useData();
  const profile = useProfile();
  const u = useUnits();
  const { navigate } = useRouter();
  const confirm = useConfirm();

  const saved = useMemo(() => loadLive(workout.id), [workout.id]);
  const [exercises, setExercises] = useState<DraftExercise[]>(() => saved?.exercises ?? toDraft(workout.exercises, u));
  const [exIdx, setExIdx] = useState(saved?.exIdx ?? 0);
  const [setIdx, setSetIdx] = useState(saved?.setIdx ?? 0);
  const [started, setStarted] = useState(saved?.started ?? workout.status === 'in_progress');
  const [startTime, setStartTime] = useState<string | null>(saved?.startTime ?? workout.start_time);
  const sw = useStopwatch(saved?.timer, 500);
  const [rest, setRest] = useState<{ sec: number; n: number } | null>(null);
  const [picker, setPicker] = useState(false);
  const [finishing, setFinishing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [extra, setExtra] = useState({ difficulty: workout.difficulty, energy_level: workout.energy_level, mood: workout.mood ?? '', notes: workout.notes ?? '' });

  // Persist live state locally on every change (survives refresh / screen lock)
  const state: LiveState = { exercises, exIdx, setIdx, timer: sw.state, startTime, started };
  const stateRef = useRef(state);
  stateRef.current = state;
  useEffect(() => {
    saveLive(workout.id, stateRef.current);
  }, [exercises, exIdx, setIdx, sw.state, startTime, started, workout.id]);

  // Keep the screen awake during a workout where supported
  useEffect(() => {
    if (!started || !sw.running) return;
    let lock: { release: () => Promise<void> } | null = null;
    const nav = navigator as Navigator & { wakeLock?: { request: (t: 'screen') => Promise<{ release: () => Promise<void> }> } };
    nav.wakeLock?.request('screen').then((l) => (lock = l)).catch(() => undefined);
    return () => {
      void lock?.release().catch(() => undefined);
    };
  }, [started, sw.running]);

  const ex = exercises[exIdx];
  const set = ex?.sets[setIdx];
  const nextEx = exercises.slice(exIdx + 1).find((e) => !e.skipped);
  const prev = ex ? previousPerformance(workouts, ex.name, todayISO(), workout.id) : null;
  const allSets = exercises.filter((e) => !e.skipped).flatMap((e) => e.sets);
  const doneSets = allSets.filter((s) => s.completed).length;

  const updateEx = (i: number, fn: (e: DraftExercise) => DraftExercise) => setExercises((list) => list.map((e, j) => (j === i ? fn(e) : e)));
  const updateSet = (patch: Partial<DraftExercise['sets'][number]>) => set && updateEx(exIdx, (e) => ({ ...e, sets: e.sets.map((s, j) => (j === setIdx ? { ...s, ...patch } : s)) }));

  const buildWorkout = (status: Workout['status']): Workout => {
    const ex = fromDraft(exercises, u);
    return {
      ...workout,
      status,
      date: workout.date,
      start_time: startTime,
      exercises: ex,
    };
  };

  async function begin() {
    primeAudio();
    if ('Notification' in window && Notification.permission === 'default' && profile.notifications_enabled) void Notification.requestPermission().catch(() => undefined);
    const st = startTime ?? nowTime();
    setStartTime(st);
    setStarted(true);
    sw.start();
    if (workout.status !== 'in_progress') await saveWorkout({ ...buildWorkout('in_progress'), start_time: st, date: todayISO() });
  }

  function goTo(i: number) {
    setExIdx(i);
    const firstOpen = exercises[i].sets.findIndex((s) => !s.completed);
    setSetIdx(firstOpen >= 0 ? firstOpen : Math.max(0, exercises[i].sets.length - 1));
  }

  function completeSet() {
    if (!ex || !set) return;
    primeAudio();
    const updated = exercises.map((e, j) => (j === exIdx ? { ...e, sets: e.sets.map((s, k) => (k === setIdx ? { ...s, completed: true } : s)) } : e));
    setExercises(updated);
    if (!sw.running && started) sw.start();
    const nextOpen = updated[exIdx].sets.findIndex((s, k) => k > setIdx && !s.completed);
    const restSec = ex.rest_seconds ?? profile.default_rest_seconds;
    if (nextOpen >= 0) {
      setSetIdx(nextOpen);
      if (restSec > 0) setRest({ sec: restSec, n: Date.now() });
    } else {
      const ni = updated.findIndex((e, j) => j > exIdx && !e.skipped && e.sets.some((s) => !s.completed));
      if (ni >= 0) {
        setExIdx(ni);
        setSetIdx(updated[ni].sets.findIndex((s) => !s.completed));
        if (restSec > 0) setRest({ sec: restSec, n: Date.now() });
      }
    }
  }

  function addSet() {
    if (!ex) return;
    const last = ex.sets[ex.sets.length - 1];
    updateEx(exIdx, (e) => ({ ...e, sets: [...e.sets, draftSetFrom(last)] }));
    setSetIdx(ex.sets.length);
  }

  async function deleteSet() {
    if (!ex || !set) return;
    if (ex.sets.length === 1 && !(await confirm({ title: 'Remove the only set?', message: 'This exercise will have no sets left.', confirmLabel: 'Remove', danger: true }))) return;
    updateEx(exIdx, (e) => ({ ...e, sets: e.sets.filter((_, j) => j !== setIdx) }));
    setSetIdx((i) => Math.max(0, Math.min(i, ex.sets.length - 2)));
  }

  function skipExercise() {
    if (!ex) return;
    updateEx(exIdx, (e) => ({ ...e, skipped: !e.skipped }));
    if (!ex.skipped) {
      const ni = exercises.findIndex((e, j) => j > exIdx && !e.skipped);
      if (ni >= 0) goTo(ni);
    }
  }

  async function exit() {
    sw.pause();
    setSaving(true);
    const r = await saveWorkout({ ...buildWorkout(started ? 'in_progress' : workout.status) }, { toast: started ? 'Progress saved — resume any time' : undefined });
    setSaving(false);
    if (r.ok) navigate(`/workouts/${workout.id}`);
  }

  const totalsPreview = workoutTotals({ exercises: fromDraft(exercises, u), status: 'in_progress' }, true);
  const minutes = Math.round(sw.elapsed / 60000);
  const weightKg = latestWeight(tables.body_measurements)?.value ?? profile.weight_kg;
  const estCalories = estimateWorkoutCalories(workout.workout_type, minutes || null, weightKg);

  async function finish() {
    if (saving) return;
    setSaving(true);
    sw.pause();
    const final = buildWorkout('completed');
    const t = workoutTotals(final, true);
    const done: Workout = {
      ...final,
      end_time: nowTime(),
      duration_min: minutes || workout.duration_min || null,
      total_volume_kg: t.volumeKg || null,
      calories: workout.calories ?? estCalories,
      difficulty: extra.difficulty,
      energy_level: extra.energy_level,
      mood: extra.mood || null,
      notes: extra.notes.trim() || null,
      date: workout.status === 'planned' ? todayISO() : workout.date,
    };
    const r = await saveWorkout(done, { toast: 'Workout complete — great job! 🎉' });
    setSaving(false);
    if (r.ok) {
      clearLive(workout.id);
      navigate(`/workouts/${workout.id}`, { replace: true });
    }
  }

  const progressPct = allSets.length ? (doneSets / allSets.length) * 100 : 0;

  return (
    <div className="live">
      <header className="live-top">
        <div className="live-top-row">
          <IconButton icon="x" label="Save and exit" onClick={exit} loading={saving && !finishing} />
          <div className="grow" style={{ minWidth: 0 }}>
            <div className="strong ellipsis">{workout.name}</div>
            <div className="xs muted">
              {doneSets}/{allSets.length} sets · {exercises.filter((e) => !e.skipped).length} exercises
            </div>
          </div>
          <div className="live-clock" role="timer" aria-label="Workout time">
            {fmtDuration(Math.floor(sw.elapsed / 1000))}
          </div>
          {started &&
            (sw.running ? (
              <IconButton icon="pause" label="Pause workout" variant="secondary" onClick={sw.pause} />
            ) : (
              <IconButton icon="play" label="Resume workout" variant="primary" onClick={sw.start} />
            ))}
        </div>
        <div className="pbar" style={{ marginTop: 10 }}>
          <div className="pbar-fill tone-success" style={{ width: `${progressPct}%` }} />
        </div>
      </header>

      <div className="live-body">
        {!started && (
          <Card>
            <div className="stack" style={{ alignItems: 'center', textAlign: 'center' }}>
              <h2 style={{ fontSize: 22 }}>Ready?</h2>
              <p className="muted">
                {exercises.length} exercises · {allSets.length} sets. The timer starts when you tap Start.
              </p>
              <Button size="lg" variant="primary" icon="play" onClick={begin}>
                Start workout
              </Button>
            </div>
          </Card>
        )}

        {started && !sw.running && (
          <div className="alert alert-warning">
            <Icon name="pause" size={18} /> Workout paused. Tap ▶ to resume.
          </div>
        )}

        {exercises.length > 0 && (
          <nav className="ex-nav" aria-label="Exercises">
            {exercises.map((e, i) => {
              const done = e.sets.length > 0 && e.sets.every((s) => s.completed);
              return (
                <button key={e.id} className={`ex-pill ${i === exIdx ? 'active' : ''} ${done ? 'done' : ''} ${e.skipped ? 'skipped' : ''}`} onClick={() => goTo(i)} aria-current={i === exIdx ? 'step' : undefined}>
                  {done && <Icon name="check" size={14} strokeWidth={3} />}
                  {e.name}
                </button>
              );
            })}
          </nav>
        )}

        {ex ? (
          <Card className="live-current">
            <div className="stack">
              <div className="row between" style={{ alignItems: 'flex-start' }}>
                <div className="grow">
                  <div className="xs muted strong" style={{ textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                    Exercise {exIdx + 1} of {exercises.length}
                    {ex.muscle_group ? ` · ${ex.muscle_group}` : ''}
                  </div>
                  <div className="live-ex-name">{ex.name}</div>
                  {ex.target_reps && (
                    <div className="small muted">
                      Target: {ex.target_sets ?? ex.sets.length} × {ex.target_reps}
                    </div>
                  )}
                </div>
                {ex.skipped && <Badge>Skipped</Badge>}
              </div>

              {ex.sets.length > 0 && (
                <div className="row-wrap" role="list" aria-label="Sets">
                  {ex.sets.map((s, i) => (
                    <button key={s.id} role="listitem" className={`set-chip ${s.completed ? 'done' : ''} ${i === setIdx ? 'current' : ''}`} style={{ border: 0, cursor: 'pointer', minHeight: 32 }} onClick={() => setSetIdx(i)} aria-label={`Set ${i + 1}${s.completed ? ', done' : ''}`}>
                      {s.completed ? '✓' : ''} Set {i + 1}
                      {s.reps ? ` · ${s.reps}` : ''}
                      {s.weight ? ` × ${s.weight}` : ''}
                    </button>
                  ))}
                </div>
              )}

              {prev && (
                <div className="small muted">
                  <b>Last time:</b> {prev.map((s) => `${s.reps ?? '–'}×${s.weight_kg != null ? fmtNum(u.weight(s.weight_kg), 1) : 'BW'}`).join(', ')} {u.w}
                </div>
              )}

              {set ? (
                <>
                  <div className="strong">
                    Set {setIdx + 1} of {ex.sets.length}
                    {set.completed && <span className="success-text"> · done ✓</span>}
                  </div>
                  <div className="live-set-big">
                    <Stepper label="Reps" value={set.reps} step={1} onChange={(v) => updateSet({ reps: v })} />
                    <Stepper label="Weight" unit={u.w} value={set.weight} step={u.w === 'kg' ? 2.5 : 5} onChange={(v) => updateSet({ weight: v })} />
                  </div>
                  <Button size="lg" variant={set.completed ? 'secondary' : 'success'} icon="check" block onClick={set.completed ? () => updateSet({ completed: false }) : completeSet} disabled={!started}>
                    {set.completed ? 'Undo — mark set not done' : 'Complete set'}
                  </Button>
                </>
              ) : (
                <p className="muted">No sets yet — add one below.</p>
              )}

              <div className="row-wrap">
                <Button size="sm" icon="plus" onClick={addSet}>
                  Add set
                </Button>
                {set && (
                  <Button size="sm" icon="trash" onClick={deleteSet}>
                    Delete set
                  </Button>
                )}
                <Button size="sm" icon="skip" onClick={skipExercise}>
                  {ex.skipped ? 'Unskip' : 'Skip exercise'}
                </Button>
              </div>
              {nextEx && (
                <div className="small muted row">
                  <Icon name="arrowRight" size={16} /> Next: <b>{nextEx.name}</b>
                </div>
              )}
            </div>
          </Card>
        ) : (
          <Card>
            <EmptyState icon="dumbbell" title="No exercises yet" message="Add exercises to track sets, or just use the timer." action={<Button variant="primary" icon="plus" onClick={() => setPicker(true)}>Add exercises</Button>} />
          </Card>
        )}

        <RestTimer trigger={rest} sound={profile.sound_enabled} compact />

        <Button icon="plus" onClick={() => setPicker(true)}>
          Add exercise
        </Button>
      </div>

      <div className="live-bar">
        <div className="live-bar-inner">
          <Button size="lg" icon="flag" variant="primary" disabled={!started} onClick={() => setFinishing(true)}>
            Finish workout
          </Button>
        </div>
      </div>

      <ExercisePicker
        open={picker}
        onClose={() => setPicker(false)}
        onPick={(list) => {
          const added = toDraft(list.map((e) => exerciseFromLibrary(e, profile.default_rest_seconds)), u).map((d, i) => (list[i].key ? d : { ...d, exercise_key: null }));
          setExercises((l) => {
            if (l.length === 0) {
              setExIdx(0);
              setSetIdx(0);
            }
            return [...l, ...added];
          });
        }}
      />

      <Modal
        open={finishing}
        title="Finish workout"
        onClose={() => setFinishing(false)}
        footer={
          <>
            <Button onClick={() => setFinishing(false)}>Keep going</Button>
            <Button variant="primary" icon="check" loading={saving} onClick={finish}>
              Save workout
            </Button>
          </>
        }
      >
        <div className="grid g2-keep">
          <Stat label="Duration" icon="clock" value={fmtDuration(Math.floor(sw.elapsed / 1000))} />
          <Stat label="Exercises" icon="list" tone="info" value={totalsPreview.exercises} />
          <Stat label="Sets" icon="checkSquare" tone="success" value={totalsPreview.sets} />
          <Stat label="Reps" icon="zap" tone="violet" value={fmtNum(totalsPreview.reps)} />
          <Stat label="Volume" icon="dumbbell" tone="accent" value={totalsPreview.volumeKg ? fmtNum(u.weight(totalsPreview.volumeKg), 0) : '–'} unit={totalsPreview.volumeKg ? u.w : undefined} />
          <Stat label="Est. calories" icon="flame" tone="warning" value={workout.calories ?? estCalories ?? '–'} unit="kcal" sub="rough estimate" />
        </div>
        {doneSets < allSets.length && (
          <p className="small muted">
            {allSets.length - doneSets} set(s) weren't completed — only completed sets count toward totals.
          </p>
        )}
        <Rating label="How hard was it?" value={extra.difficulty} max={10} onChange={(v) => setExtra((x) => ({ ...x, difficulty: v }))} low="Easy" high="Max" />
        <Rating label="Energy level" value={extra.energy_level} max={5} onChange={(v) => setExtra((x) => ({ ...x, energy_level: v }))} low="Low" high="High" />
        <Select label="Mood" value={extra.mood} onChange={(e) => setExtra((x) => ({ ...x, mood: e.target.value }))}>
          <option value="">—</option>
          {MOODS.map((m) => (
            <option key={m}>{m}</option>
          ))}
        </Select>
        <Textarea label="Notes" value={extra.notes} onChange={(e) => setExtra((x) => ({ ...x, notes: e.target.value }))} />
      </Modal>
    </div>
  );
}
