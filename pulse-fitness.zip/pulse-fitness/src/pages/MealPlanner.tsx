import { useEffect, useState } from 'react';
import { useData, useProfile } from '../hooks/useData';
import { useRouter } from '../router';
import { useConfirm } from '../components/ui/Confirm';
import { PageHeader, Card, EmptyState, Tabs } from '../components/ui/Misc';
import { Button, IconButton } from '../components/ui/Button';
import { Input, NumberInput, Select, Textarea, Toggle } from '../components/ui/Field';
import { Modal } from '../components/ui/Modal';
import { Icon } from '../components/Icon';
import { DateDialog } from '../components/workout/DateDialog';
import { MealIdeas } from './Nutrition';
import { addDays, fmtDate, isValidISO, startOfWeek, todayISO, parseISO } from '../utils/date';
import { fmtNum } from '../utils/format';
import { uuid } from '../utils/id';
import { Validator } from '../utils/validate';
import type { MealPlan, MealTemplate, PlanMealType } from '../types';
import type { MealIdea } from '../data/meals';

const SLOTS: { value: PlanMealType; label: string }[] = [
  { value: 'breakfast', label: 'Breakfast' },
  { value: 'lunch', label: 'Lunch' },
  { value: 'dinner', label: 'Dinner' },
  { value: 'snack', label: 'Snacks' },
];
const toEntryMeal = (s: PlanMealType) => (s === 'snack' ? 'afternoon_snack' : s);

export default function MealPlannerPage() {
  const data = useData();
  const { tables } = data;
  const profile = useProfile();
  const { query, navigate } = useRouter();
  const confirm = useConfirm();
  const qd = query.get('date');
  const [week, setWeek] = useState(startOfWeek(qd && isValidISO(qd) ? qd : todayISO()));
  const [tab, setTab] = useState<'plan' | 'templates' | 'ideas'>('plan');
  const [editing, setEditing] = useState<{ plan: MealPlan; asTemplate?: boolean } | null>(null);
  const [copying, setCopying] = useState<MealPlan | null>(null);
  const [repeating, setRepeating] = useState<MealPlan | null>(null);
  const [focusDay, setFocusDay] = useState(qd && isValidISO(qd) ? qd : todayISO());

  useEffect(() => {
    if (qd) navigate('/meals', { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const days = Array.from({ length: 7 }, (_, i) => addDays(week, i));
  const today = todayISO();

  async function remove(p: MealPlan) {
    if (await confirm({ title: 'Delete planned meal?', message: `“${p.title}” on ${fmtDate(p.date)}.`, confirmLabel: 'Delete', danger: true })) await data.remove('meal_plans', p, { toast: 'Meal removed' });
  }
  async function logAsEaten(p: MealPlan) {
    await data.save('nutrition_entries', { id: uuid(), date: p.date, meal_type: toEntryMeal(p.meal_type), food_name: p.title, serving_size: null, calories: p.calories, protein_g: p.protein_g, carbs_g: p.carbs_g, fat_g: p.fat_g, fiber_g: null, sugar_g: null, notes: p.description }, { toast: 'Logged in your food diary' });
  }
  const fromIdea = (m: MealIdea, date = focusDay): MealPlan => ({ id: '', date, meal_type: m.slot, title: m.title, description: m.description, calories: m.calories, protein_g: m.protein_g, carbs_g: m.carbs_g, fat_g: m.fat_g });

  return (
    <div className="stack">
      <PageHeader title="Meal planner" subtitle="Plan the week ahead" actions={<Button variant="primary" icon="plus" onClick={() => setEditing({ plan: blankPlan(focusDay, 'lunch') })}>Plan a meal</Button>} />
      <Tabs
        label="Planner sections"
        value={tab}
        onChange={setTab}
        tabs={[
          { value: 'plan', label: 'This week', icon: 'calendar' },
          { value: 'templates', label: `Templates (${tables.meal_templates.length})`, icon: 'copy' },
          { value: 'ideas', label: 'Ideas', icon: 'sparkle' },
        ]}
      />

      {tab === 'plan' && (
        <>
          <div className="row">
            <IconButton icon="left" label="Previous week" variant="secondary" onClick={() => setWeek(addDays(week, -7))} />
            <div className="grow center strong">
              {fmtDate(week)} – {fmtDate(addDays(week, 6), { month: 'short', day: 'numeric', year: 'numeric' })}
            </div>
            <IconButton icon="right" label="Next week" variant="secondary" onClick={() => setWeek(addDays(week, 7))} />
          </div>
          <Toggle label="Show planned meals in calendar" checked={profile.show_meals_in_calendar} onChange={(v) => void data.saveProfile({ show_meals_in_calendar: v })} />
          <div className="grid g2" style={{ gridTemplateColumns: undefined }}>
            {days.map((d) => {
              const plans = tables.meal_plans.filter((p) => p.date === d);
              const kcal = plans.reduce((a, p) => a + (p.calories ?? 0), 0);
              const prot = plans.reduce((a, p) => a + (p.protein_g ?? 0), 0);
              return (
                <Card
                  key={d}
                  className={d === today ? 'live-current' : ''}
                  title={
                    <span>
                      {fmtDate(d, { weekday: 'long' })} <span className="muted" style={{ fontWeight: 500 }}>{fmtDate(d)}</span>
                    </span>
                  }
                  action={plans.length ? <span className="xs muted">{fmtNum(kcal)} kcal · P {fmtNum(prot)}g</span> : undefined}
                >
                  <div className="planner-day">
                    {SLOTS.map((s) => {
                      const items = plans.filter((p) => p.meal_type === s.value);
                      return (
                        <div key={s.value} className="planner-slot">
                          <div className="row between">
                            <span className="small strong muted">{s.label}</span>
                            <IconButton icon="plus" size="sm" label={`Add ${s.label} on ${fmtDate(d)}`} onClick={() => { setFocusDay(d); setEditing({ plan: blankPlan(d, s.value) }); }} />
                          </div>
                          {items.map((p) => (
                            <div key={p.id} className="plan-item">
                              <button className="grow" style={{ border: 0, background: 'none', textAlign: 'left', padding: 0, cursor: 'pointer', minWidth: 0 }} onClick={() => setEditing({ plan: p })}>
                                <div className="strong ellipsis">{p.title}</div>
                                {p.calories != null && <div className="xs muted">{fmtNum(p.calories)} kcal</div>}
                              </button>
                              <IconButton icon="check" size="sm" label={`Log ${p.title} as eaten`} onClick={() => logAsEaten(p)} />
                              <IconButton icon="copy" size="sm" label={`Copy ${p.title} to another day`} onClick={() => setCopying(p)} />
                              <IconButton icon="refresh" size="sm" label={`Repeat ${p.title}`} onClick={() => setRepeating(p)} />
                              <IconButton icon="trash" size="sm" label={`Delete ${p.title}`} onClick={() => remove(p)} />
                            </div>
                          ))}
                        </div>
                      );
                    })}
                  </div>
                </Card>
              );
            })}
          </div>
        </>
      )}

      {tab === 'templates' &&
        (tables.meal_templates.length === 0 ? (
          <Card>
            <EmptyState icon="copy" title="No meal templates yet" message="Save a meal you plan often as a template to add it in one tap." action={<Button variant="primary" icon="plus" onClick={() => setEditing({ plan: blankPlan(focusDay, 'breakfast'), asTemplate: true })}>New template</Button>} />
          </Card>
        ) : (
          <Card padded={false} title="Meal templates" action={<Button size="sm" icon="plus" onClick={() => setEditing({ plan: blankPlan(focusDay, 'breakfast'), asTemplate: true })}>New</Button>}>
            <div className="list">
              {tables.meal_templates.map((t) => (
                <div key={t.id} className="list-item" style={{ cursor: 'default' }}>
                  <span className="grow">
                    <span className="list-title" style={{ display: 'block' }}>{t.title}</span>
                    <span className="list-sub" style={{ display: 'block' }}>
                      {SLOTS.find((s) => s.value === t.meal_type)?.label}
                      {t.calories != null ? ` · ${fmtNum(t.calories)} kcal` : ''}
                    </span>
                  </span>
                  <Button size="sm" icon="plus" onClick={() => setEditing({ plan: { ...blankPlan(focusDay, t.meal_type), title: t.title, description: t.description, calories: t.calories, protein_g: t.protein_g, carbs_g: t.carbs_g, fat_g: t.fat_g } })}>
                    Use
                  </Button>
                  <IconButton
                    icon="trash"
                    size="sm"
                    label={`Delete template ${t.title}`}
                    onClick={async () => {
                      if (await confirm({ title: 'Delete template?', message: t.title, confirmLabel: 'Delete', danger: true })) await data.remove('meal_templates', t, { toast: 'Template deleted' });
                    }}
                  />
                </div>
              ))}
            </div>
          </Card>
        ))}

      {tab === 'ideas' && <MealIdeas onPlan={(m) => setEditing({ plan: fromIdea(m) })} />}

      <PlanForm state={editing} onClose={() => setEditing(null)} />

      <DateDialog
        open={!!copying}
        title={`Copy “${copying?.title ?? ''}”`}
        initial={copying ? addDays(copying.date, 1) : undefined}
        confirmLabel="Copy"
        onClose={() => setCopying(null)}
        onConfirm={async (d) => {
          if (!copying) return;
          const r = await data.save('meal_plans', { ...copying, id: uuid(), date: d, created_at: undefined, updated_at: undefined }, { toast: `Copied to ${fmtDate(d)}` });
          if (r.ok) setCopying(null);
        }}
      />
      <RepeatDialog plan={repeating} onClose={() => setRepeating(null)} />
    </div>
  );
}

function blankPlan(date: string, slot: PlanMealType): MealPlan {
  return { id: '', date, meal_type: slot, title: '', description: null, calories: null, protein_g: null, carbs_g: null, fat_g: null };
}

function PlanForm({ state, onClose }: { state: { plan: MealPlan; asTemplate?: boolean } | null; onClose: () => void }) {
  const data = useData();
  const [f, setF] = useState<Record<string, string>>({});
  const [template, setTemplate] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [last, setLast] = useState<typeof state>(null);
  if (state !== last) {
    setLast(state);
    setErrors({});
    setTemplate(!!state?.asTemplate);
    if (state) {
      const p = state.plan;
      setF({ date: p.date, meal_type: p.meal_type, title: p.title, description: p.description ?? '', calories: p.calories == null ? '' : String(p.calories), protein_g: p.protein_g == null ? '' : String(p.protein_g), carbs_g: p.carbs_g == null ? '' : String(p.carbs_g), fat_g: p.fat_g == null ? '' : String(p.fat_g) });
    }
  }
  if (!state) return null;
  const { plan, asTemplate } = state;
  const set = (k: string, v: string) => setF((p) => ({ ...p, [k]: v }));

  async function save() {
    if (saving) return;
    const v = new Validator();
    v.required('title', f.title.trim(), 'Please name the meal.');
    if (!asTemplate) v.date('date', f.date);
    const calories = v.number('calories', f.calories, { min: 0, max: 10000, label: 'Calories' });
    const protein_g = v.number('protein_g', f.protein_g, { min: 0, max: 1000, label: 'Protein' });
    const carbs_g = v.number('carbs_g', f.carbs_g, { min: 0, max: 1000, label: 'Carbs' });
    const fat_g = v.number('fat_g', f.fat_g, { min: 0, max: 1000, label: 'Fat' });
    setErrors(v.errors);
    if (!v.ok) return;
    setSaving(true);
    const base = { title: f.title.trim(), description: f.description.trim() || null, meal_type: f.meal_type as PlanMealType, calories, protein_g, carbs_g, fat_g };
    let ok = true;
    if (!asTemplate) ok = (await data.save('meal_plans', { ...plan, ...base, id: plan.id || uuid(), date: f.date }, { toast: plan.id ? 'Meal updated' : 'Meal planned' })).ok;
    if (ok && template) {
      const t: MealTemplate = { id: uuid(), ...base };
      ok = (await data.save('meal_templates', t, { toast: 'Saved as template' })).ok;
    }
    setSaving(false);
    if (ok) onClose();
  }

  return (
    <Modal
      open
      title={asTemplate ? 'New meal template' : plan.id ? 'Edit planned meal' : 'Plan a meal'}
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" loading={saving} onClick={save}>
            Save
          </Button>
        </>
      }
    >
      <div className="form-grid">
        <Input label="Meal" className="full" value={f.title} onChange={(e) => set('title', e.target.value)} error={errors.title} placeholder="e.g. Chicken tinola + ¾ cup rice" />
        <Select label="Slot" value={f.meal_type} onChange={(e) => set('meal_type', e.target.value)}>
          {SLOTS.map((s) => (
            <option key={s.value} value={s.value}>
              {s.label}
            </option>
          ))}
        </Select>
        {!asTemplate && <Input label="Date" type="date" value={f.date} onChange={(e) => set('date', e.target.value)} error={errors.date} />}
        <NumberInput label="Calories" suffix="kcal" value={f.calories} onChange={(e) => set('calories', e.target.value)} error={errors.calories} />
        <NumberInput label="Protein" suffix="g" value={f.protein_g} onChange={(e) => set('protein_g', e.target.value)} error={errors.protein_g} />
        <NumberInput label="Carbs" suffix="g" value={f.carbs_g} onChange={(e) => set('carbs_g', e.target.value)} error={errors.carbs_g} />
        <NumberInput label="Fat" suffix="g" value={f.fat_g} onChange={(e) => set('fat_g', e.target.value)} error={errors.fat_g} />
      </div>
      <Textarea label="Notes / recipe" value={f.description} onChange={(e) => set('description', e.target.value)} />
      {!asTemplate && <Toggle label="Also save as a template" checked={template} onChange={setTemplate} />}
    </Modal>
  );
}

function RepeatDialog({ plan, onClose }: { plan: MealPlan | null; onClose: () => void }) {
  const data = useData();
  const [weeks, setWeeks] = useState('1');
  const [dows, setDows] = useState<number[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [last, setLast] = useState<MealPlan | null>(null);
  if (plan !== last) {
    setLast(plan);
    setWeeks('1');
    setErr(null);
    setDows(plan ? [0, 1, 2, 3, 4, 5, 6].filter((i) => i !== (parseISO(plan.date).getDay() + 6) % 7) : []);
  }
  if (!plan) return null;
  const names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  async function go() {
    if (!plan || busy) return;
    const w = Number(weeks);
    if (!Number.isInteger(w) || w < 1 || w > 12) return setErr('Weeks must be 1–12.');
    if (!dows.length) return setErr('Pick at least one day.');
    const start = startOfWeek(plan.date);
    const rows: MealPlan[] = [];
    for (let k = 0; k < w; k++)
      for (const d of dows) {
        const date = addDays(start, k * 7 + d);
        if (date <= plan.date) continue;
        rows.push({ ...plan, id: uuid(), date, created_at: undefined, updated_at: undefined });
      }
    if (!rows.length) return setErr('No future days selected.');
    setBusy(true);
    const r = await data.saveMany('meal_plans', rows, { toast: `Repeated on ${rows.length} day${rows.length === 1 ? '' : 's'}` });
    setBusy(false);
    if (r.ok) onClose();
  }

  return (
    <Modal
      open
      size="sm"
      title={`Repeat “${plan.title}”`}
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" loading={busy} onClick={go}>
            Repeat
          </Button>
        </>
      }
    >
      <fieldset className="field">
        <legend className="field-label">On these days</legend>
        <div className="chips">
          {names.map((n, i) => (
            <button key={n} type="button" className={`chip ${dows.includes(i) ? 'chip-on' : ''}`} aria-pressed={dows.includes(i)} onClick={() => setDows((d) => (d.includes(i) ? d.filter((x) => x !== i) : [...d, i]))}>
              {n}
            </button>
          ))}
        </div>
      </fieldset>
      <NumberInput label="For" suffix="weeks" decimal={false} value={weeks} onChange={(e) => setWeeks(e.target.value)} hint="Only days after the original date are filled." />
      {err && <p className="field-msg">{err}</p>}
      <p className="xs muted">
        <Icon name="info" size={12} /> Same slot ({plan.meal_type}) on each selected day.
      </p>
    </Modal>
  );
}
