import { useState, type FormEvent } from 'react';
import { useAuth } from '../hooks/useAuth';
import { Brand } from '../components/layout/AppShell';
import { Input } from '../components/ui/Field';
import { Button } from '../components/ui/Button';
import { Icon } from '../components/Icon';
import { useOnline } from '../hooks/useOnline';

type Mode = 'signin' | 'signup' | 'reset' | 'newpass';
const allowSignup = import.meta.env.VITE_ALLOW_SIGNUP === 'true';

export default function LoginPage() {
  const auth = useAuth();
  const online = useOnline();
  const [mode, setMode] = useState<Mode>(auth.recovering ? 'newpass' : 'signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [password2, setPassword2] = useState('');
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  const effectiveMode: Mode = auth.recovering ? 'newpass' : mode;

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (busy) return;
    setError(null);
    setInfo(null);
    if (effectiveMode !== 'newpass' && !/^\S+@\S+\.\S+$/.test(email.trim())) return setError('Please enter a valid email address.');
    if ((effectiveMode === 'signin' || effectiveMode === 'signup' || effectiveMode === 'newpass') && password.length < (effectiveMode === 'signin' ? 1 : 8))
      return setError(effectiveMode === 'signin' ? 'Please enter your password.' : 'Password must be at least 8 characters.');
    if ((effectiveMode === 'signup' || effectiveMode === 'newpass') && password !== password2) return setError('Passwords do not match.');
    setBusy(true);
    try {
      if (effectiveMode === 'signin') {
        const err = await auth.signIn(email, password);
        if (err) setError(err);
      } else if (effectiveMode === 'signup') {
        const r = await auth.signUp(email, password, name);
        if (r.error) setError(r.error);
        else if (r.needsConfirmation) {
          setInfo('Account created. Check your email and click the confirmation link, then sign in.');
          setMode('signin');
        }
      } else if (effectiveMode === 'reset') {
        const err = await auth.sendReset(email);
        if (err) setError(err);
        else setInfo('If that email has an account, a reset link is on its way.');
      } else {
        const err = await auth.updatePassword(password);
        if (err) setError(err);
      }
    } finally {
      setBusy(false);
    }
  }

  const titles: Record<Mode, string> = {
    signin: 'Sign in to your private fitness space',
    signup: 'Create your account',
    reset: 'Reset your password',
    newpass: 'Choose a new password',
  };

  return (
    <div className="auth">
      <form className="auth-card" onSubmit={submit} noValidate>
        <Brand />
        <p className="auth-tagline">{titles[effectiveMode]}</p>
        <div className="card stack">
          {!online && (
            <div className="alert alert-warning">
              <Icon name="wifiOff" size={18} /> You're offline. Signing in needs an internet connection.
            </div>
          )}
          {error && (
            <div className="alert alert-error" role="alert">
              <Icon name="alert" size={18} /> {error}
            </div>
          )}
          {info && (
            <div className="alert alert-success" role="status">
              <Icon name="check" size={18} /> {info}
            </div>
          )}
          {effectiveMode === 'signup' && <Input label="Name" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />}
          {effectiveMode !== 'newpass' && (
            <Input label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" inputMode="email" required />
          )}
          {effectiveMode !== 'reset' && (
            <Input
              label={effectiveMode === 'newpass' ? 'New password' : 'Password'}
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete={effectiveMode === 'signin' ? 'current-password' : 'new-password'}
              required
            />
          )}
          {(effectiveMode === 'signup' || effectiveMode === 'newpass') && (
            <Input label="Confirm password" type="password" value={password2} onChange={(e) => setPassword2(e.target.value)} autoComplete="new-password" required />
          )}
          <Button type="submit" variant="primary" size="lg" block loading={busy} disabled={!online}>
            {effectiveMode === 'signin' ? 'Sign in' : effectiveMode === 'signup' ? 'Create account' : effectiveMode === 'reset' ? 'Send reset link' : 'Save new password'}
          </Button>
        </div>
        <div className="row between" style={{ justifyContent: 'center', flexWrap: 'wrap' }}>
          {effectiveMode === 'signin' && (
            <>
              <button type="button" className="link-btn" onClick={() => setMode('reset')}>
                Forgot password?
              </button>
              {allowSignup && (
                <button type="button" className="link-btn" onClick={() => setMode('signup')}>
                  Create account
                </button>
              )}
            </>
          )}
          {(effectiveMode === 'signup' || effectiveMode === 'reset') && (
            <button type="button" className="link-btn" onClick={() => setMode('signin')}>
              Back to sign in
            </button>
          )}
        </div>
        <p className="center faint xs">
          <Icon name="info" size={12} /> Private app — your data is only visible to your account.
        </p>
      </form>
    </div>
  );
}
