import { useEffect, useState } from 'react';
import { useStopwatch, type StopwatchState } from '../hooks/useTimer';
import { useProfile } from '../hooks/useData';
import { PageHeader, Card } from '../components/ui/Misc';
import { Button } from '../components/ui/Button';
import { RestTimer } from '../components/RestTimer';
import { fmtStopwatch } from '../utils/format';

const KEY = 'pulse.stopwatch.v1';
interface Saved {
  sw: StopwatchState;
  laps: number[];
  stopped: boolean;
}
function load(): Saved | null {
  try {
    const r = localStorage.getItem(KEY);
    return r ? (JSON.parse(r) as Saved) : null;
  } catch {
    return null;
  }
}

export function Stopwatch() {
  const [saved] = useState(load);
  const sw = useStopwatch(saved?.sw, 47);
  const [laps, setLaps] = useState<number[]>(saved?.laps ?? []);
  const [stopped, setStopped] = useState(saved?.stopped ?? false);

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify({ sw: sw.state, laps, stopped }));
    } catch {
      /* ignore */
    }
  }, [sw.state, laps, stopped]);

  const started = sw.elapsed > 0 || sw.running;
  const reset = () => {
    sw.reset();
    setLaps([]);
    setStopped(false);
  };
  const lapTimes = laps.map((t, i) => t - (laps[i - 1] ?? 0));
  const best = lapTimes.length > 1 ? Math.min(...lapTimes) : null;
  const worst = lapTimes.length > 1 ? Math.max(...lapTimes) : null;

  return (
    <div className="stack" style={{ alignItems: 'center' }}>
      <div className="big-timer" role="timer" aria-label="Stopwatch">
        {fmtStopwatch(sw.elapsed)}
      </div>
      {stopped && <p className="small muted">Stopped. Reset to start again.</p>}
      <div className="timer-controls">
        {!sw.running && !started && (
          <Button size="lg" variant="primary" icon="play" onClick={sw.start}>
            Start
          </Button>
        )}
        {sw.running && (
          <>
            <Button size="lg" icon="pause" onClick={sw.pause}>
              Pause
            </Button>
            <Button size="lg" icon="lap" onClick={() => setLaps((l) => [...l, sw.elapsed])}>
              Lap
            </Button>
          </>
        )}
        {!sw.running && started && !stopped && (
          <Button size="lg" variant="primary" icon="play" onClick={sw.start}>
            Resume
          </Button>
        )}
        {started && !stopped && (
          <Button
            size="lg"
            variant="danger"
            icon="stop"
            onClick={() => {
              sw.pause();
              setStopped(true);
            }}
          >
            Stop
          </Button>
        )}
        {started && (
          <Button size="lg" icon="rotate" onClick={reset}>
            Reset
          </Button>
        )}
      </div>
      {laps.length > 0 && (
        <ul className="laps" style={{ width: '100%', maxWidth: 420 }} aria-label="Laps">
          {[...lapTimes].reverse().map((t, ri) => {
            const i = lapTimes.length - 1 - ri;
            return (
              <li key={i}>
                <span className={t === best ? 'success-text strong' : t === worst ? 'danger-text strong' : ''}>
                  Lap {i + 1}
                  {t === best ? ' · fastest' : t === worst ? ' · slowest' : ''}
                </span>
                <span className="num">{fmtStopwatch(t)}</span>
                <span className="num muted">{fmtStopwatch(laps[i])}</span>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

export default function TimersPage() {
  const profile = useProfile();
  return (
    <div className="stack">
      <PageHeader title="Timers" subtitle="Stopwatch for runs, planks & HIIT · rest timer between sets" />
      <div className="grid g2">
        <Card title="Stopwatch" icon="timer">
          <Stopwatch />
        </Card>
        <Card title="Rest timer" icon="clock">
          <RestTimer sound={profile.sound_enabled} />
        </Card>
      </div>
      <p className="xs faint center">Timers keep running if you switch pages — they're based on the clock, not on the screen being open.</p>
    </div>
  );
}
