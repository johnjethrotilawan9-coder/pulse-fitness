import { useMemo, useState, type FormEvent } from 'react';
import { useData, useProfile } from '../hooks/useData';
import { useUnits } from '../hooks/useUnits';
import { useRouter, Link } from '../router';
import { PageHeader, Card, EmptyState } from '../components/ui/Misc';
import { Input, NumberInput, Select, Textarea, ChipSelect, Rating } from '../components/ui/Field';
import { Button, IconButton } from '../components/ui/Button';
import { ExercisePicker } from '../components/workout/ExercisePicker';
import { ExerciseEditor } from '../components/workout/ExerciseEditor';
import { fromDraft, toDraft, validateDraft, type DraftExercise } from '../components/workout/draft';
import { MUSCLE_GROUPS } from '../data/exercises';
import { MOODS, WORKOUT_TYPES } from '../data/goals';
import { blankWorkout, exerciseFromLibrary } from '../utils/workout';
import { Validator } from '../utils/validate';
import { isValidISO, minutesBetween, todayISO } from '../utils/date';
import { estimateWorkoutCalories, workoutTotals } from '../utils/calc';
import { latestWeight } from '../utils/stats';
import { label } from '../utils/format';
import type { Workout, WorkoutStatus } from '../types';

export default function WorkoutEditPage({ id }: { id?: string }) {
  const { workouts } = useData();
  const existing = id ? workouts.find((w) => w.id === id) : undefined;
  if (id && !existing)
    return <EmptyState icon="info" title="Workout not found" message="It may have been deleted." action={<Link to="/workouts" className="btn btn-primary btn-md">Back to workouts</Link>} />;
  return <WorkoutForm key={id ?? 'new'} existing={existing} />;
}

function WorkoutForm({ existing }: { existing?: Workout }) {
  const { saveWorkout, tables } = useData();
  const profile = useProfile();
  const u = useUnits();
  const { navigate, query } = useRouter();

  const initial = useMemo(() => {
    if (existing) return existing;
    const d = query.get('date');
    return blankWorkout(d && isValidISO(d) ? d : todayISO());
  }, [existing, query]);

  const [f, setF] = useState({
    date: initial.date,
    name: initial.name,
    workout_type: initial.workout_type,
    status: initial.status as WorkoutStatus,
    start_time: initial.start_time ?? '',
    end_time: initial.end_time ?? '',
    duration_min: initial.duration_min == null ? '' : String(initial.duration_min),
    muscle_groups: initial.muscle_groups,
    distance: initial.distance_km == null ? '' : String(u.dist(initial.distance_km)),
    calories: initial.calories == null ? '' : String(initial.calories),
    difficulty: initial.difficulty,
    energy_level: initial.energy_level,
    mood: initial.mood ?? '',
    notes: initial.notes ?? '',
  });
  const [exercises, setExercises] = useState<DraftExercise[]>(() => toDraft(initial.exercises, u));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [picker, setPicker] = useState(false);

  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF((p) => ({ ...p, [k]: v }));

  const autoDuration = f.start_time && f.end_time ? minutesBetween(f.start_time, f.end_time) : null;
  const weightKg = latestWeight(tables.body_measurements)?.value ?? profile.weight_kg;

  function estimateCalories() {
    const mins = Number(f.duration_min) || autoDuration;
    const est = estimateWorkoutCalories(f.workout_type, mins ?? null, weightKg);
    if (est) set('calories', String(est));
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (saving) return;
    const v = new Validator();
    v.date('date', f.date);
    v.required('name', f.name.trim(), 'Please give the workout a name.');
    const duration = v.number('duration_min', f.duration_min, { min: 0, max: 1440, label: 'Duration' });
    const distance = v.number('distance', f.distance, { min: 0, max: 1000, label: 'Distance' });
    const calories = v.number('calories', f.calories, { min: 0, max: 20000, int: true, label: 'Calories' });
    const exErrs = validateDraft(exercises);
    setErrors({ ...v.errors, ...exErrs });
    if (!v.ok || Object.keys(exErrs).length) {
      requestAnimationFrame(() => document.querySelector('.field-error, .field-msg')?.scrollIntoView({ behavior: 'smooth', block: 'center' }));
      return;
    }
    const ex = fromDraft(exercises, u).map((x) => ({ ...x, name: x.name.trim() }));
    const w: Workout = {
      ...initial,
      date: f.date,
      name: f.name.trim(),
      workout_type: f.workout_type,
      status: f.status,
      start_time: f.start_time || null,
      end_time: f.end_time || null,
      duration_min: duration ?? autoDuration ?? null,
      muscle_groups: f.muscle_groups,
      distance_km: u.fromDist(distance),
      calories,
      difficulty: f.difficulty,
      energy_level: f.energy_level,
      mood: f.mood || null,
      notes: f.notes.trim() || null,
      exercises: ex,
    };
    const totals = workoutTotals(w);
    w.total_volume_kg = totals.volumeKg || null;
    setSaving(true);
    const res = await saveWorkout(w, { toast: existing ? 'Workout updated' : 'Workout saved' });
    setSaving(false);
    if (res.ok) navigate(`/workouts/${w.id}`, { replace: true });
  }

  const moveEx = (i: number, dir: -1 | 1) =>
    setExercises((list) => {
      const next = [...list];
      const j = i + dir;
      if (j < 0 || j >= next.length) return list;
      [next[i], next[j]] = [next[j], next[i]];
      return next;
    });

  return (
    <form onSubmit={submit} noValidate className="stack">
      <PageHeader
        title={existing ? 'Edit workout' : 'New workout'}
        back={<IconButton icon="left" label="Back" onClick={() => history.back()} />}
        subtitle={existing ? existing.name : 'Log a past session or plan one for later'}
      />

      <Card title="Details" icon="dumbbell">
        <div className="form-grid">
          <Input label="Workout name" className="full" value={f.name} onChange={(e) => set('name', e.target.value)} error={errors.name} placeholder="e.g. Push Day, Morning HIIT" />
          <Input label="Date" type="date" value={f.date} onChange={(e) => set('date', e.target.value)} error={errors.date} />
          <Select label="Status" value={f.status} onChange={(e) => set('status', e.target.value as WorkoutStatus)}>
            <option value="planned">Planned</option>
            <option value="in_progress">In progress</option>
            <option value="completed">Completed</option>
            <option value="skipped">Skipped</option>
          </Select>
          <Select label="Workout type" value={f.workout_type} onChange={(e) => set('workout_type', e.target.value)}>
            {WORKOUT_TYPES.map((t) => (
              <option key={t} value={t}>
                {label(t)}
              </option>
            ))}
          </Select>
          <NumberInput
            label="Duration"
            suffix="min"
            value={f.duration_min}
            onChange={(e) => set('duration_min', e.target.value)}
            error={errors.duration_min}
            placeholder={autoDuration != null ? String(autoDuration) : ''}
            hint={autoDuration != null && !f.duration_min ? `From start/end: ${autoDuration} min` : undefined}
          />
          <Input label="Start time" type="time" value={f.start_time} onChange={(e) => set('start_time', e.target.value)} />
          <Input label="End time" type="time" value={f.end_time} onChange={(e) => set('end_time', e.target.value)} />
          <NumberInput label="Distance (optional)" suffix={u.d} value={f.distance} onChange={(e) => set('distance', e.target.value)} error={errors.distance} />
          <div className="field">
            <NumberInput label="Calories burned" suffix="kcal" decimal={false} value={f.calories} onChange={(e) => set('calories', e.target.value)} error={errors.calories} />
            <button type="button" className="link-btn" style={{ alignSelf: 'flex-start', fontSize: 13, padding: 0 }} onClick={estimateCalories}>
              Estimate from duration
            </button>
          </div>
        </div>
      </Card>

      <Card title="Exercises" icon="list" action={<Button size="sm" icon="plus" onClick={() => setPicker(true)}>Add</Button>}>
        {exercises.length === 0 ? (
          <div className="empty" style={{ padding: 16 }}>
            <p className="muted">No exercises yet. Add some from the library, or leave empty for cardio/sport sessions.</p>
            <Button icon="plus" variant="primary" onClick={() => setPicker(true)}>
              Add exercises
            </Button>
          </div>
        ) : (
          <div className="stack-sm">
            {exercises.map((ex, i) => (
              <ExerciseEditor
                key={ex.id}
                ex={ex}
                index={i}
                count={exercises.length}
                errors={errors}
                onChange={(n) => setExercises((l) => l.map((x) => (x.id === ex.id ? n : x)))}
                onRemove={() => setExercises((l) => l.filter((x) => x.id !== ex.id))}
                onMove={(d) => moveEx(i, d)}
              />
            ))}
            <Button icon="plus" onClick={() => setPicker(true)}>
              Add exercise
            </Button>
          </div>
        )}
      </Card>

      <Card title="How it went" icon="heart">
        <div className="stack">
          <ChipSelect label="Muscle groups" values={f.muscle_groups} options={[...MUSCLE_GROUPS]} onChange={(v) => set('muscle_groups', v)} />
          <Rating label="Difficulty" value={f.difficulty} max={10} onChange={(v) => set('difficulty', v)} low="Easy" high="Max effort" />
          <Rating label="Energy level" value={f.energy_level} max={5} onChange={(v) => set('energy_level', v)} low="Low" high="High" />
          <Select label="Mood" value={f.mood} onChange={(e) => set('mood', e.target.value)}>
            <option value="">—</option>
            {MOODS.map((m) => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </Select>
          <Textarea label="Notes" value={f.notes} onChange={(e) => set('notes', e.target.value)} placeholder="How did it feel? Anything to remember next time?" />
        </div>
      </Card>

      <div className="row" style={{ justifyContent: 'flex-end' }}>
        <Button onClick={() => history.back()}>Cancel</Button>
        <Button type="submit" variant="primary" icon="check" loading={saving}>
          {existing ? 'Save changes' : 'Save workout'}
        </Button>
      </div>

      <ExercisePicker
        open={picker}
        onClose={() => setPicker(false)}
        onPick={(list) => {
          const added = toDraft(list.map((e) => exerciseFromLibrary(e, profile.default_rest_seconds)), u).map((d, i) => (list[i].key ? d : { ...d, exercise_key: null }));
          setExercises((l) => [...l, ...added]);
          const groups = new Set(f.muscle_groups);
          list.forEach((e) => e.muscle_group && groups.add(e.muscle_group));
          set('muscle_groups', [...groups]);
        }}
      />
    </form>
  );
}
