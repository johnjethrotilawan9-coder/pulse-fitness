import { useMemo, useState, type ReactNode } from 'react';
import { useData, useProfile } from '../hooks/useData';
import { useUnits } from '../hooks/useUnits';
import { PageHeader, Card, Tabs, EmptyState } from '../components/ui/Misc';
import { IconButton, Button } from '../components/ui/Button';
import { Icon, type IconName } from '../components/Icon';
import { HBars } from '../components/charts/Charts';
import { addDays, addMonths, daysBetween, endOfMonth, endOfWeek, fmtDate, fmtMonth, parseISO, startOfMonth, startOfWeek, todayISO } from '../utils/date';
import { fmtMinutes, fmtNum } from '../utils/format';
import { activeDays, currentStreak, measurementChange, nutritionTotals, periodStats, topKey, waterByDay } from '../utils/stats';
import type { BodyMeasurement } from '../types';

function Delta({ cur, prev, fmt = (n: number) => fmtNum(n, 1), invert = false }: { cur: number; prev: number; fmt?: (n: number) => string; invert?: boolean }) {
  const d = cur - prev;
  if (Math.abs(d) < 1e-9) return <span className="xs muted">same as before</span>;
  const good = invert ? d < 0 : d > 0;
  return (
    <span className={`xs strong ${good ? 'success-text' : 'danger-text'}`}>
      {d > 0 ? '▲' : '▼'} {fmt(Math.abs(d))} vs previous
    </span>
  );
}

function Tile({ icon, label, value, sub, tone = 'accent' }: { icon: IconName; label: string; value: ReactNode; sub?: ReactNode; tone?: string }) {
  return (
    <div className="card stat-card">
      <div className="stat">
        <div className="stat-label">
          <span className={`stat-icon tone-${tone}`}>
            <Icon name={icon} size={15} />
          </span>
          {label}
        </div>
        <div className="stat-value">{value}</div>
        {sub && <div className="stat-sub">{sub}</div>}
      </div>
    </div>
  );
}

export default function StatsPage() {
  const [tab, setTab] = useState<'week' | 'month'>('week');
  const { workouts, tables } = useData();
  const empty = workouts.length === 0 && tables.running_sessions.length === 0 && tables.body_measurements.length === 0 && tables.nutrition_entries.length === 0;
  return (
    <div className="stack">
      <PageHeader title="Statistics" subtitle="Weekly and monthly reports" />
      <Tabs label="Report period" value={tab} onChange={setTab} tabs={[{ value: 'week', label: 'Weekly', icon: 'calendar' }, { value: 'month', label: 'Monthly', icon: 'chart' }]} />
      {empty ? (
        <Card>
          <EmptyState icon="chart" title="No data to report yet" message="Your reports fill in automatically as you log workouts, runs, meals, water and weigh-ins." />
        </Card>
      ) : tab === 'week' ? (
        <Weekly />
      ) : (
        <Monthly />
      )}
    </div>
  );
}

function Weekly() {
  const { workouts, tables } = useData();
  const profile = useProfile();
  const u = useUnits();
  const [anchor, setAnchor] = useState(todayISO());
  const from = startOfWeek(anchor), to = endOfWeek(anchor);
  const pFrom = addDays(from, -7), pTo = addDays(to, -7);
  const cur = periodStats(workouts, tables.running_sessions, from, to);
  const prev = periodStats(workouts, tables.running_sessions, pFrom, pTo);
  const water = waterByDay(tables.water_entries);
  const days = daysBetween(from, to);
  const waterHit = days.filter((d) => (water[d] ?? 0) >= profile.water_target_ml).length;
  const prevWaterHit = daysBetween(pFrom, pTo).filter((d) => (water[d] ?? 0) >= profile.water_target_ml).length;
  const weight = measurementChange(tables.body_measurements, 'weight_kg', from, to);
  const food = tables.nutrition_entries.filter((n) => n.date >= from && n.date <= to);
  const loggedDays = new Set(food.map((f) => f.date)).size;
  const nt = nutritionTotals(food);
  const topMuscle = topKey(cur.muscleCounts);
  const streak = currentStreak(activeDays(workouts, tables.running_sessions));
  const isCurrent = from === startOfWeek(todayISO());

  return (
    <>
      <div className="row">
        <IconButton icon="left" label="Previous week" variant="secondary" onClick={() => setAnchor(addDays(anchor, -7))} />
        <div className="grow center strong">
          {fmtDate(from)} – {fmtDate(to, { month: 'short', day: 'numeric', year: 'numeric' })}
          {isCurrent && <div className="xs muted">This week</div>}
        </div>
        <IconButton icon="right" label="Next week" variant="secondary" disabled={isCurrent} onClick={() => setAnchor(addDays(anchor, 7))} />
        {!isCurrent && <Button size="sm" onClick={() => setAnchor(todayISO())}>This week</Button>}
      </div>
      <div className="grid g4">
        <Tile icon="dumbbell" label="Workouts" value={cur.workouts} sub={<Delta cur={cur.workouts} prev={prev.workouts} fmt={(n) => fmtNum(n)} />} />
        <Tile icon="check" tone="success" label="Completed" value={`${cur.completed}/${profile.weekly_workout_target}`} sub={<Delta cur={cur.completed} prev={prev.completed} fmt={(n) => fmtNum(n)} />} />
        <Tile icon="skip" tone="warning" label="Skipped" value={cur.skipped} sub={<Delta cur={cur.skipped} prev={prev.skipped} fmt={(n) => fmtNum(n)} invert />} />
        <Tile icon="clock" tone="info" label="Exercise time" value={fmtMinutes(cur.minutes)} sub={<Delta cur={cur.minutes} prev={prev.minutes} fmt={(n) => fmtMinutes(n)} />} />
        <Tile icon="run" label="Running distance" value={`${fmtNum(u.dist(cur.runKm), 1)} ${u.d}`} sub={<Delta cur={u.dist(cur.runKm) ?? 0} prev={u.dist(prev.runKm) ?? 0} fmt={(n) => `${fmtNum(n, 1)} ${u.d}`} />} />
        <Tile icon="flame" tone="warning" label="Calories burned" value={cur.calories ? fmtNum(cur.calories) : '–'} sub={cur.calories ? <Delta cur={cur.calories} prev={prev.calories} fmt={(n) => `${fmtNum(n)} kcal`} /> : 'not tracked'} />
        <Tile icon="timer" tone="violet" label="Avg workout" value={cur.avgWorkoutMin ? fmtMinutes(cur.avgWorkoutMin) : '–'} sub={prev.avgWorkoutMin ? <Delta cur={cur.avgWorkoutMin} prev={prev.avgWorkoutMin} fmt={(n) => fmtMinutes(n)} /> : undefined} />
        <Tile icon="scale" tone="info" label="Weight change" value={weight ? `${weight.delta > 0 ? '+' : ''}${fmtNum(u.weight(weight.delta), 1)} ${u.w}` : '–'} sub={weight ? `${fmtNum(u.weight(weight.first), 1)} → ${fmtNum(u.weight(weight.last), 1)}` : 'needs 2+ weigh-ins'} />
        <Tile icon="droplet" tone="water" label="Water goal hit" value={`${waterHit}/7 days`} sub={<Delta cur={waterHit} prev={prevWaterHit} fmt={(n) => `${n} days`} />} />
        <Tile icon="utensils" tone="success" label="Avg calories eaten" value={loggedDays ? fmtNum(nt.calories / loggedDays) : '–'} sub={loggedDays ? `P ${fmtNum(nt.protein / loggedDays)}g · ${loggedDays} day${loggedDays === 1 ? '' : 's'} logged` : 'no meals logged'} />
        <Tile icon="target" tone="violet" label="Most trained" value={<span style={{ fontSize: 20 }}>{topMuscle ?? '–'}</span>} />
        <Tile icon="flame" label="Current streak" value={`${streak} day${streak === 1 ? '' : 's'}`} />
      </div>
      <Card title="Muscle groups this week" icon="dumbbell">
        <HBars data={Object.entries(cur.muscleCounts).sort((a, b) => b[1] - a[1]).map(([label, value]) => ({ label, value }))} unit="×" />
      </Card>
    </>
  );
}

function Monthly() {
  const { workouts, tables } = useData();
  const profile = useProfile();
  const u = useUnits();
  const [month, setMonth] = useState(startOfMonth(todayISO()));
  const from = month, to = endOfMonth(month);
  const today = todayISO();
  const cur = periodStats(workouts, tables.running_sessions, from, to);
  const prev = periodStats(workouts, tables.running_sessions, addMonths(month, -1), endOfMonth(addMonths(month, -1)));
  const elapsedDays = daysBetween(from, to < today ? to : today).length;
  const act = activeDays(workouts, tables.running_sessions);
  const activeInMonth = [...act].filter((d) => d >= from && d <= to).length;
  const weeks = elapsedDays / 7;
  const workoutGoal = Math.round(profile.weekly_workout_target * weeks);
  const runGoal = profile.weekly_run_km_target * weeks;
  const weight = measurementChange(tables.body_measurements, 'weight_kg', from, to);
  const measureKeys: [keyof BodyMeasurement, string][] = [['waist_cm', 'Waist'], ['chest_cm', 'Chest'], ['arms_cm', 'Arms'], ['thighs_cm', 'Thighs'], ['hips_cm', 'Hips'], ['neck_cm', 'Neck'], ['body_fat_pct', 'Body fat']];
  const measureChanges = measureKeys.map(([k, l]) => ({ l, k, c: measurementChange(tables.body_measurements, k, from, to) })).filter((x) => x.c);
  const topEx = Object.entries(cur.exerciseCounts).sort((a, b) => b[1] - a[1]).slice(0, 6);
  const isCurrent = month === startOfMonth(today);

  const heat = useMemo(() => {
    const h: Record<string, number> = {};
    workouts.filter((w) => w.status === 'completed').forEach((w) => (h[w.date] = (h[w.date] ?? 0) + 1));
    tables.running_sessions.filter((r) => r.status === 'completed').forEach((r) => (h[r.date] = (h[r.date] ?? 0) + 1));
    return h;
  }, [workouts, tables.running_sessions]);
  const gridStart = startOfWeek(from);
  const cells = daysBetween(gridStart, endOfWeek(to));

  return (
    <>
      <div className="row">
        <IconButton icon="left" label="Previous month" variant="secondary" onClick={() => setMonth(addMonths(month, -1))} />
        <div className="grow center strong">{fmtMonth(month)}</div>
        <IconButton icon="right" label="Next month" variant="secondary" disabled={isCurrent} onClick={() => setMonth(addMonths(month, 1))} />
      </div>
      <div className="grid g4">
        <Tile icon="dumbbell" label="Workouts" value={cur.completed} sub={<Delta cur={cur.completed} prev={prev.completed} fmt={(n) => fmtNum(n)} />} />
        <Tile icon="clock" tone="info" label="Exercise time" value={fmtMinutes(cur.minutes)} sub={<Delta cur={cur.minutes} prev={prev.minutes} fmt={fmtMinutes} />} />
        <Tile icon="run" tone="accent" label="Running distance" value={`${fmtNum(u.dist(cur.runKm), 1)} ${u.d}`} sub={`${cur.runs} runs`} />
        <Tile icon="scale" tone="violet" label="Weight change" value={weight ? `${weight.delta > 0 ? '+' : ''}${fmtNum(u.weight(weight.delta), 1)} ${u.w}` : '–'} sub={weight ? `${fmtNum(u.weight(weight.first), 1)} → ${fmtNum(u.weight(weight.last), 1)} ${u.w}` : 'needs 2+ weigh-ins'} />
        <Tile icon="target" tone="success" label="Workout goal" value={`${cur.completed}/${workoutGoal}`} sub={`${workoutGoal ? Math.round((cur.completed / workoutGoal) * 100) : 0}% of target so far`} />
        <Tile icon="pin" tone="warning" label="Running goal" value={`${fmtNum(u.dist(cur.runKm), 1)}/${fmtNum(u.dist(runGoal), 0)}`} sub={`${runGoal ? Math.round((cur.runKm / runGoal) * 100) : 0}% of target so far`} />
        <Tile icon="calendar" tone="info" label="Consistency" value={`${activeInMonth}/${elapsedDays} days`} sub={`${elapsedDays ? Math.round((activeInMonth / elapsedDays) * 100) : 0}% active days`} />
        <Tile icon="flame" tone="warning" label="Calories burned" value={cur.calories ? fmtNum(cur.calories) : '–'} sub={cur.calories ? 'kcal from logged sessions' : 'not tracked'} />
      </div>
      <div className="grid g2">
        <Card title="Activity calendar" icon="calendar">
          <div className="cal-grid" style={{ borderRadius: 12 }} role="img" aria-label={`Active days in ${fmtMonth(month)}: ${activeInMonth}`}>
            {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d, i) => (
              <div key={i} className="cal-dow">
                {d}
              </div>
            ))}
            {cells.map((d) => {
              const v = heat[d] ?? 0;
              const inMonth = d >= from && d <= to;
              return (
                <div key={d} className={`cal-cell ${inMonth ? '' : 'other'}`} style={{ minHeight: 40, cursor: 'default', alignItems: 'center', justifyContent: 'center' }} title={`${fmtDate(d)}: ${v} activities`}>
                  <span className={`hm hm-${inMonth ? Math.min(4, v * 2) : 0}`} style={{ width: 26, height: 26, display: 'grid', placeItems: 'center', fontSize: 11, fontWeight: 600, color: v >= 2 ? 'var(--on-accent)' : undefined }}>
                    {parseISO(d).getDate()}
                  </span>
                </div>
              );
            })}
          </div>
        </Card>
        <Card title="Most common exercises" icon="list">
          {topEx.length ? <HBars data={topEx.map(([label, value]) => ({ label, value }))} unit="×" /> : <p className="muted">No exercises logged this month.</p>}
        </Card>
        <Card title="Body measurement changes" icon="target">
          {measureChanges.length ? (
            <ul className="stack-sm">
              {measureChanges.map(({ l, k, c }) => (
                <li key={k as string} className="row between">
                  <span className="strong">{l}</span>
                  <span>
                    {k === 'body_fat_pct' ? `${fmtNum(c!.first, 1)}% → ${fmtNum(c!.last, 1)}%` : `${u.fmtLen(c!.first)} → ${u.fmtLen(c!.last)}`}{' '}
                    <b className={c!.delta <= 0 ? 'success-text' : 'muted'}>
                      ({c!.delta > 0 ? '+' : ''}
                      {k === 'body_fat_pct' ? fmtNum(c!.delta, 1) : fmtNum(u.len(c!.delta), 1)})
                    </b>
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="muted">Needs at least two entries with the same measurement this month.</p>
          )}
        </Card>
        <Card title="Muscle groups" icon="dumbbell">
          <HBars data={Object.entries(cur.muscleCounts).sort((a, b) => b[1] - a[1]).map(([label, value]) => ({ label, value }))} unit="×" />
        </Card>
      </div>
    </>
  );
}
