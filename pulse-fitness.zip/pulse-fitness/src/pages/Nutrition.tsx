import { useEffect, useMemo, useState } from 'react';
import { useData, useProfile } from '../hooks/useData';
import { useRouter } from '../router';
import { useConfirm } from '../components/ui/Confirm';
import { PageHeader, Card, EmptyState, ProgressBar, Tabs, Badge, SearchBox } from '../components/ui/Misc';
import { Button, IconButton } from '../components/ui/Button';
import { Input, NumberInput, Select, Textarea, Toggle, Segmented } from '../components/ui/Field';
import { Modal } from '../components/ui/Modal';
import { Icon } from '../components/Icon';
import { Ring } from '../components/charts/Charts';
import { addDays, fmtLongDate, isValidISO, relativeDay, todayISO } from '../utils/date';
import { fmtNum } from '../utils/format';
import { nutritionTotals } from '../utils/stats';
import { uuid } from '../utils/id';
import { Validator } from '../utils/validate';
import { GOAL_BY_ID, type MealFocus } from '../data/goals';
import { MEAL_DISCLAIMER, MEAL_FOCUS_LABEL, MEAL_IDEAS, NUTRITION_TIPS, type MealIdea } from '../data/meals';
import type { Food, MealType, NutritionEntry, PlanMealType } from '../types';

export const MEALS: { value: MealType; label: string }[] = [
  { value: 'breakfast', label: 'Breakfast' },
  { value: 'morning_snack', label: 'Morning snack' },
  { value: 'lunch', label: 'Lunch' },
  { value: 'afternoon_snack', label: 'Afternoon snack' },
  { value: 'dinner', label: 'Dinner' },
  { value: 'evening_snack', label: 'Evening snack' },
];

function defaultMealForNow(): MealType {
  const h = new Date().getHours();
  if (h < 10) return 'breakfast';
  if (h < 12) return 'morning_snack';
  if (h < 14) return 'lunch';
  if (h < 17) return 'afternoon_snack';
  if (h < 21) return 'dinner';
  return 'evening_snack';
}

const slotToMeal = (s: PlanMealType): MealType => (s === 'snack' ? 'afternoon_snack' : s);

export default function NutritionPage() {
  const data = useData();
  const { tables } = data;
  const profile = useProfile();
  const { query, navigate } = useRouter();
  const confirm = useConfirm();
  const [tab, setTab] = useState<'log' | 'ideas' | 'foods'>('log');
  const qd = query.get('date');
  const [date, setDate] = useState(qd && isValidISO(qd) ? qd : todayISO());
  const [editing, setEditing] = useState<NutritionEntry | null>(null);
  const [foodEditing, setFoodEditing] = useState<Food | null>(null);
  const [copying, setCopying] = useState<MealType | null>(null);

  useEffect(() => {
    if (query.get('add')) {
      setEditing(blankEntry(date, defaultMealForNow()));
      navigate('/nutrition', { replace: true });
    } else if (qd && isValidISO(qd)) {
      setDate(qd);
      navigate('/nutrition', { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  const entries = tables.nutrition_entries.filter((e) => e.date === date);
  const totals = nutritionTotals(entries);
  const water = tables.water_entries.filter((w) => w.date === date).reduce((a, w) => a + w.amount_ml, 0);

  async function removeEntry(e: NutritionEntry) {
    if (await confirm({ title: 'Remove food?', message: `“${e.food_name}” will be removed from ${relativeDay(e.date).toLowerCase()}'s log.`, confirmLabel: 'Remove', danger: true })) await data.remove('nutrition_entries', e, { toast: 'Removed' });
  }

  async function copyYesterday(meal: MealType) {
    const src = tables.nutrition_entries.filter((e) => e.date === addDays(date, -1) && e.meal_type === meal);
    if (!src.length) return;
    setCopying(meal);
    await data.saveMany('nutrition_entries', src.map((e) => ({ ...e, id: uuid(), date, created_at: undefined, updated_at: undefined })), { toast: `Copied ${src.length} item${src.length === 1 ? '' : 's'}` });
    setCopying(null);
  }

  const macro = (l: string, v: number, t: number, tone: string, unit = 'g') => (
    <div className="macro" key={l}>
      <div className="macro-head">
        <span className="strong">{l}</span>
        <span className="muted">
          {fmtNum(v)} / {fmtNum(t)} {unit}
        </span>
      </div>
      <ProgressBar value={v} max={t} tone={v > t * 1.1 && l !== 'Protein' && l !== 'Fiber' ? 'warning' : tone} label={`${l}`} />
    </div>
  );

  return (
    <div className="stack">
      <PageHeader title="Nutrition" subtitle="Track meals and macros against your targets" actions={<Button variant="primary" icon="plus" onClick={() => setEditing(blankEntry(date, date === todayISO() ? defaultMealForNow() : 'breakfast'))}>Add food</Button>} />
      <Tabs
        label="Nutrition sections"
        value={tab}
        onChange={setTab}
        tabs={[
          { value: 'log', label: 'Food log', icon: 'list' },
          { value: 'ideas', label: 'Meal ideas', icon: 'sparkle' },
          { value: 'foods', label: `My foods (${tables.foods.length})`, icon: 'star' },
        ]}
      />

      {tab === 'log' && (
        <>
          <div className="row">
            <IconButton icon="left" label="Previous day" variant="secondary" onClick={() => setDate(addDays(date, -1))} />
            <div className="grow center">
              <div className="strong">{relativeDay(date)}</div>
              <div className="xs muted">{fmtLongDate(date)}</div>
            </div>
            <IconButton icon="right" label="Next day" variant="secondary" onClick={() => setDate(addDays(date, 1))} />
            {date !== todayISO() && <Button size="sm" onClick={() => setDate(todayISO())}>Today</Button>}
          </div>

          <Card>
            <div className="row" style={{ gap: 20, alignItems: 'center', flexWrap: 'wrap', justifyContent: 'center' }}>
              <Ring value={totals.calories} max={profile.calorie_target} size={132} stroke={12} tone={totals.calories > profile.calorie_target ? 'warning' : 'success'} label="Calories">
                <span className="ring-big" style={{ fontSize: 26 }}>
                  {fmtNum(totals.calories)}
                </span>
                <span className="ring-small">of {fmtNum(profile.calorie_target)} kcal</span>
                <span className="ring-small">{totals.calories <= profile.calorie_target ? `${fmtNum(profile.calorie_target - totals.calories)} left` : `${fmtNum(totals.calories - profile.calorie_target)} over`}</span>
              </Ring>
              <div className="grow stack-sm" style={{ minWidth: 220 }}>
                {macro('Protein', totals.protein, profile.protein_target, 'accent')}
                {macro('Carbs', totals.carbs, profile.carbs_target, 'info')}
                {macro('Fat', totals.fat, profile.fat_target, 'violet')}
                {macro('Fiber', totals.fiber, profile.fiber_target, 'success')}
                {macro('Water', water, profile.water_target_ml, 'water', 'ml')}
              </div>
            </div>
            {totals.sugar > 0 && <p className="xs muted" style={{ marginTop: 10 }}>Sugar: {fmtNum(totals.sugar)} g</p>}
          </Card>

          <Card padded={false}>
            {MEALS.map((m) => {
              const list = entries.filter((e) => e.meal_type === m.value);
              const kcal = list.reduce((a, e) => a + (e.calories ?? 0), 0);
              const hasYesterday = tables.nutrition_entries.some((e) => e.date === addDays(date, -1) && e.meal_type === m.value);
              return (
                <div key={m.value} className="meal-block">
                  <div className="meal-head">
                    <div>
                      <div className="strong">{m.label}</div>
                      <div className="xs muted">{list.length ? `${fmtNum(kcal)} kcal · ${list.length} item${list.length === 1 ? '' : 's'}` : 'Nothing logged'}</div>
                    </div>
                    <div className="row" style={{ gap: 4 }}>
                      {!list.length && hasYesterday && (
                        <Button size="sm" variant="ghost" icon="copy" loading={copying === m.value} onClick={() => copyYesterday(m.value)}>
                          Yesterday
                        </Button>
                      )}
                      <IconButton icon="plus" label={`Add to ${m.label}`} size="sm" variant="secondary" onClick={() => setEditing(blankEntry(date, m.value))} />
                    </div>
                  </div>
                  {list.map((e) => (
                    <div key={e.id} className="food-row">
                      <button className="grow" style={{ border: 0, background: 'none', textAlign: 'left', padding: 0, cursor: 'pointer', minWidth: 0 }} onClick={() => setEditing(e)}>
                        <div className="strong ellipsis">{e.food_name}</div>
                        <div className="macro-inline">
                          {[e.serving_size, e.protein_g != null && `P ${fmtNum(e.protein_g)}g`, e.carbs_g != null && `C ${fmtNum(e.carbs_g)}g`, e.fat_g != null && `F ${fmtNum(e.fat_g)}g`].filter(Boolean).join(' · ') || 'No details'}
                        </div>
                      </button>
                      <span className="strong nowrap">{e.calories != null ? `${fmtNum(e.calories)} kcal` : '–'}</span>
                      <IconButton icon="trash" label={`Remove ${e.food_name}`} size="sm" onClick={() => removeEntry(e)} />
                    </div>
                  ))}
                </div>
              );
            })}
          </Card>
        </>
      )}

      {tab === 'ideas' && <MealIdeas onLog={(idea) => setEditing({ ...blankEntry(date, slotToMeal(idea.slot)), food_name: idea.title, calories: idea.calories, protein_g: idea.protein_g, carbs_g: idea.carbs_g, fat_g: idea.fat_g, notes: idea.description })} />}

      {tab === 'foods' && (
        <Card
          title="My foods"
          icon="star"
          action={
            <Button size="sm" icon="plus" onClick={() => setFoodEditing({ id: '', name: '', serving_size: null, calories: null, protein_g: null, carbs_g: null, fat_g: null, fiber_g: null, sugar_g: null })}>
              New
            </Button>
          }
          padded={false}
        >
          {tables.foods.length === 0 ? (
            <div style={{ padding: 16 }}>
              <EmptyState icon="star" title="No saved foods yet" message="Save foods you eat often for one-tap logging. Tick “Save to My foods” when adding food." />
            </div>
          ) : (
            <div className="list">
              {[...tables.foods]
                .sort((a, b) => a.name.localeCompare(b.name))
                .map((f) => (
                  <div key={f.id} className="list-item" style={{ cursor: 'default' }}>
                    <button className="grow" style={{ border: 0, background: 'none', textAlign: 'left', padding: 0, cursor: 'pointer', minWidth: 0 }} onClick={() => setFoodEditing(f)}>
                      <span className="list-title" style={{ display: 'block' }}>
                        {f.name}
                      </span>
                      <span className="list-sub" style={{ display: 'block' }}>
                        {[f.serving_size, f.calories != null && `${fmtNum(f.calories)} kcal`, f.protein_g != null && `P ${fmtNum(f.protein_g)}g`].filter(Boolean).join(' · ')}
                      </span>
                    </button>
                    <Button size="sm" icon="plus" onClick={() => setEditing({ ...blankEntry(date, date === todayISO() ? defaultMealForNow() : 'breakfast'), food_name: f.name, serving_size: f.serving_size, calories: f.calories, protein_g: f.protein_g, carbs_g: f.carbs_g, fat_g: f.fat_g, fiber_g: f.fiber_g, sugar_g: f.sugar_g })}>
                      Log
                    </Button>
                  </div>
                ))}
            </div>
          )}
        </Card>
      )}

      <EntryForm entry={editing} onClose={() => setEditing(null)} />
      <FoodForm food={foodEditing} onClose={() => setFoodEditing(null)} />
    </div>
  );
}

function blankEntry(date: string, meal: MealType): NutritionEntry {
  return { id: '', date, meal_type: meal, food_name: '', serving_size: null, calories: null, protein_g: null, carbs_g: null, fat_g: null, fiber_g: null, sugar_g: null, notes: null };
}

const MACRO_FIELDS = [
  ['calories', 'Calories', 'kcal'],
  ['protein_g', 'Protein', 'g'],
  ['carbs_g', 'Carbs', 'g'],
  ['fat_g', 'Fat', 'g'],
  ['fiber_g', 'Fiber', 'g'],
  ['sugar_g', 'Sugar', 'g'],
] as const;

function EntryForm({ entry, onClose }: { entry: NutritionEntry | null; onClose: () => void }) {
  const data = useData();
  const [f, setF] = useState<Record<string, string>>({});
  const [saveFood, setSaveFood] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [foodQ, setFoodQ] = useState('');
  const [last, setLast] = useState<NutritionEntry | null>(null);
  if (entry !== last) {
    setLast(entry);
    setErrors({});
    setSaveFood(false);
    setFoodQ('');
    if (entry)
      setF({
        date: entry.date,
        meal_type: entry.meal_type,
        food_name: entry.food_name,
        serving_size: entry.serving_size ?? '',
        notes: entry.notes ?? '',
        ...Object.fromEntries(MACRO_FIELDS.map(([k]) => [k, entry[k] == null ? '' : String(entry[k])])),
      });
  }
  const matches = useMemo(() => {
    const t = foodQ.trim().toLowerCase();
    return t ? data.tables.foods.filter((x) => x.name.toLowerCase().includes(t)).slice(0, 5) : [];
  }, [foodQ, data.tables.foods]);
  if (!entry) return null;
  const set = (k: string, v: string) => setF((p) => ({ ...p, [k]: v }));

  async function save() {
    if (!entry || saving) return;
    const v = new Validator();
    v.required('food_name', f.food_name.trim(), 'Please enter a food name.');
    v.date('date', f.date);
    const nums = Object.fromEntries(MACRO_FIELDS.map(([k, l]) => [k, v.number(k, f[k], { min: 0, max: k === 'calories' ? 10000 : 1000, label: l })]));
    setErrors(v.errors);
    if (!v.ok) return;
    setSaving(true);
    const row: NutritionEntry = { ...entry, id: entry.id || uuid(), date: f.date, meal_type: f.meal_type as MealType, food_name: f.food_name.trim(), serving_size: f.serving_size.trim() || null, notes: f.notes.trim() || null, ...(nums as Record<string, number | null>) } as NutritionEntry;
    const r = await data.save('nutrition_entries', row, { toast: entry.id ? 'Updated' : `Added to ${MEALS.find((m) => m.value === row.meal_type)?.label}` });
    if (r.ok && saveFood && !data.tables.foods.some((x) => x.name.toLowerCase() === row.food_name.toLowerCase())) {
      await data.save('foods', { id: uuid(), name: row.food_name, serving_size: row.serving_size, calories: row.calories, protein_g: row.protein_g, carbs_g: row.carbs_g, fat_g: row.fat_g, fiber_g: row.fiber_g, sugar_g: row.sugar_g });
    }
    setSaving(false);
    if (r.ok) onClose();
  }

  return (
    <Modal
      open
      title={entry.id ? 'Edit food' : 'Add food'}
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" icon="check" loading={saving} onClick={save}>
            Save
          </Button>
        </>
      }
    >
      {!entry.id && data.tables.foods.length > 0 && (
        <div className="stack-sm">
          <SearchBox value={foodQ} onChange={setFoodQ} placeholder="Search My foods" label="Search saved foods" />
          {matches.map((m) => (
            <button
              key={m.id}
              className="plan-item"
              style={{ border: 0, cursor: 'pointer', textAlign: 'left' }}
              onClick={() => {
                setF((p) => ({ ...p, food_name: m.name, serving_size: m.serving_size ?? '', ...Object.fromEntries(MACRO_FIELDS.map(([k]) => [k, m[k] == null ? '' : String(m[k])])) }));
                setFoodQ('');
              }}
            >
              <Icon name="star" size={14} />
              <span className="grow">{m.name}</span>
              <span className="muted xs">{m.calories != null ? `${fmtNum(m.calories)} kcal` : ''}</span>
            </button>
          ))}
        </div>
      )}
      <div className="form-grid">
        <Input label="Food" className="full" value={f.food_name} onChange={(e) => set('food_name', e.target.value)} error={errors.food_name} placeholder="e.g. Chicken tinola" />
        <Select label="Meal" value={f.meal_type} onChange={(e) => set('meal_type', e.target.value)}>
          {MEALS.map((m) => (
            <option key={m.value} value={m.value}>
              {m.label}
            </option>
          ))}
        </Select>
        <Input label="Date" type="date" value={f.date} onChange={(e) => set('date', e.target.value)} error={errors.date} />
        <Input label="Serving size" className="full" value={f.serving_size} onChange={(e) => set('serving_size', e.target.value)} placeholder="e.g. 1 bowl, 1 cup rice, 150 g" />
        {MACRO_FIELDS.map(([k, l, unit]) => (
          <NumberInput key={k} label={l} suffix={unit} value={f[k]} onChange={(e) => set(k, e.target.value)} error={errors[k]} />
        ))}
      </div>
      <Textarea label="Notes" value={f.notes} onChange={(e) => set('notes', e.target.value)} />
      {!entry.id && <Toggle label="Save to My foods" description="Reuse it later with one tap." checked={saveFood} onChange={setSaveFood} />}
      <p className="xs faint">All nutrition fields are optional — log as much or as little detail as you like.</p>
    </Modal>
  );
}

function FoodForm({ food, onClose }: { food: Food | null; onClose: () => void }) {
  const data = useData();
  const confirm = useConfirm();
  const [f, setF] = useState<Record<string, string>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [last, setLast] = useState<Food | null>(null);
  if (food !== last) {
    setLast(food);
    setErrors({});
    if (food) setF({ name: food.name, serving_size: food.serving_size ?? '', ...Object.fromEntries(MACRO_FIELDS.map(([k]) => [k, food[k] == null ? '' : String(food[k])])) });
  }
  if (!food) return null;
  const set = (k: string, v: string) => setF((p) => ({ ...p, [k]: v }));
  async function save() {
    if (!food || saving) return;
    const v = new Validator();
    v.required('name', f.name.trim(), 'Please enter a name.');
    const nums = Object.fromEntries(MACRO_FIELDS.map(([k, l]) => [k, v.number(k, f[k], { min: 0, max: 10000, label: l })]));
    setErrors(v.errors);
    if (!v.ok) return;
    setSaving(true);
    const r = await data.save('foods', { ...food, id: food.id || uuid(), name: f.name.trim(), serving_size: f.serving_size.trim() || null, ...(nums as Record<string, number | null>) } as Food, { toast: 'Food saved' });
    setSaving(false);
    if (r.ok) onClose();
  }
  return (
    <Modal
      open
      title={food.id ? 'Edit saved food' : 'New saved food'}
      onClose={onClose}
      footer={
        <>
          {food.id && (
            <Button
              variant="ghost"
              icon="trash"
              onClick={async () => {
                if (await confirm({ title: 'Delete saved food?', message: 'Past log entries are not affected.', confirmLabel: 'Delete', danger: true })) if ((await data.remove('foods', food, { toast: 'Deleted' })).ok) onClose();
              }}
            >
              Delete
            </Button>
          )}
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" loading={saving} onClick={save}>
            Save
          </Button>
        </>
      }
    >
      <div className="form-grid">
        <Input label="Name" className="full" value={f.name} onChange={(e) => set('name', e.target.value)} error={errors.name} />
        <Input label="Serving size" className="full" value={f.serving_size} onChange={(e) => set('serving_size', e.target.value)} />
        {MACRO_FIELDS.map(([k, l, unit]) => (
          <NumberInput key={k} label={l} suffix={unit} value={f[k]} onChange={(e) => set(k, e.target.value)} error={errors[k]} />
        ))}
      </div>
    </Modal>
  );
}

// ------------------------------------------------------------ recommendations
export function MealIdeas({ onLog, onPlan }: { onLog?: (m: MealIdea) => void; onPlan?: (m: MealIdea) => void }) {
  const profile = useProfile();
  const goalFocus = (profile.goals.map((g) => GOAL_BY_ID[g]?.mealFocus).find(Boolean) ?? 'balanced') as MealFocus;
  const [focus, setFocus] = useState<MealFocus>(goalFocus);
  const [filipino, setFilipino] = useState(false);
  const [slot, setSlot] = useState<PlanMealType | 'all'>('all');
  const ideas = MEAL_IDEAS.filter((m) => m.focus.includes(focus) && (!filipino || m.filipino) && (slot === 'all' || m.slot === slot));

  return (
    <div className="stack">
      <Card>
        <div className="stack">
          <Select label="Suggestions for" value={focus} onChange={(e) => setFocus(e.target.value as MealFocus)} hint={profile.goals.length ? `Based on your goal: ${profile.goals[0]}` : 'Set goals on the Programs page to personalise this.'}>
            {(Object.keys(MEAL_FOCUS_LABEL) as MealFocus[]).map((k) => (
              <option key={k} value={k}>
                {MEAL_FOCUS_LABEL[k]}
              </option>
            ))}
          </Select>
          <Segmented<PlanMealType | 'all'>
            label="Meal"
            value={slot}
            onChange={setSlot}
            size="sm"
            options={[
              { value: 'all', label: 'All' },
              { value: 'breakfast', label: 'Breakfast' },
              { value: 'lunch', label: 'Lunch' },
              { value: 'dinner', label: 'Dinner' },
              { value: 'snack', label: 'Snacks' },
            ]}
          />
          <Toggle label="Filipino-friendly only" description="Local, home-cooked options" checked={filipino} onChange={setFilipino} />
        </div>
      </Card>
      <Card title="Tips" icon="info">
        <ul className="stack-sm">
          {NUTRITION_TIPS[focus].map((t) => (
            <li key={t} className="row" style={{ alignItems: 'flex-start' }}>
              <Icon name="check" size={16} className="success-text" style={{ marginTop: 3, flexShrink: 0 }} />
              <span>{t}</span>
            </li>
          ))}
        </ul>
      </Card>
      {ideas.length === 0 ? (
        <EmptyState icon="utensils" title="No ideas match" message="Try another meal or turn off the filter." />
      ) : (
        <div className="grid g2">
          {ideas.map((m) => (
            <div key={m.title} className="card meal-idea">
              <div className="row between" style={{ alignItems: 'flex-start' }}>
                <div className="strong">{m.title}</div>
                <Badge tone="info">{m.slot}</Badge>
              </div>
              <p className="small muted">{m.description}</p>
              <div className="row-wrap xs">
                <Badge>~{m.calories} kcal</Badge>
                <Badge tone="accent">P {m.protein_g}g</Badge>
                <Badge tone="info">C {m.carbs_g}g</Badge>
                <Badge tone="violet">F {m.fat_g}g</Badge>
                {m.filipino && <Badge tone="success">🇵🇭 Local</Badge>}
              </div>
              <div className="row-wrap">
                {onLog && (
                  <Button size="sm" icon="plus" onClick={() => onLog(m)}>
                    Log it
                  </Button>
                )}
                {onPlan && (
                  <Button size="sm" icon="calendar" onClick={() => onPlan(m)}>
                    Add to plan
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
      <p className="xs faint">{MEAL_DISCLAIMER} Values are approximate.</p>
    </div>
  );
}
