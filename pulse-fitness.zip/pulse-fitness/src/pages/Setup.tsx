import { Brand } from '../components/layout/AppShell';
import { Icon } from '../components/Icon';

/** Shown only when the Supabase environment variables are missing. */
export default function SetupPage() {
  return (
    <div className="auth">
      <div className="auth-card" style={{ maxWidth: 560 }}>
        <Brand />
        <div className="card stack">
          <div className="alert alert-info">
            <Icon name="info" size={18} />
            <span>This app isn't connected to its database yet.</span>
          </div>
          <ol className="stack-sm" style={{ paddingLeft: 20, listStyle: 'decimal' }}>
            <li>Create a free project at supabase.com.</li>
            <li>
              Open <b>SQL Editor</b>, paste the contents of <code>supabase/schema.sql</code> and click <b>Run</b>.
            </li>
            <li>
              In <b>Project Settings → API</b>, copy the Project URL and the <i>anon public</i> key.
            </li>
            <li>
              Set them as <code>VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_ANON_KEY</code> — in a <code>.env</code> file locally, or in Netlify under <b>Site configuration → Environment variables</b> — then rebuild/redeploy.
            </li>
          </ol>
          <p className="muted small">Full step-by-step instructions are in README.md.</p>
        </div>
      </div>
    </div>
  );
}
