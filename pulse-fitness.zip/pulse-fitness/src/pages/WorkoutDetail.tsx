import { useState } from 'react';
import { useData } from '../hooks/useData';
import { useUnits } from '../hooks/useUnits';
import { useWorkoutActions } from '../hooks/useWorkoutActions';
import { useRouter, Link } from '../router';
import { PageHeader, Card, EmptyState, StatusBadge, Badge, Stat } from '../components/ui/Misc';
import { Button, IconButton } from '../components/ui/Button';
import { DateDialog } from '../components/workout/DateDialog';
import { fmtLongDate } from '../utils/date';
import { fmtMinutes, fmtNum, label } from '../utils/format';
import { workoutMinutes, workoutTotals } from '../utils/calc';
import { autoRecords } from '../utils/stats';

export default function WorkoutDetailPage({ id }: { id: string }) {
  const { workouts, tables } = useData();
  const u = useUnits();
  const actions = useWorkoutActions();
  const { navigate } = useRouter();
  const [dialog, setDialog] = useState<'reschedule' | 'duplicate' | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const w = workouts.find((x) => x.id === id);

  if (!w)
    return (
      <EmptyState icon="info" title="Workout not found" message="It may have been deleted." action={<Link to="/workouts" className="btn btn-primary btn-md">Back to workouts</Link>} />
    );

  const t = workoutTotals(w);
  const mins = workoutMinutes(w);
  const prs = autoRecords(workouts, tables.running_sessions).lifts.filter((p) => p.date === w.date && w.exercises.some((e) => e.name === p.title));

  const run = async (key: string, fn: () => Promise<unknown>) => {
    setBusy(key);
    try {
      await fn();
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="stack">
      <PageHeader
        back={<IconButton icon="left" label="Back" onClick={() => (history.length > 1 ? history.back() : navigate('/workouts'))} />}
        title={w.name}
        subtitle={
          <span className="row-wrap">
            <span>{fmtLongDate(w.date)}</span>
            <StatusBadge status={w.status} />
            {w.program_name && <Badge tone="violet">{w.program_name}</Badge>}
          </span>
        }
      />

      <div className="row-wrap">
        {w.status !== 'completed' && (
          <Button variant="primary" icon="play" onClick={() => navigate(`/live/${w.id}`)}>
            {w.status === 'in_progress' ? 'Resume live workout' : 'Start live workout'}
          </Button>
        )}
        {w.status !== 'completed' && (
          <Button icon="check" loading={busy === 'complete'} onClick={() => run('complete', () => actions.setStatus(w, 'completed'))}>
            Mark completed
          </Button>
        )}
        {w.status === 'planned' && (
          <Button icon="skip" loading={busy === 'skip'} onClick={() => run('skip', () => actions.setStatus(w, 'skipped'))}>
            Skip
          </Button>
        )}
        {(w.status === 'completed' || w.status === 'skipped') && (
          <Button icon="rotate" loading={busy === 'plan'} onClick={() => run('plan', () => actions.setStatus(w, 'planned'))}>
            Set back to planned
          </Button>
        )}
        <Button icon="edit" onClick={() => navigate(`/workouts/${w.id}/edit`)}>
          Edit
        </Button>
        <Button icon="calendar" onClick={() => setDialog('reschedule')}>
          Reschedule
        </Button>
        <Button icon="copy" onClick={() => setDialog('duplicate')}>
          Duplicate
        </Button>
        <Button
          icon="trash"
          variant="ghost"
          onClick={async () => {
            if (await actions.remove(w)) navigate('/workouts', { replace: true });
          }}
        >
          Delete
        </Button>
      </div>

      <div className="grid g4">
        <div className="card stat-card">
          <Stat label="Duration" icon="clock" value={mins ? fmtMinutes(mins) : '–'} />
        </div>
        <div className="card stat-card">
          {w.status === 'completed' || t.sets > 0 ? (
            <Stat label="Sets · Reps" icon="list" tone="info" value={`${t.sets} · ${fmtNum(t.reps)}`} />
          ) : (
            <Stat label="Planned sets" icon="list" tone="info" value={w.exercises.reduce((a, e) => a + e.sets.length, 0)} sub={`${w.exercises.length} exercises`} />
          )}
        </div>
        <div className="card stat-card">
          <Stat label="Volume" icon="dumbbell" tone="violet" value={t.volumeKg ? fmtNum(u.weight(t.volumeKg), 0) : '–'} unit={t.volumeKg ? u.w : undefined} />
        </div>
        <div className="card stat-card">
          <Stat label="Calories" icon="flame" tone="warning" value={w.calories ?? '–'} unit={w.calories ? 'kcal' : undefined} />
        </div>
      </div>

      {prs.length > 0 && (
        <div className="alert alert-success">
          🏆 Personal record{prs.length > 1 ? 's' : ''} in this workout: {prs.map((p) => `${p.title} (${p.kind === 'weight' ? u.fmtWeight(p.value) : `${p.value} reps`})`).join(', ')}
        </div>
      )}

      <Card title="Exercises" icon="list">
        {w.exercises.length === 0 ? (
          <p className="muted">No exercises logged for this workout.</p>
        ) : (
          <div className="stack-sm">
            {w.exercises.map((e, i) => (
              <div key={e.id} className="ex-card">
                <div className="row between">
                  <div className="grow">
                    <div className="strong" style={e.skipped ? { textDecoration: 'line-through' } : undefined}>
                      {i + 1}. {e.name}
                    </div>
                    <div className="small muted">
                      {[e.muscle_group, e.target_reps && `target ${e.target_sets ?? ''}×${e.target_reps}`, e.rest_seconds != null && `${e.rest_seconds}s rest`].filter(Boolean).join(' · ')}
                    </div>
                  </div>
                  {e.skipped && <Badge>Skipped</Badge>}
                </div>
                {e.sets.length > 0 && (
                  <div className="row-wrap">
                    {e.sets.map((s, si) => (
                      <span key={s.id} className={`set-chip ${s.completed ? 'done' : ''}`}>
                        {s.completed && '✓ '}
                        {si + 1}: {s.reps ?? '–'} × {s.weight_kg != null ? u.fmtWeight(s.weight_kg) : 'BW'}
                      </span>
                    ))}
                  </div>
                )}
                {e.notes && <p className="small muted">{e.notes}</p>}
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card title="Details" icon="info">
        <dl className="kv">
          <div>
            <dt>Type</dt>
            <dd>{label(w.workout_type)}</dd>
          </div>
          <div>
            <dt>Time</dt>
            <dd>{w.start_time ? `${w.start_time}${w.end_time ? ` – ${w.end_time}` : ''}` : '–'}</dd>
          </div>
          <div>
            <dt>Muscle groups</dt>
            <dd>{w.muscle_groups.join(', ') || '–'}</dd>
          </div>
          <div>
            <dt>Distance</dt>
            <dd>{w.distance_km ? u.fmtDist(w.distance_km) : '–'}</dd>
          </div>
          <div>
            <dt>Difficulty</dt>
            <dd>{w.difficulty ? `${w.difficulty}/10` : '–'}</dd>
          </div>
          <div>
            <dt>Energy</dt>
            <dd>{w.energy_level ? `${w.energy_level}/5` : '–'}</dd>
          </div>
          <div>
            <dt>Mood</dt>
            <dd>{w.mood ?? '–'}</dd>
          </div>
        </dl>
        {w.notes && (
          <>
            <div className="divider" style={{ margin: '14px 0' }} />
            <p style={{ whiteSpace: 'pre-wrap' }}>{w.notes}</p>
          </>
        )}
      </Card>

      <DateDialog
        open={dialog === 'reschedule'}
        title="Reschedule workout"
        initial={w.date}
        confirmLabel="Move"
        onClose={() => setDialog(null)}
        onConfirm={async (d) => {
          const r = await actions.reschedule(w, d);
          if (r.ok) setDialog(null);
        }}
      />
      <DateDialog
        open={dialog === 'duplicate'}
        title="Duplicate workout"
        confirmLabel="Duplicate"
        withKeepResults
        onClose={() => setDialog(null)}
        onConfirm={async (d, keep) => {
          const copy = await actions.duplicate(w, d, keep);
          if (copy) {
            setDialog(null);
            navigate(`/workouts/${copy.id}`);
          }
        }}
      />
    </div>
  );
}
