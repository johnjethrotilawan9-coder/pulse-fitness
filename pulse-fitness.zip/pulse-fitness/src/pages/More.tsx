import { Link } from '../router';
import { PageHeader } from '../components/ui/Misc';
import { Icon } from '../components/Icon';
import { MAIN_NAV, MORE_NAV, useSignOut } from '../components/layout/AppShell';
import { useProfile } from '../hooks/useData';
import { useAuth } from '../hooks/useAuth';

const TONES = ['accent', 'info', 'success', 'violet', 'warning', 'water'];

export default function MorePage() {
  const profile = useProfile();
  const { user } = useAuth();
  const signOut = useSignOut();
  const items = [...MAIN_NAV.filter((n) => !['/', '/workouts', '/calendar', '/run'].includes(n.to)), ...MORE_NAV];
  return (
    <div className="stack">
      <PageHeader title="More" subtitle={profile.name || user?.email || undefined} />
      <div className="more-grid">
        {items.map((n, i) => (
          <Link key={n.to} to={n.to} className="more-tile">
            <span className={`list-icon tone-${TONES[i % TONES.length]}`}>
              <Icon name={n.icon} size={20} />
            </span>
            {n.label}
          </Link>
        ))}
      </div>
      <button className="btn btn-secondary btn-lg btn-block" onClick={() => void signOut()}>
        <Icon name="logout" size={18} /> Log out
      </button>
    </div>
  );
}
