import { useMemo, useState } from 'react';
import { useData } from '../hooks/useData';
import { useUnits } from '../hooks/useUnits';
import { useConfirm } from '../components/ui/Confirm';
import { PageHeader, Card, EmptyState, Badge, SearchBox } from '../components/ui/Misc';
import { Button, IconButton } from '../components/ui/Button';
import { Input, NumberInput, Select, Textarea } from '../components/ui/Field';
import { Modal } from '../components/ui/Modal';
import { Icon } from '../components/Icon';
import { autoRecords, type AutoPR } from '../utils/stats';
import { fmtDate, todayISO } from '../utils/date';
import { fmtDuration, fmtMinutes, fmtNum } from '../utils/format';
import { uuid } from '../utils/id';
import { Validator } from '../utils/validate';
import type { PersonalRecord } from '../types';

const CATEGORIES = ['strength', 'running', 'endurance', 'bodyweight', 'flexibility', 'other'];

export default function RecordsPage() {
  const data = useData();
  const u = useUnits();
  const confirm = useConfirm();
  const [editing, setEditing] = useState<PersonalRecord | null>(null);
  const [q, setQ] = useState('');
  const auto = useMemo(() => autoRecords(data.workouts, data.tables.running_sessions), [data.workouts, data.tables.running_sessions]);
  const manual = [...data.tables.personal_records].sort((a, b) => b.date.localeCompare(a.date));
  const lifts = auto.lifts.filter((l) => !q || l.title.toLowerCase().includes(q.toLowerCase()));

  const fmt = (p: AutoPR) =>
    p.kind === 'distance' ? u.fmtDist(p.value) : p.kind === 'duration' ? fmtDuration(p.value) : p.kind === 'minutes' ? fmtMinutes(p.value) : p.kind === 'weight' ? u.fmtWeight(p.value) : p.kind === 'days' ? `${p.value} day${p.value === 1 ? '' : 's'}` : p.kind === 'reps' ? `${p.value} reps` : `${p.value}`;

  const empty = !auto.general.length && !auto.lifts.length && !manual.length;

  return (
    <div className="stack">
      <PageHeader title="Personal records" subtitle="Calculated from your history, plus any you add" actions={<Button variant="primary" icon="plus" onClick={() => setEditing({ id: '', title: '', category: 'strength', value: 0, unit: null, date: todayISO(), exercise_name: null, notes: null })}>Add record</Button>} />
      {empty && (
        <Card>
          <EmptyState icon="trophy" title="No records yet" message="Complete workouts and runs and your personal bests appear here automatically. You can also add records manually." />
        </Card>
      )}
      {auto.general.length > 0 && (
        <div className="grid g3">
          {auto.general.map((p) => (
            <div key={p.id} className="card stat-card">
              <div className="stat">
                <div className="stat-label">
                  <span className="stat-icon tone-warning">
                    <Icon name="trophy" size={15} />
                  </span>
                  {p.title}
                </div>
                <div className="stat-value">{fmt(p)}</div>
                <div className="stat-sub">
                  {p.id === 'streak' ? 'best run of consecutive active days' : `${p.detail === 'week of' ? 'week of ' : ''}${fmtDate(p.date, { month: 'short', day: 'numeric', year: 'numeric' })}${p.detail && p.detail !== 'week of' ? ` · ${p.detail}` : ''}`}
                  {p.estimated && ' (est.)'}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      {auto.lifts.length > 0 && (
        <Card title="Lifting PRs" icon="dumbbell" action={<Badge>{auto.lifts.length} exercises</Badge>}>
          {auto.lifts.length > 8 && <div style={{ marginBottom: 10 }}><SearchBox value={q} onChange={setQ} placeholder="Filter exercises" /></div>}
          <div className="list">
            {lifts.map((p) => (
              <div key={p.id} className="list-item" style={{ cursor: 'default' }}>
                <span className="grow">
                  <span className="list-title" style={{ display: 'block' }}>{p.title}</span>
                  <span className="list-sub" style={{ display: 'block' }}>
                    {p.kind === 'weight' ? 'Heaviest weight' : 'Most reps (bodyweight)'} · {fmtDate(p.date, { month: 'short', day: 'numeric', year: 'numeric' })}
                    {p.detail ? ` · ${p.detail}` : ''}
                  </span>
                </span>
                <span className="list-meta strong" style={{ color: 'var(--text)', fontSize: 16 }}>{fmt(p)}</span>
              </div>
            ))}
          </div>
        </Card>
      )}
      <Card title="My records" icon="star" padded={false}>
        {manual.length === 0 ? (
          <p className="muted small" style={{ padding: '0 16px 16px' }}>Add records the app can't calculate — a race time, a max hold, a test result.</p>
        ) : (
          <div className="list">
            {manual.map((r) => (
              <div key={r.id} className="list-item" style={{ cursor: 'default' }}>
                <button className="grow" style={{ border: 0, background: 'none', textAlign: 'left', padding: 0, cursor: 'pointer', minWidth: 0 }} onClick={() => setEditing(r)}>
                  <span className="list-title" style={{ display: 'block' }}>{r.title}</span>
                  <span className="list-sub" style={{ display: 'block' }}>
                    {r.category} · {fmtDate(r.date, { month: 'short', day: 'numeric', year: 'numeric' })}
                    {r.exercise_name ? ` · ${r.exercise_name}` : ''}
                  </span>
                </button>
                <span className="list-meta strong" style={{ color: 'var(--text)', fontSize: 16 }}>
                  {fmtNum(r.value, 2)} {r.unit}
                </span>
                <IconButton
                  icon="trash"
                  size="sm"
                  label={`Delete ${r.title}`}
                  onClick={async () => {
                    if (await confirm({ title: 'Delete record?', message: r.title, confirmLabel: 'Delete', danger: true })) await data.remove('personal_records', r, { toast: 'Record deleted' });
                  }}
                />
              </div>
            ))}
          </div>
        )}
      </Card>
      <RecordForm rec={editing} onClose={() => setEditing(null)} />
    </div>
  );
}

function RecordForm({ rec, onClose }: { rec: PersonalRecord | null; onClose: () => void }) {
  const data = useData();
  const [f, setF] = useState<Record<string, string>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [last, setLast] = useState<PersonalRecord | null>(null);
  if (rec !== last) {
    setLast(rec);
    setErrors({});
    if (rec) setF({ title: rec.title, category: rec.category, value: rec.id ? String(rec.value) : '', unit: rec.unit ?? '', date: rec.date, exercise_name: rec.exercise_name ?? '', notes: rec.notes ?? '' });
  }
  if (!rec) return null;
  const set = (k: string, v: string) => setF((p) => ({ ...p, [k]: v }));
  async function save() {
    if (!rec || saving) return;
    const v = new Validator();
    v.required('title', f.title.trim(), 'Please describe the record.');
    v.date('date', f.date);
    const value = v.number('value', f.value, { required: true, label: 'Value', min: -1e9, max: 1e9 });
    setErrors(v.errors);
    if (!v.ok || value == null) return;
    setSaving(true);
    const r = await data.save('personal_records', { ...rec, id: rec.id || uuid(), title: f.title.trim(), category: f.category, value, unit: f.unit.trim() || null, date: f.date, exercise_name: f.exercise_name.trim() || null, notes: f.notes.trim() || null }, { toast: 'Record saved 🏆' });
    setSaving(false);
    if (r.ok) onClose();
  }
  return (
    <Modal
      open
      title={rec.id ? 'Edit record' : 'New personal record'}
      onClose={onClose}
      size="sm"
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" loading={saving} onClick={save}>Save</Button>
        </>
      }
    >
      <Input label="Record" value={f.title} onChange={(e) => set('title', e.target.value)} error={errors.title} placeholder="e.g. 10 km race, Plank hold" />
      <div className="form-grid">
        <NumberInput label="Value" value={f.value} onChange={(e) => set('value', e.target.value)} error={errors.value} />
        <Input label="Unit" value={f.unit} onChange={(e) => set('unit', e.target.value)} placeholder="kg, min, reps…" />
        <Select label="Category" value={f.category} onChange={(e) => set('category', e.target.value)}>
          {CATEGORIES.map((c) => <option key={c} value={c}>{c[0].toUpperCase() + c.slice(1)}</option>)}
        </Select>
        <Input label="Date" type="date" value={f.date} onChange={(e) => set('date', e.target.value)} error={errors.date} />
      </div>
      <Input label="Exercise (optional)" value={f.exercise_name} onChange={(e) => set('exercise_name', e.target.value)} />
      <Textarea label="Notes" value={f.notes} onChange={(e) => set('notes', e.target.value)} />
    </Modal>
  );
}
