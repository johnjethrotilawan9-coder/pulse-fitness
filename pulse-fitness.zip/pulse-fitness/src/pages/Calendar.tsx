import { useMemo, useState, type DragEvent } from 'react';
import { useData, useProfile } from '../hooks/useData';
import { useRouter } from '../router';
import { useConfirm } from '../components/ui/Confirm';
import { PageHeader, Card, EmptyState } from '../components/ui/Misc';
import { Button, IconButton } from '../components/ui/Button';
import { Segmented, Input, Select, Textarea, Toggle } from '../components/ui/Field';
import { Modal } from '../components/ui/Modal';
import { Icon, type IconName } from '../components/Icon';
import { DateDialog } from '../components/workout/DateDialog';
import { addDays, addMonths, fmtDate, fmtLongDate, fmtMonth, isValidISO, parseISO, startOfMonth, startOfWeek, todayISO } from '../utils/date';
import { uuid } from '../utils/id';
import { Validator } from '../utils/validate';
import { useUnits } from '../hooks/useUnits';
import type { CalendarEvent, CalendarEventType } from '../types';

type View = 'month' | 'week' | 'day';

interface Item {
  key: string;
  date: string;
  title: string;
  cls: string; // ev-* / dot-*
  icon: IconName;
  statusText: string;
  time?: string | null;
  kind: 'workout' | 'run' | 'event' | 'weigh' | 'meal';
  id: string;
  movable: boolean;
}

const EVENT_TYPES: { value: CalendarEventType; label: string }[] = [
  { value: 'rest', label: 'Rest day' },
  { value: 'note', label: 'Personal note' },
  { value: 'activity', label: 'Other activity' },
  { value: 'other', label: 'Other' },
];

export default function CalendarPage() {
  const data = useData();
  const { workouts, tables } = data;
  const profile = useProfile();
  const u = useUnits();
  const { navigate, query } = useRouter();
  const confirm = useConfirm();
  const today = todayISO();
  const initialDate = query.get('date');
  const [view, setView] = useState<View>('month');
  const [cursor, setCursor] = useState(initialDate && isValidISO(initialDate) ? initialDate : today);
  const [selected, setSelected] = useState(initialDate && isValidISO(initialDate) ? initialDate : today);
  const [editing, setEditing] = useState<CalendarEvent | null>(null);
  const [moving, setMoving] = useState<Item | null>(null);
  const [addOpen, setAddOpen] = useState(false);

  const items = useMemo(() => {
    const map: Record<string, Item[]> = {};
    const push = (i: Item) => (map[i.date] ??= []).push(i);
    workouts.forEach((w) =>
      push({ key: 'w' + w.id, id: w.id, kind: 'workout', date: w.date, title: w.name, cls: w.status, icon: w.status === 'completed' ? 'check' : w.status === 'skipped' ? 'skip' : 'dumbbell', statusText: { planned: 'Planned workout', in_progress: 'Workout in progress', completed: 'Completed workout', skipped: 'Skipped workout' }[w.status], time: w.start_time, movable: true }),
    );
    tables.running_sessions.forEach((r) =>
      push({ key: 'r' + r.id, id: r.id, kind: 'run', date: r.date, title: r.route_name || (r.status === 'planned' ? `Planned ${r.activity_type}` : `${r.activity_type[0].toUpperCase()}${r.activity_type.slice(1)} ${r.distance_km ? u.fmtDist(r.distance_km, 1) : ''}`), cls: r.status === 'skipped' ? 'skipped' : 'run', icon: 'run', statusText: r.status === 'planned' ? 'Planned run' : r.status === 'skipped' ? 'Skipped run' : 'Run', time: r.start_time, movable: r.status === 'planned' }),
    );
    tables.calendar_events.forEach((e) =>
      push({ key: 'e' + e.id, id: e.id, kind: 'event', date: e.date, title: e.title, cls: e.event_type === 'run' ? 'run' : e.event_type, icon: e.event_type === 'rest' ? 'bed' : e.event_type === 'note' ? 'note' : 'flag', statusText: EVENT_TYPES.find((t) => t.value === e.event_type)?.label ?? 'Event', time: e.start_time, movable: true }),
    );
    tables.body_measurements.forEach((m) =>
      push({ key: 'm' + m.id, id: m.id, kind: 'weigh', date: m.date, title: m.weight_kg != null ? `Weigh-in ${u.fmtWeight(m.weight_kg)}` : 'Measurements', cls: 'weigh', icon: 'scale', statusText: 'Weight check-in', movable: false }),
    );
    if (profile.show_meals_in_calendar)
      tables.meal_plans.forEach((p) => push({ key: 'p' + p.id, id: p.id, kind: 'meal', date: p.date, title: `${p.meal_type}: ${p.title}`, cls: 'meal', icon: 'utensils', statusText: 'Planned meal', movable: false }));
    const order = { workout: 0, run: 1, event: 2, weigh: 3, meal: 4 };
    Object.values(map).forEach((l) => l.sort((a, b) => order[a.kind] - order[b.kind] || (a.time ?? '').localeCompare(b.time ?? '')));
    return map;
  }, [workouts, tables, profile.show_meals_in_calendar, u]);

  function open(i: Item) {
    if (i.kind === 'workout') navigate(`/workouts/${i.id}`);
    else if (i.kind === 'run') navigate(`/run?id=${i.id}`);
    else if (i.kind === 'weigh') navigate('/progress');
    else if (i.kind === 'meal') navigate(`/meals?date=${i.date}`);
    else setEditing(tables.calendar_events.find((e) => e.id === i.id) ?? null);
  }

  async function move(i: Item, date: string) {
    if (i.date === date) return true;
    if (i.kind === 'workout') {
      const w = workouts.find((x) => x.id === i.id);
      if (!w) return false;
      return (await data.saveWorkout({ ...w, date, status: w.status === 'skipped' ? 'planned' : w.status }, { toast: `Moved to ${fmtDate(date)}` })).ok;
    }
    if (i.kind === 'run') {
      const r = tables.running_sessions.find((x) => x.id === i.id);
      return r ? (await data.save('running_sessions', { ...r, date }, { toast: `Moved to ${fmtDate(date)}` })).ok : false;
    }
    if (i.kind === 'event') {
      const e = tables.calendar_events.find((x) => x.id === i.id);
      return e ? (await data.save('calendar_events', { ...e, date }, { toast: `Moved to ${fmtDate(date)}` })).ok : false;
    }
    return false;
  }

  const onDrop = (date: string) => (ev: DragEvent) => {
    ev.preventDefault();
    const key = ev.dataTransfer.getData('text/plain');
    const it = Object.values(items).flat().find((x) => x.key === key);
    if (it?.movable) void move(it, date);
  };

  const step = (dir: -1 | 1) => {
    const next = view === 'month' ? addMonths(cursor, dir) : addDays(cursor, dir * (view === 'week' ? 7 : 1));
    setCursor(next);
    if (view === 'day') setSelected(next);
  };
  const title = view === 'month' ? fmtMonth(cursor) : view === 'week' ? `Week of ${fmtDate(startOfWeek(cursor), { month: 'short', day: 'numeric', year: 'numeric' })}` : fmtLongDate(cursor);

  const monthStart = startOfWeek(startOfMonth(cursor));
  const monthDays = Array.from({ length: 42 }, (_, i) => addDays(monthStart, i));
  const trimmed = monthDays[35].slice(0, 7) !== cursor.slice(0, 7) ? monthDays.slice(0, 35) : monthDays;
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(startOfWeek(cursor), i));
  const dayForPanel = view === 'day' ? cursor : selected;

  const pill = (i: Item) => (
    <div
      key={i.key}
      className={`cal-pill ev-${i.cls}`}
      draggable={i.movable}
      onDragStart={(e) => e.dataTransfer.setData('text/plain', i.key)}
      onClick={(e) => {
        e.stopPropagation();
        open(i);
      }}
      title={`${i.statusText}: ${i.title}`}
    >
      <Icon name={i.icon} size={11} strokeWidth={2.5} />
      <span>{i.title}</span>
    </div>
  );

  const itemRow = (i: Item) => (
    <div key={i.key} className="row" style={{ gap: 6 }}>
      <button className={`ev-item ev-${i.cls}`} onClick={() => open(i)} aria-label={`${i.statusText}: ${i.title}`}>
        <Icon name={i.icon} size={16} />
        <span>
          {i.time ? `${i.time} · ` : ''}
          {i.title}
        </span>
        <small style={{ opacity: 0.8, fontWeight: 600, flex: '0 0 auto' }}>{i.statusText.split(' ')[0]}</small>
      </button>
      {i.movable && <IconButton icon="calendar" label={`Move ${i.title} to another date`} size="sm" onClick={() => setMoving(i)} />}
    </div>
  );

  return (
    <div className="stack">
      <PageHeader title="Calendar" subtitle="Plan and review your training" actions={<Button variant="primary" icon="plus" onClick={() => setAddOpen(true)}>Add</Button>} />

      <div className="cal-toolbar">
        <IconButton icon="left" label="Previous" variant="secondary" onClick={() => step(-1)} />
        <IconButton icon="right" label="Next" variant="secondary" onClick={() => step(1)} />
        <Button
          size="md"
          onClick={() => {
            setCursor(today);
            setSelected(today);
          }}
        >
          Today
        </Button>
        <h2 className="cal-title grow">{title}</h2>
        <Segmented<View> label="Calendar view" value={view} onChange={setView} options={[{ value: 'month', label: 'Month' }, { value: 'week', label: 'Week' }, { value: 'day', label: 'Day' }]} />
      </div>

      {view === 'month' && (
        <div>
          <div className="cal-grid" role="grid" aria-label={fmtMonth(cursor)}>
            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => (
              <div key={d} className="cal-dow" role="columnheader">
                {d}
              </div>
            ))}
            {trimmed.map((d) => {
              const list = items[d] ?? [];
              const other = d.slice(0, 7) !== cursor.slice(0, 7);
              return (
                <button
                  key={d}
                  role="gridcell"
                  className={`cal-cell ${other ? 'other' : ''} ${d === today ? 'today' : ''} ${d === selected ? 'selected' : ''}`}
                  onClick={() => setSelected(d)}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={onDrop(d)}
                  aria-label={`${fmtLongDate(d)}: ${list.length ? list.map((i) => `${i.statusText} ${i.title}`).join(', ') : 'nothing scheduled'}`}
                  aria-selected={d === selected}
                >
                  <span className="cal-day">{parseISO(d).getDate()}</span>
                  <span className="cal-dots" aria-hidden>
                    {list.slice(0, 4).map((i) => (
                      <span key={i.key} className={`cal-dot dot-${i.cls}`} />
                    ))}
                  </span>
                  {list.slice(0, 3).map(pill)}
                  {list.length > 3 && <span className="xs muted desktop-only">+{list.length - 3} more</span>}
                </button>
              );
            })}
          </div>
          <div className="legend" aria-label="Legend">
            <span><i className="cal-dot dot-planned" /> Planned</span>
            <span><i className="cal-dot dot-completed" /> Completed</span>
            <span><i className="cal-dot dot-skipped" /> Skipped</span>
            <span><i className="cal-dot dot-run" /> Run</span>
            <span><i className="cal-dot dot-rest" /> Rest day</span>
            <span><i className="cal-dot dot-weigh" /> Weigh-in</span>
            <span><i className="cal-dot dot-note" /> Note</span>
            {profile.show_meals_in_calendar && <span><i className="cal-dot dot-meal" /> Meal plan</span>}
          </div>
          <p className="xs faint desktop-only" style={{ marginTop: 6 }}>
            Tip: drag a workout, planned run or event to another day to move it.
          </p>
        </div>
      )}

      {view === 'week' && (
        <div className="week-grid">
          {weekDays.map((d) => (
            <div key={d} className={`week-col ${d === today ? 'today' : ''}`} onDragOver={(e) => e.preventDefault()} onDrop={onDrop(d)}>
              <div className="row between">
                <button className="link-btn" style={{ padding: 0, color: 'var(--text)' }} onClick={() => { setCursor(d); setSelected(d); setView('day'); }}>
                  <b>{fmtDate(d, { weekday: 'short' })}</b> <span className="muted">{fmtDate(d)}</span>
                </button>
                <IconButton icon="plus" label={`Add on ${fmtDate(d)}`} size="sm" onClick={() => { setSelected(d); setAddOpen(true); }} />
              </div>
              {(items[d] ?? []).map((i) => (
                <button key={i.key} className={`ev-item ev-${i.cls}`} draggable={i.movable} onDragStart={(e) => e.dataTransfer.setData('text/plain', i.key)} onClick={() => open(i)} aria-label={`${i.statusText}: ${i.title}`}>
                  <Icon name={i.icon} size={14} />
                  <span>{i.title}</span>
                </button>
              ))}
              {!(items[d] ?? []).length && <span className="xs faint">—</span>}
            </div>
          ))}
        </div>
      )}

      {view !== 'week' && (
        <Card
          title={fmtLongDate(dayForPanel)}
          icon="calendar"
          action={
            <Button size="sm" icon="plus" onClick={() => { setSelected(dayForPanel); setAddOpen(true); }}>
              Add
            </Button>
          }
        >
          {(items[dayForPanel] ?? []).length === 0 ? (
            <p className="muted">Nothing on this day yet.</p>
          ) : (
            <div className="stack-sm">{(items[dayForPanel] ?? []).map(itemRow)}</div>
          )}
        </Card>
      )}

      <Modal open={addOpen} title={`Add to ${fmtDate(selected, { weekday: 'short', month: 'short', day: 'numeric' })}`} size="sm" onClose={() => setAddOpen(false)}>
        <div className="list">
          {[
            { icon: 'dumbbell' as IconName, label: 'Workout', sub: 'Plan or log a workout', go: () => navigate(`/workouts/new?date=${selected}`) },
            { icon: 'layers' as IconName, label: 'Program', sub: 'Schedule a workout program', go: () => navigate(`/programs?start=${selected}`) },
            { icon: 'run' as IconName, label: 'Planned run', sub: 'Schedule a run or walk', go: () => navigate(`/run?plan=${selected}`) },
            { icon: 'bed' as IconName, label: 'Rest day', sub: 'Mark as a recovery day', go: () => setEditing({ id: '', date: selected, title: 'Rest day', event_type: 'rest', start_time: null, notes: null, completed: false }) },
            { icon: 'note' as IconName, label: 'Note or other activity', sub: 'Personal note, sport, class…', go: () => setEditing({ id: '', date: selected, title: '', event_type: 'note', start_time: null, notes: null, completed: false }) },
            { icon: 'scale' as IconName, label: 'Weight check-in', sub: 'Log weight & measurements', go: () => navigate(`/progress?add=1&date=${selected}`) },
          ].map((o) => (
            <button
              key={o.label}
              className="list-item"
              style={{ paddingLeft: 0, paddingRight: 0 }}
              onClick={() => {
                setAddOpen(false);
                o.go();
              }}
            >
              <span className="list-icon tone-accent">
                <Icon name={o.icon} size={18} />
              </span>
              <span className="grow">
                <span className="list-title" style={{ display: 'block' }}>
                  {o.label}
                </span>
                <span className="list-sub" style={{ display: 'block' }}>
                  {o.sub}
                </span>
              </span>
            </button>
          ))}
        </div>
      </Modal>

      <EventModal
        event={editing}
        onClose={() => setEditing(null)}
        onDelete={async (e) => {
          const ok = await confirm({ title: 'Delete this entry?', message: `“${e.title}” on ${fmtDate(e.date)} will be removed.`, confirmLabel: 'Delete', danger: true });
          if (ok && (await data.remove('calendar_events', e, { toast: 'Deleted' })).ok) setEditing(null);
        }}
      />

      <DateDialog
        open={!!moving}
        title={`Move “${moving?.title ?? ''}”`}
        initial={moving?.date}
        confirmLabel="Move"
        onClose={() => setMoving(null)}
        onConfirm={async (d) => {
          if (moving && (await move(moving, d))) {
            setMoving(null);
            setSelected(d);
          }
        }}
      />

      {Object.keys(items).length === 0 && (
        <Card>
          <EmptyState icon="calendar" title="Your calendar is empty" message="Plan a workout, schedule a program, or mark rest days — they'll all show up here." />
        </Card>
      )}
    </div>
  );
}

function EventModal({ event, onClose, onDelete }: { event: CalendarEvent | null; onClose: () => void; onDelete: (e: CalendarEvent) => void }) {
  const data = useData();
  const [f, setF] = useState<CalendarEvent | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [last, setLast] = useState<CalendarEvent | null>(null);
  if (event !== last) {
    setLast(event);
    setF(event);
    setErrors({});
  }
  if (!f) return null;
  const isNew = !f.id;

  async function save() {
    if (!f || saving) return;
    const v = new Validator();
    v.required('title', f.title.trim(), 'Please add a title.');
    v.date('date', f.date);
    setErrors(v.errors);
    if (!v.ok) return;
    setSaving(true);
    const row: CalendarEvent = { ...f, id: f.id || uuid(), title: f.title.trim(), notes: f.notes?.trim() || null, start_time: f.start_time || null };
    const r = await data.save('calendar_events', row, { toast: isNew ? 'Added to calendar' : 'Saved' });
    setSaving(false);
    if (r.ok) onClose();
  }

  return (
    <Modal
      open
      title={isNew ? 'New calendar entry' : 'Edit entry'}
      onClose={onClose}
      size="sm"
      footer={
        <>
          {!isNew && (
            <Button variant="ghost" icon="trash" onClick={() => onDelete(f)}>
              Delete
            </Button>
          )}
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" loading={saving} onClick={save}>
            Save
          </Button>
        </>
      }
    >
      <Select label="Type" value={f.event_type} onChange={(e) => setF({ ...f, event_type: e.target.value as CalendarEventType, title: !f.title || f.title === 'Rest day' ? (e.target.value === 'rest' ? 'Rest day' : '') : f.title })}>
        {EVENT_TYPES.map((t) => (
          <option key={t.value} value={t.value}>
            {t.label}
          </option>
        ))}
      </Select>
      <Input label="Title" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} error={errors.title} placeholder="e.g. Basketball with friends" />
      <div className="form-grid">
        <Input label="Date" type="date" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} error={errors.date} />
        <Input label="Time (optional)" type="time" value={f.start_time ?? ''} onChange={(e) => setF({ ...f, start_time: e.target.value })} />
      </div>
      <Textarea label="Notes" value={f.notes ?? ''} onChange={(e) => setF({ ...f, notes: e.target.value })} />
      {f.event_type !== 'rest' && f.event_type !== 'note' && <Toggle label="Done" checked={f.completed} onChange={(v) => setF({ ...f, completed: v })} />}
    </Modal>
  );
}
