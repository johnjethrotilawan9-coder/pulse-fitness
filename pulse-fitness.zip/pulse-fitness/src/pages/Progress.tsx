import { useEffect, useMemo, useState } from 'react';
import { useData, useProfile } from '../hooks/useData';
import { useUnits } from '../hooks/useUnits';
import { useAuth } from '../hooks/useAuth';
import { useOnline } from '../hooks/useOnline';
import { useToast } from '../hooks/useToast';
import { useRouter } from '../router';
import { useConfirm } from '../components/ui/Confirm';
import { PageHeader, Card, EmptyState, Stat, ProgressBar, Tabs } from '../components/ui/Misc';
import { Button, IconButton } from '../components/ui/Button';
import { Input, NumberInput, Textarea, Segmented, Select } from '../components/ui/Field';
import { Modal } from '../components/ui/Modal';
import { LineChart, BarChart, Heatmap } from '../components/charts/Charts';
import { addDays, addMonths, fmtDate, isValidISO, todayISO } from '../utils/date';
import { fmtNum } from '../utils/format';
import { uuid } from '../utils/id';
import { Validator } from '../utils/validate';
import { activeDays, currentStreak, firstWeight, latestWeight, longestStreak, periodStats, weeklySeries } from '../utils/stats';
import { deleteProgressPhoto, photoUrl, uploadProgressPhoto } from '../services/storage';
import { toApiError } from '../services/api';
import type { BodyMeasurement, ProgressPhoto } from '../types';

const MEASURES: { key: keyof BodyMeasurement; label: string }[] = [
  { key: 'waist_cm', label: 'Waist' },
  { key: 'chest_cm', label: 'Chest' },
  { key: 'arms_cm', label: 'Arms' },
  { key: 'thighs_cm', label: 'Thighs' },
  { key: 'hips_cm', label: 'Hips' },
  { key: 'neck_cm', label: 'Neck' },
];

type Range = '1m' | '3m' | '6m' | '1y' | 'all';

export default function ProgressPage() {
  const data = useData();
  const { workouts, tables } = data;
  const profile = useProfile();
  const u = useUnits();
  const { query, navigate } = useRouter();
  const confirm = useConfirm();
  const [tab, setTab] = useState<'body' | 'training' | 'photos'>('body');
  const [range, setRange] = useState<Range>('3m');
  const [measure, setMeasure] = useState<keyof BodyMeasurement>('waist_cm');
  const [editing, setEditing] = useState<BodyMeasurement | null>(null);
  const today = todayISO();

  useEffect(() => {
    if (query.get('add')) {
      const d = query.get('date');
      setEditing(blank(d && isValidISO(d) ? d : today));
      navigate('/progress', { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  const ms = useMemo(() => [...tables.body_measurements].sort((a, b) => a.date.localeCompare(b.date) || (a.created_at ?? '').localeCompare(b.created_at ?? '')), [tables.body_measurements]);
  const from = range === 'all' ? '0000' : range === '1y' ? addMonths(today, -12) : addMonths(today, range === '1m' ? -1 : range === '3m' ? -3 : -6);
  const current = latestWeight(ms);
  const first = firstWeight(ms);
  const startKg = profile.start_weight_kg ?? first?.value ?? null;
  const currentKg = current?.value ?? profile.weight_kg;
  const goalKg = profile.goal_weight_kg;
  const remaining = currentKg != null && goalKg != null ? currentKg - goalKg : null;
  const progressPct = startKg != null && goalKg != null && currentKg != null && startKg !== goalKg ? Math.max(0, Math.min(100, ((startKg - currentKg) / (startKg - goalKg)) * 100)) : null;

  const weightPts = ms.filter((m) => m.weight_kg != null && m.date >= from).map((m) => ({ label: fmtDate(m.date), value: u.weight(m.weight_kg) }));
  const measurePts = ms.filter((m) => m[measure] != null && m.date >= from).map((m) => ({ label: fmtDate(m.date), value: u.len(m[measure] as number) }));
  const weeklyWeightChange = useMemo(() => {
    const w = weeklySeries(12, (a, b) => {
      const inWeek = ms.filter((m) => m.weight_kg != null && m.date >= a && m.date <= b);
      return inWeek.length ? (inWeek[inWeek.length - 1].weight_kg as number) : NaN;
    });
    const out: { label: string; value: number | null }[] = [];
    let prev: number | null = null;
    for (const p of w) {
      if (!isNaN(p.value)) {
        out.push({ label: p.label, value: prev != null ? u.weight(p.value - prev) : null });
        prev = p.value;
      } else out.push({ label: p.label, value: null });
    }
    return out;
  }, [ms, u]);

  const days = useMemo(() => activeDays(workouts, tables.running_sessions), [workouts, tables.running_sessions]);
  const heat = useMemo(() => {
    const h: Record<string, number> = {};
    workouts.filter((w) => w.status === 'completed').forEach((w) => (h[w.date] = (h[w.date] ?? 0) + 1));
    tables.running_sessions.filter((r) => r.status === 'completed').forEach((r) => (h[r.date] = (h[r.date] ?? 0) + 1));
    return h;
  }, [workouts, tables.running_sessions]);
  const freq = weeklySeries(12, (a, b) => periodStats(workouts, tables.running_sessions, a, b).completed);
  const runDist = weeklySeries(12, (a, b) => u.dist(periodStats(workouts, tables.running_sessions, a, b).runKm) ?? 0);
  const minutes = weeklySeries(12, (a, b) => Math.round(periodStats(workouts, tables.running_sessions, a, b).minutes));

  async function remove(m: BodyMeasurement) {
    if (await confirm({ title: 'Delete this entry?', message: `Measurements from ${fmtDate(m.date, { month: 'long', day: 'numeric', year: 'numeric' })} will be deleted.`, confirmLabel: 'Delete', danger: true })) await data.remove('body_measurements', m, { toast: 'Entry deleted' });
  }

  return (
    <div className="stack">
      <PageHeader title="Progress" subtitle="Body, training and photos" actions={<Button variant="primary" icon="plus" onClick={() => setEditing(blank(today))}>Log weigh-in</Button>} />
      <Tabs
        label="Progress sections"
        value={tab}
        onChange={setTab}
        tabs={[
          { value: 'body', label: 'Body', icon: 'scale' },
          { value: 'training', label: 'Training', icon: 'chart' },
          { value: 'photos', label: 'Photos', icon: 'camera' },
        ]}
      />

      {tab === 'body' && (
        <>
          <div className="grid g4">
            <div className="card stat-card">
              <Stat label="Starting" icon="flag" tone="info" value={startKg != null ? fmtNum(u.weight(startKg), 1) : '–'} unit={startKg != null ? u.w : undefined} sub={first && profile.start_weight_kg == null ? fmtDate(first.date) : profile.start_weight_kg != null ? 'set in settings' : undefined} />
            </div>
            <div className="card stat-card">
              <Stat label="Current" icon="scale" value={currentKg != null ? fmtNum(u.weight(currentKg), 1) : '–'} unit={currentKg != null ? u.w : undefined} sub={current ? `as of ${fmtDate(current.date)}` : undefined} />
            </div>
            <div className="card stat-card">
              <Stat label="Goal" icon="target" tone="success" value={goalKg != null ? fmtNum(u.weight(goalKg), 1) : '–'} unit={goalKg != null ? u.w : undefined} sub={goalKg == null ? 'set a goal when logging' : undefined} />
            </div>
            <div className="card stat-card">
              <Stat
                label="Remaining"
                icon="trend"
                tone="violet"
                value={remaining != null ? fmtNum(Math.abs(u.weight(remaining) ?? 0), 1) : '–'}
                unit={remaining != null ? u.w : undefined}
                sub={remaining == null ? undefined : Math.abs(remaining) < 0.05 ? 'Goal reached 🎉' : remaining > 0 ? 'to lose' : 'to gain'}
              />
            </div>
          </div>
          {progressPct != null && (
            <Card>
              <div className="macro">
                <div className="macro-head">
                  <span className="strong">Progress to goal</span>
                  <span className="muted">{Math.round(progressPct)}%</span>
                </div>
                <ProgressBar value={progressPct} max={100} tone="success" label="Progress to goal weight" />
              </div>
            </Card>
          )}

          {ms.length === 0 ? (
            <Card>
              <EmptyState icon="scale" title="No measurements yet" message="Log your weight and any body measurements you track. Only what you enter is saved — nothing is assumed." action={<Button variant="primary" icon="plus" onClick={() => setEditing(blank(today))}>Log first weigh-in</Button>} />
            </Card>
          ) : (
            <>
              <Segmented<Range> label="Chart range" value={range} onChange={setRange} size="sm" options={[{ value: '1m', label: '1M' }, { value: '3m', label: '3M' }, { value: '6m', label: '6M' }, { value: '1y', label: '1Y' }, { value: 'all', label: 'All' }]} />
              <div className="grid g2">
                <Card title={`Weight (${u.w})`} icon="scale">
                  <LineChart data={weightPts} unit={u.w} goal={goalKg != null ? u.weight(goalKg) : null} ariaLabel="Weight over time" />
                </Card>
                <Card title={`Weekly weight change (${u.w})`} icon="trend">
                  {weeklyWeightChange.some((p) => p.value != null) ? <LineChart data={weeklyWeightChange} unit={u.w} digits={2} tone="violet" ariaLabel="Week-over-week weight change" /> : <p className="muted small chart-empty">Needs weigh-ins in at least two different weeks.</p>}
                </Card>
                <Card
                  title="Body measurements"
                  icon="target"
                  action={
                    <Select label="Measurement" hideLabel value={measure as string} onChange={(e) => setMeasure(e.target.value as keyof BodyMeasurement)} style={{ height: 36, width: 120 }}>
                      {MEASURES.map((m) => (
                        <option key={m.key} value={m.key}>
                          {m.label}
                        </option>
                      ))}
                    </Select>
                  }
                >
                  <LineChart data={measurePts} unit={u.l} tone="info" ariaLabel={`${MEASURES.find((m) => m.key === measure)?.label} over time`} />
                </Card>
                <Card title="Body fat %" icon="zap">
                  <LineChart data={ms.filter((m) => m.body_fat_pct != null && m.date >= from).map((m) => ({ label: fmtDate(m.date), value: m.body_fat_pct }))} unit="%" tone="warning" ariaLabel="Body fat percentage over time" />
                </Card>
              </div>

              <Card title="History" icon="list" padded={false}>
                <div className="list">
                  {[...ms].reverse().map((m) => (
                    <div key={m.id} className="list-item" style={{ cursor: 'default' }}>
                      <button className="grow" style={{ border: 0, background: 'none', textAlign: 'left', padding: 0, cursor: 'pointer', minWidth: 0 }} onClick={() => setEditing(m)}>
                        <span className="list-title" style={{ display: 'block' }}>
                          {fmtDate(m.date, { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}
                        </span>
                        <span className="list-sub" style={{ display: 'block', whiteSpace: 'normal' }}>
                          {[m.weight_kg != null && u.fmtWeight(m.weight_kg), m.body_fat_pct != null && `${m.body_fat_pct}% fat`, ...MEASURES.filter((x) => m[x.key] != null).map((x) => `${x.label} ${u.fmtLen(m[x.key] as number)}`)].filter(Boolean).join(' · ') || m.notes || '—'}
                        </span>
                      </button>
                      <IconButton icon="trash" size="sm" label="Delete entry" onClick={() => remove(m)} />
                    </div>
                  ))}
                </div>
              </Card>
            </>
          )}
        </>
      )}

      {tab === 'training' && (
        <>
          <div className="grid g3">
            <div className="card stat-card">
              <Stat label="Current streak" icon="flame" value={currentStreak(days, today)} unit="days" />
            </div>
            <div className="card stat-card">
              <Stat label="Longest streak" icon="trophy" tone="warning" value={longestStreak(days)} unit="days" />
            </div>
            <div className="card stat-card">
              <Stat label="Active days (12 wk)" icon="calendar" tone="success" value={[...days].filter((d) => d >= addDays(today, -83)).length} />
            </div>
          </div>
          <Card title="Activity heatmap" icon="calendar">
            <Heatmap values={heat} weeks={17} ariaLabel="Workout and run activity over the last 17 weeks" describe={(d, v) => `${fmtDate(d)}: ${v} activit${v === 1 ? 'y' : 'ies'}`} />
          </Card>
          <div className="grid g2">
            <Card title="Workouts per week" icon="dumbbell">
              <BarChart data={freq} target={profile.weekly_workout_target} ariaLabel="Completed workouts per week" tone="success" />
            </Card>
            <Card title="Weekly exercise time (min)" icon="clock">
              <BarChart data={minutes} unit="min" ariaLabel="Minutes exercised per week" tone="info" />
            </Card>
            <Card title={`Running distance (${u.d}/week)`} icon="run">
              <BarChart data={runDist} digits={1} unit={u.d} target={u.dist(profile.weekly_run_km_target)} ariaLabel="Running distance per week" tone="accent" />
            </Card>
          </div>
        </>
      )}

      {tab === 'photos' && <Photos />}

      <MeasurementForm entry={editing} onClose={() => setEditing(null)} />
    </div>
  );
}

function blank(date: string): BodyMeasurement {
  return { id: '', date, weight_kg: null, body_fat_pct: null, waist_cm: null, chest_cm: null, arms_cm: null, thighs_cm: null, hips_cm: null, neck_cm: null, notes: null };
}

function MeasurementForm({ entry, onClose }: { entry: BodyMeasurement | null; onClose: () => void }) {
  const data = useData();
  const profile = useProfile();
  const u = useUnits();
  const [f, setF] = useState<Record<string, string>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [last, setLast] = useState<BodyMeasurement | null>(null);
  if (entry !== last) {
    setLast(entry);
    setErrors({});
    if (entry)
      setF({
        date: entry.date,
        weight: entry.weight_kg == null ? '' : String(u.weight(entry.weight_kg)),
        goal: profile.goal_weight_kg == null ? '' : String(u.weight(profile.goal_weight_kg)),
        body_fat_pct: entry.body_fat_pct == null ? '' : String(entry.body_fat_pct),
        notes: entry.notes ?? '',
        ...Object.fromEntries(MEASURES.map((m) => [m.key, entry[m.key] == null ? '' : String(u.len(entry[m.key] as number))])),
      });
  }
  if (!entry) return null;
  const set = (k: string, v: string) => setF((p) => ({ ...p, [k]: v }));

  async function save() {
    if (!entry || saving) return;
    const v = new Validator();
    v.date('date', f.date);
    const weight = v.number('weight', f.weight, { min: 0.1, max: u.w === 'kg' ? 499 : 1100, label: 'Weight' });
    const goal = v.number('goal', f.goal, { min: 0.1, max: u.w === 'kg' ? 499 : 1100, label: 'Goal weight' });
    const bf = v.number('body_fat_pct', f.body_fat_pct, { min: 0, max: 100, label: 'Body fat' });
    const lens = Object.fromEntries(MEASURES.map((m) => [m.key, v.number(m.key, f[m.key], { min: 0.1, max: 400, label: m.label })]));
    const anyValue = weight != null || bf != null || Object.values(lens).some((x) => x != null) || f.notes.trim();
    v.check('weight', !!anyValue, 'Enter at least one measurement.');
    setErrors(v.errors);
    if (!v.ok) return;
    setSaving(true);
    const row: BodyMeasurement = {
      ...entry,
      id: entry.id || uuid(),
      date: f.date,
      weight_kg: u.fromWeight(weight),
      body_fat_pct: bf,
      notes: f.notes.trim() || null,
      ...(Object.fromEntries(Object.entries(lens).map(([k, val]) => [k, u.fromLen(val)])) as Partial<BodyMeasurement>),
    };
    const r = await data.save('body_measurements', row, { toast: entry.id ? 'Entry updated' : 'Weigh-in saved' });
    if (r.ok) {
      const goalKg = u.fromWeight(goal);
      const patch: Record<string, unknown> = {};
      if (goalKg !== profile.goal_weight_kg) patch.goal_weight_kg = goalKg;
      const isLatest = !data.tables.body_measurements.some((m) => m.id !== row.id && m.weight_kg != null && m.date > row.date);
      if (row.weight_kg != null && isLatest) patch.weight_kg = row.weight_kg;
      if (Object.keys(patch).length) await data.saveProfile(patch);
    }
    setSaving(false);
    if (r.ok) onClose();
  }

  return (
    <Modal
      open
      title={entry.id ? 'Edit measurements' : 'Log weigh-in & measurements'}
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" loading={saving} onClick={save}>
            Save
          </Button>
        </>
      }
    >
      <div className="form-grid">
        <Input label="Date" type="date" value={f.date} onChange={(e) => set('date', e.target.value)} error={errors.date} />
        <NumberInput label="Weight" suffix={u.w} value={f.weight} onChange={(e) => set('weight', e.target.value)} error={errors.weight} />
        <NumberInput label="Goal weight" suffix={u.w} value={f.goal} onChange={(e) => set('goal', e.target.value)} error={errors.goal} />
        <NumberInput label="Body fat (if known)" suffix="%" value={f.body_fat_pct} onChange={(e) => set('body_fat_pct', e.target.value)} error={errors.body_fat_pct} />
        {MEASURES.map((m) => (
          <NumberInput key={m.key} label={m.label} suffix={u.l} value={f[m.key]} onChange={(e) => set(m.key, e.target.value)} error={errors[m.key]} />
        ))}
      </div>
      <Textarea label="Notes" value={f.notes} onChange={(e) => set('notes', e.target.value)} />
      <p className="xs faint">Leave any field blank if you didn't measure it.</p>
    </Modal>
  );
}

function PhotoThumb({ p, onOpen }: { p: ProgressPhoto; onOpen: (url: string) => void }) {
  const [url, setUrl] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    let alive = true;
    photoUrl(p.storage_path).then((u) => {
      if (!alive) return;
      if (u) setUrl(u);
      else setFailed(true);
    });
    return () => {
      alive = false;
    };
  }, [p.storage_path]);
  return (
    <button className="photo" onClick={() => url && onOpen(url)} aria-label={`Progress photo from ${fmtDate(p.date)}${p.caption ? `: ${p.caption}` : ''}`}>
      {url ? <img src={url} alt="" loading="lazy" /> : <span className="center-spinner" style={{ padding: 0, height: '100%' }}>{failed ? <span className="xs muted">Unavailable offline</span> : <span className="spinner" />}</span>}
      <span className="photo-date">{fmtDate(p.date)}</span>
    </button>
  );
}

function Photos() {
  const data = useData();
  const { user } = useAuth();
  const online = useOnline();
  const toast = useToast();
  const confirm = useConfirm();
  const [date, setDate] = useState(todayISO());
  const [caption, setCaption] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [viewer, setViewer] = useState<{ p: ProgressPhoto; url: string } | null>(null);
  const photos = [...data.tables.progress_photos].sort((a, b) => b.date.localeCompare(a.date));

  async function upload() {
    if (!file || !user || busy) return;
    if (!online) return toast.error('Photos need an internet connection to upload.');
    setBusy(true);
    try {
      const path = await uploadProgressPhoto(user.id, file);
      const r = await data.save('progress_photos', { id: uuid(), date, storage_path: path, caption: caption.trim() || null }, { toast: 'Photo saved' });
      if (!r.ok) await deleteProgressPhoto(path).catch(() => undefined);
      else {
        setFile(null);
        setCaption('');
      }
    } catch (e) {
      toast.error(`Upload failed: ${toApiError(e).message}`);
    } finally {
      setBusy(false);
    }
  }

  async function remove(p: ProgressPhoto) {
    if (!(await confirm({ title: 'Delete photo?', message: 'The photo will be permanently deleted from your account.', confirmLabel: 'Delete', danger: true }))) return;
    try {
      await deleteProgressPhoto(p.storage_path);
    } catch (e) {
      const err = toApiError(e);
      if (err.network) return toast.error('Deleting photos needs an internet connection.');
    }
    if ((await data.remove('progress_photos', p, { toast: 'Photo deleted' })).ok) setViewer(null);
  }

  return (
    <div className="stack">
      <Card title="Add a progress photo" icon="camera">
        <div className="stack-sm">
          <p className="small muted">Photos are stored privately in your account — only you can see them. Uploading requires an internet connection.</p>
          <div className="form-grid">
            <Input label="Date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            <Input label="Caption (optional)" value={caption} onChange={(e) => setCaption(e.target.value)} placeholder="e.g. Front, relaxed" />
          </div>
          <div className="field">
            <label className="field-label" htmlFor="photo-file">
              Photo
            </label>
            <input id="photo-file" type="file" accept="image/*" className="input" style={{ paddingTop: 10 }} onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
          </div>
          <Button variant="primary" icon="camera" onClick={upload} loading={busy} disabled={!file || !online || !isValidISO(date)}>
            Upload photo
          </Button>
        </div>
      </Card>
      {photos.length === 0 ? (
        <EmptyState icon="image" title="No photos yet" message="Progress photos taken in the same spot and lighting make changes easier to see." />
      ) : (
        <div className="photo-grid">
          {photos.map((p) => (
            <PhotoThumb key={p.id} p={p} onOpen={(url) => setViewer({ p, url })} />
          ))}
        </div>
      )}
      <Modal
        open={!!viewer}
        title={viewer ? fmtDate(viewer.p.date, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }) : ''}
        onClose={() => setViewer(null)}
        size="lg"
        footer={
          viewer && (
            <Button variant="ghost" icon="trash" onClick={() => remove(viewer.p)}>
              Delete photo
            </Button>
          )
        }
      >
        {viewer && (
          <>
            <img src={viewer.url} alt={viewer.p.caption ?? 'Progress photo'} style={{ borderRadius: 12, maxHeight: '65vh', margin: '0 auto', objectFit: 'contain' }} />
            {viewer.p.caption && <p className="center muted">{viewer.p.caption}</p>}
          </>
        )}
      </Modal>
    </div>
  );
}
