import { useMemo, useState } from 'react';
import { useData, useProfile } from '../hooks/useData';
import { useUnits } from '../hooks/useUnits';
import { useRouter, Link } from '../router';
import { Card, StatusBadge, Stat, ProgressBar, EmptyState, Badge } from '../components/ui/Misc';
import { Button } from '../components/ui/Button';
import { Icon, type IconName } from '../components/Icon';
import { Ring, LineChart } from '../components/charts/Charts';
import { addDays, endOfMonth, endOfWeek, fmtDate, fmtLongDate, greeting, relativeDay, startOfMonth, startOfWeek, todayISO } from '../utils/date';
import { fmtMinutes, fmtNum } from '../utils/format';
import { activeDays, currentStreak, firstWeight, latestWeight, nutritionTotals, periodStats } from '../utils/stats';
import { uuid } from '../utils/id';
import { parseOptionalNumber } from '../utils/validate';
import type { DailyMetric } from '../types';

function QuickAction({ icon, label, onClick, tone }: { icon: IconName; label: string; onClick: () => void; tone: string }) {
  return (
    <button className="quick-action" onClick={onClick}>
      <span className={`list-icon tone-${tone}`}>
        <Icon name={icon} size={19} />
      </span>
      {label}
    </button>
  );
}

export default function Dashboard() {
  const data = useData();
  const { workouts, tables } = data;
  const profile = useProfile();
  const u = useUnits();
  const { navigate } = useRouter();
  const today = todayISO();
  const [stepsInput, setStepsInput] = useState('');
  const [savingSteps, setSavingSteps] = useState(false);
  const [waterBusy, setWaterBusy] = useState(false);

  const week = useMemo(() => periodStats(workouts, tables.running_sessions, startOfWeek(today), endOfWeek(today)), [workouts, tables.running_sessions, today]);
  const month = useMemo(() => periodStats(workouts, tables.running_sessions, startOfMonth(today), endOfMonth(today)), [workouts, tables.running_sessions, today]);
  const streak = useMemo(() => currentStreak(activeDays(workouts, tables.running_sessions), today), [workouts, tables.running_sessions, today]);

  const todays = workouts.filter((w) => w.date === today).sort((a, b) => (a.start_time ?? '').localeCompare(b.start_time ?? ''));
  const restToday = tables.calendar_events.find((e) => e.date === today && e.event_type === 'rest');
  const upcoming = workouts
    .filter((w) => w.date > today && w.status === 'planned')
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(0, 4);

  const recent = useMemo(
    () =>
      [
        ...workouts.filter((w) => w.status === 'completed').map((w) => ({ id: w.id, date: w.date, title: w.name, sub: w.duration_min ? fmtMinutes(w.duration_min) : w.workout_type, icon: 'dumbbell' as IconName, to: `/workouts/${w.id}`, tone: 'success' })),
        ...tables.running_sessions
          .filter((r) => r.status === 'completed')
          .map((r) => ({ id: r.id, date: r.date, title: r.route_name || `${r.activity_type[0].toUpperCase()}${r.activity_type.slice(1)}`, sub: `${u.fmtDist(r.distance_km)}${r.duration_sec ? ` · ${fmtMinutes(r.duration_sec / 60)}` : ''}`, icon: 'run' as IconName, to: `/run?id=${r.id}`, tone: 'accent' })),
      ]
        .sort((a, b) => b.date.localeCompare(a.date))
        .slice(0, 5),
    [workouts, tables.running_sessions, u],
  );

  const food = tables.nutrition_entries.filter((n) => n.date === today);
  const nt = nutritionTotals(food);
  const water = tables.water_entries.filter((w) => w.date === today).reduce((a, w) => a + w.amount_ml, 0);
  const metric = tables.daily_metrics.find((m) => m.date === today);
  const current = latestWeight(tables.body_measurements);
  const start = profile.start_weight_kg != null ? { value: profile.start_weight_kg } : firstWeight(tables.body_measurements);
  const currentKg = current?.value ?? profile.weight_kg;
  const weightSeries = [...tables.body_measurements]
    .filter((m) => m.weight_kg != null && m.date >= addDays(today, -90))
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((m) => ({ label: fmtDate(m.date), value: u.weight(m.weight_kg) }));

  const mealsByType = food.reduce<Record<string, number>>((a, f) => ((a[f.meal_type] = (a[f.meal_type] ?? 0) + (f.calories ?? 0)), a), {});

  async function addWater(ml: number) {
    if (waterBusy) return;
    setWaterBusy(true);
    await data.save('water_entries', { id: uuid(), date: today, amount_ml: ml }, { toast: `+${ml} ml water` });
    setWaterBusy(false);
  }

  async function saveSteps() {
    const n = parseOptionalNumber(stepsInput);
    if (n == null || n < 0 || n > 200000 || !Number.isInteger(n)) return;
    setSavingSteps(true);
    const row: DailyMetric = { id: metric?.id ?? uuid(), date: today, steps: n, sleep_hours: metric?.sleep_hours ?? null, notes: metric?.notes ?? null };
    const r = await data.save('daily_metrics', row, { toast: 'Steps saved' });
    setSavingSteps(false);
    if (r.ok) setStepsInput('');
  }

  const name = profile.name?.split(' ')[0];

  return (
    <div className="stack">
      <header className="page-head" style={{ marginBottom: 4 }}>
        <div>
          <p className="hero-greet">
            {greeting()}
            {name ? `, ${name}` : ''} 👋
          </p>
          <h1>{fmtLongDate(today)}</h1>
        </div>
      </header>

      <div className="quick-actions">
        <QuickAction icon="play" label="Workout" tone="accent" onClick={() => navigate(todays.find((w) => w.status !== 'completed' && w.status !== 'skipped') ? `/live/${todays.find((w) => w.status !== 'completed' && w.status !== 'skipped')!.id}` : '/workouts')} />
        <QuickAction icon="run" label="Run" tone="warning" onClick={() => navigate('/run')} />
        <QuickAction icon="utensils" label="Meal" tone="success" onClick={() => navigate('/nutrition?add=1')} />
        <QuickAction icon="scale" label="Weight" tone="info" onClick={() => navigate('/progress?add=1')} />
      </div>

      <div className="dash-grid">
        <Card title="Today's workout" icon="dumbbell" action={<Link to="/calendar" className="card-link">Calendar <Icon name="right" size={14} /></Link>}>
          {todays.length === 0 ? (
            restToday ? (
              <div className="row">
                <span className="list-icon tone-violet">
                  <Icon name="bed" />
                </span>
                <div className="grow">
                  <div className="strong">Rest day</div>
                  <div className="small muted">{restToday.title}</div>
                </div>
              </div>
            ) : (
              <div className="stack-sm">
                <p className="muted">Nothing scheduled for today.</p>
                <div className="row-wrap">
                  <Button variant="primary" icon="plus" size="sm" onClick={() => navigate(`/workouts/new?date=${today}`)}>
                    Plan / log a workout
                  </Button>
                  <Button size="sm" icon="layers" onClick={() => navigate('/programs')}>
                    Pick a program
                  </Button>
                </div>
              </div>
            )
          ) : (
            <div className="stack-sm">
              {todays.map((w) => (
                <div key={w.id} className="row" style={{ alignItems: 'center' }}>
                  <div className="grow">
                    <Link to={`/workouts/${w.id}`} className="strong" style={{ display: 'block' }}>
                      {w.name}
                    </Link>
                    <div className="row-wrap small muted" style={{ marginTop: 2 }}>
                      <StatusBadge status={w.status} />
                      {w.exercises.length > 0 && <span>{w.exercises.length} exercises</span>}
                    </div>
                  </div>
                  {w.status === 'planned' || w.status === 'in_progress' ? (
                    <Button variant="primary" icon="play" size="sm" onClick={() => navigate(`/live/${w.id}`)}>
                      {w.status === 'in_progress' ? 'Resume' : 'Start'}
                    </Button>
                  ) : (
                    <Button size="sm" onClick={() => navigate(`/workouts/${w.id}`)}>
                      View
                    </Button>
                  )}
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card title="This week" icon="target" action={<Link to="/stats" className="card-link">Stats <Icon name="right" size={14} /></Link>}>
          <div className="rings-row">
            <div>
              <Ring value={week.completed} max={profile.weekly_workout_target} size={96} stroke={9} label="Weekly workouts">
                <span className="ring-big">{week.completed}</span>
                <span className="ring-small">of {profile.weekly_workout_target}</span>
              </Ring>
              <div className="ring-label">Workouts</div>
            </div>
            <div>
              <Ring value={week.runKm} max={profile.weekly_run_km_target} size={96} stroke={9} tone="warning" label="Weekly distance">
                <span className="ring-big">{fmtNum(u.dist(week.runKm), 1)}</span>
                <span className="ring-small">of {fmtNum(u.dist(profile.weekly_run_km_target), 0)} {u.d}</span>
              </Ring>
              <div className="ring-label">Distance</div>
            </div>
            <div>
              <Ring value={water} max={profile.water_target_ml} size={96} stroke={9} tone="water" label="Water today">
                <span className="ring-big">{fmtNum(water / 1000, 1)}</span>
                <span className="ring-small">of {fmtNum(profile.water_target_ml / 1000, 1)} L</span>
              </Ring>
              <div className="ring-label">Water today</div>
            </div>
          </div>
        </Card>

        <div className="grid g4 dash-span">
          <div className="card stat-card">
            <Stat label="Streak" icon="flame" tone="accent" value={streak} unit={streak === 1 ? 'day' : 'days'} sub="active days in a row" />
          </div>
          <div className="card stat-card">
            <Stat label="This week" icon="dumbbell" tone="success" value={week.completed} unit="workouts" sub={`${fmtMinutes(week.minutes)} exercised`} />
          </div>
          <div className="card stat-card">
            <Stat label="This month" icon="calendar" tone="info" value={month.completed} unit="workouts" sub={`${fmtMinutes(month.minutes)} total`} />
          </div>
          <div className="card stat-card">
            <Stat label="Burned this week" icon="zap" tone="warning" value={week.calories ? fmtNum(week.calories) : '–'} unit={week.calories ? 'kcal' : undefined} sub={week.calories ? 'from logged sessions' : 'log calories to see this'} />
          </div>
        </div>

        <Card title="Nutrition today" icon="utensils" action={<Link to="/nutrition" className="card-link">Log food <Icon name="right" size={14} /></Link>}>
          <div className="row" style={{ gap: 18, alignItems: 'center' }}>
            <Ring value={nt.calories} max={profile.calorie_target} size={110} stroke={10} tone={nt.calories > profile.calorie_target ? 'warning' : 'success'} label="Calories consumed">
              <span className="ring-big">{fmtNum(nt.calories)}</span>
              <span className="ring-small">/ {fmtNum(profile.calorie_target)} kcal</span>
            </Ring>
            <div className="grow stack-sm">
              {[
                ['Protein', nt.protein, profile.protein_target, 'accent'],
                ['Carbs', nt.carbs, profile.carbs_target, 'info'],
                ['Fat', nt.fat, profile.fat_target, 'violet'],
              ].map(([l, v, t, tone]) => (
                <div key={l as string} className="macro">
                  <div className="macro-head">
                    <span className="strong">{l}</span>
                    <span className="muted">
                      {fmtNum(v as number)} / {t} g
                    </span>
                  </div>
                  <ProgressBar value={v as number} max={t as number} tone={tone as string} label={`${l} consumed`} />
                </div>
              ))}
            </div>
          </div>
          <div className="divider" style={{ margin: '14px 0 10px' }} />
          {food.length ? (
            <div className="row-wrap small">
              {Object.entries(mealsByType).map(([k, v]) => (
                <Badge key={k}>
                  {k.replace('_', ' ')} · {fmtNum(v)} kcal
                </Badge>
              ))}
            </div>
          ) : (
            <p className="small muted">No meals logged today.</p>
          )}
        </Card>

        <Card title="Body" icon="scale" action={<Link to="/progress" className="card-link">Progress <Icon name="right" size={14} /></Link>}>
          {currentKg == null ? (
            <EmptyState icon="scale" title="No weight logged yet" message="Add a weigh-in to track your progress." action={<Button size="sm" variant="primary" onClick={() => navigate('/progress?add=1')}>Log weight</Button>} />
          ) : (
            <div className="stack-sm">
              <div className="grid g3">
                <Stat label="Current" value={fmtNum(u.weight(currentKg), 1)} unit={u.w} />
                <Stat label="Goal" value={profile.goal_weight_kg ? fmtNum(u.weight(profile.goal_weight_kg), 1) : '–'} unit={profile.goal_weight_kg ? u.w : undefined} />
                <Stat
                  label="Change"
                  value={start && current ? `${current.value - start.value > 0 ? '+' : ''}${fmtNum(u.weight(current.value - start.value), 1)}` : '–'}
                  unit={start && current ? u.w : undefined}
                />
              </div>
              {weightSeries.length > 1 && <LineChart data={weightSeries} height={120} unit={u.w} goal={profile.goal_weight_kg ? u.weight(profile.goal_weight_kg) : null} ariaLabel="Weight over the last 90 days" />}
            </div>
          )}
        </Card>

        <Card title="Water & steps" icon="droplet" action={<Link to="/water" className="card-link">Water <Icon name="right" size={14} /></Link>}>
          <div className="stack-sm">
            <div className="macro">
              <div className="macro-head">
                <span className="strong">Water</span>
                <span className="muted">
                  {fmtNum(water)} / {fmtNum(profile.water_target_ml)} ml
                </span>
              </div>
              <ProgressBar value={water} max={profile.water_target_ml} tone="water" label="Water today" />
            </div>
            <div className="row-wrap">
              {[250, 500, 750].map((ml) => (
                <Button key={ml} size="sm" icon="droplet" disabled={waterBusy} onClick={() => addWater(ml)}>
                  +{ml} ml
                </Button>
              ))}
            </div>
            <div className="divider" style={{ margin: '8px 0' }} />
            <div className="macro">
              <div className="macro-head">
                <span className="strong">Steps</span>
                <span className="muted">{metric?.steps != null ? `${fmtNum(metric.steps)} / ${fmtNum(profile.step_target)}` : 'not entered'}</span>
              </div>
              {metric?.steps != null && <ProgressBar value={metric.steps} max={profile.step_target} tone="success" label="Steps today" />}
            </div>
            <form
              className="row"
              onSubmit={(e) => {
                e.preventDefault();
                void saveSteps();
              }}
            >
              <input className="input grow" style={{ height: 40 }} inputMode="numeric" placeholder={metric?.steps != null ? 'Update steps' : 'Enter today’s steps'} aria-label="Steps today" value={stepsInput} onChange={(e) => setStepsInput(e.target.value.replace(/[^\d]/g, ''))} />
              <Button size="sm" type="submit" loading={savingSteps} disabled={!stepsInput}>
                Save
              </Button>
            </form>
          </div>
        </Card>

        <Card title="Running" icon="run" action={<Link to="/run" className="card-link">Runs <Icon name="right" size={14} /></Link>}>
          {week.runs === 0 && tables.running_sessions.length === 0 ? (
            <div className="stack-sm">
              <p className="muted">No runs logged yet.</p>
              <Button size="sm" variant="primary" icon="play" onClick={() => navigate('/run')}>
                Start a run
              </Button>
            </div>
          ) : (
            <div className="grid g3">
              <Stat label="This week" value={fmtNum(u.dist(week.runKm), 1)} unit={u.d} sub={`${week.runs} run${week.runs === 1 ? '' : 's'}`} />
              <Stat label="This month" value={fmtNum(u.dist(month.runKm), 1)} unit={u.d} />
              <Stat label="Run time (wk)" value={fmtMinutes(week.runMin)} />
            </div>
          )}
        </Card>

        <Card title="Upcoming" icon="calendar" padded={false}>
          {upcoming.length === 0 ? (
            <p className="muted small" style={{ padding: '0 16px 16px' }}>
              No upcoming workouts scheduled.
            </p>
          ) : (
            <div className="list">
              {upcoming.map((w) => (
                <Link key={w.id} to={`/workouts/${w.id}`} className="list-item">
                  <span className="list-icon tone-info">
                    <Icon name="clock" size={18} />
                  </span>
                  <span className="grow">
                    <span className="list-title" style={{ display: 'block' }}>
                      {w.name}
                    </span>
                    <span className="list-sub" style={{ display: 'block' }}>
                      {relativeDay(w.date)}
                    </span>
                  </span>
                  <Icon name="right" size={18} className="faint" />
                </Link>
              ))}
            </div>
          )}
        </Card>

        <Card title="Recent activity" icon="zap" padded={false}>
          {recent.length === 0 ? (
            <p className="muted small" style={{ padding: '0 16px 16px' }}>
              Completed workouts and runs will appear here.
            </p>
          ) : (
            <div className="list">
              {recent.map((r) => (
                <Link key={r.id} to={r.to} className="list-item">
                  <span className={`list-icon tone-${r.tone}`}>
                    <Icon name={r.icon} size={18} />
                  </span>
                  <span className="grow">
                    <span className="list-title" style={{ display: 'block' }}>
                      {r.title}
                    </span>
                    <span className="list-sub" style={{ display: 'block' }}>
                      {relativeDay(r.date)} · {r.sub}
                    </span>
                  </span>
                </Link>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
