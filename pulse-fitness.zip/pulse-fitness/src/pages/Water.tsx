import { useState } from 'react';
import { useData, useProfile } from '../hooks/useData';
import { useConfirm } from '../components/ui/Confirm';
import { PageHeader, Card, Stat } from '../components/ui/Misc';
import { Button, IconButton } from '../components/ui/Button';
import { NumberInput } from '../components/ui/Field';
import { BarChart } from '../components/charts/Charts';
import { addDays, fmtDate, fmtLongDate, relativeDay, todayISO } from '../utils/date';
import { fmtNum } from '../utils/format';
import { waterByDay } from '../utils/stats';
import { uuid } from '../utils/id';
import { parseOptionalNumber } from '../utils/validate';

export default function WaterPage() {
  const data = useData();
  const profile = useProfile();
  const confirm = useConfirm();
  const [date, setDate] = useState(todayISO());
  const [custom, setCustom] = useState('');
  const [customErr, setCustomErr] = useState<string | undefined>();
  const [target, setTarget] = useState(String(profile.water_target_ml));
  const [targetErr, setTargetErr] = useState<string | undefined>();
  const [busy, setBusy] = useState(false);

  const entries = data.tables.water_entries.filter((e) => e.date === date).sort((a, b) => (b.created_at ?? '').localeCompare(a.created_at ?? ''));
  const total = entries.reduce((a, e) => a + e.amount_ml, 0);
  const pct = Math.min(100, (total / Math.max(1, profile.water_target_ml)) * 100);
  const byDay = waterByDay(data.tables.water_entries);
  const series = Array.from({ length: 14 }, (_, i) => addDays(todayISO(), i - 13)).map((d) => ({ label: fmtDate(d, { day: 'numeric' }), value: byDay[d] ?? 0 }));
  const last7 = Array.from({ length: 7 }, (_, i) => addDays(todayISO(), -i));
  const hit7 = last7.filter((d) => (byDay[d] ?? 0) >= profile.water_target_ml).length;

  async function add(ml: number) {
    if (busy) return;
    setBusy(true);
    await data.save('water_entries', { id: uuid(), date, amount_ml: ml }, { toast: `+${ml} ml` });
    setBusy(false);
  }

  return (
    <div className="stack">
      <PageHeader title="Water" subtitle="Stay hydrated" />
      <div className="row">
        <IconButton icon="left" label="Previous day" variant="secondary" onClick={() => setDate(addDays(date, -1))} />
        <div className="grow center">
          <div className="strong">{relativeDay(date)}</div>
          <div className="xs muted">{fmtLongDate(date)}</div>
        </div>
        <IconButton icon="right" label="Next day" variant="secondary" disabled={date >= todayISO()} onClick={() => setDate(addDays(date, 1))} />
      </div>

      <div className="grid g2">
        <Card>
          <div className="stack" style={{ alignItems: 'center' }}>
            <div className="water-glass" role="progressbar" aria-label="Water intake" aria-valuenow={total} aria-valuemin={0} aria-valuemax={profile.water_target_ml}>
              <div className="water-fill" style={{ height: `${pct}%` }} />
              <div className="water-text">
                <span className="ring-big" style={{ fontSize: 30 }}>
                  {fmtNum(total)}
                </span>
                <span className="small strong">of {fmtNum(profile.water_target_ml)} ml</span>
                <span className="xs">{Math.round(pct)}%</span>
              </div>
            </div>
            {total >= profile.water_target_ml && <div className="alert alert-success">🎉 Daily water goal reached!</div>}
            <div className="row-wrap" style={{ justifyContent: 'center' }}>
              {[250, 500, 750].map((ml) => (
                <Button key={ml} icon="droplet" size="lg" disabled={busy} onClick={() => add(ml)}>
                  +{ml} ml
                </Button>
              ))}
            </div>
            <form
              className="row"
              style={{ width: '100%', maxWidth: 360, alignItems: 'flex-start' }}
              onSubmit={(e) => {
                e.preventDefault();
                const n = parseOptionalNumber(custom);
                if (n == null || n <= 0 || n > 5000 || !Number.isInteger(n)) return setCustomErr('Enter a whole number between 1 and 5000 ml.');
                setCustomErr(undefined);
                setCustom('');
                void add(n);
              }}
            >
              <NumberInput label="Custom amount" hideLabel className="grow" suffix="ml" decimal={false} placeholder="Custom amount" value={custom} onChange={(e) => setCustom(e.target.value)} error={customErr} />
              <Button type="submit" variant="primary" disabled={busy}>
                Add
              </Button>
            </form>
          </div>
        </Card>

        <Card title={`Entries (${entries.length})`} icon="list">
          {entries.length === 0 ? (
            <p className="muted">No water logged for this day.</p>
          ) : (
            <div className="list">
              {entries.map((e) => (
                <div key={e.id} className="list-item" style={{ cursor: 'default', minHeight: 48 }}>
                  <span className="list-icon tone-water" style={{ width: 34, height: 34 }}>💧</span>
                  <span className="grow strong">{e.amount_ml} ml</span>
                  <span className="xs muted">{e.created_at ? new Date(e.created_at).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : ''}</span>
                  <IconButton
                    icon="trash"
                    size="sm"
                    label={`Remove ${e.amount_ml} ml entry`}
                    onClick={async () => {
                      if (await confirm({ title: 'Remove water entry?', message: `${e.amount_ml} ml`, confirmLabel: 'Remove', danger: true })) await data.remove('water_entries', e, { toast: 'Removed' });
                    }}
                  />
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>

      <div className="grid g2">
        <Card title="Last 14 days" icon="chart">
          <BarChart data={series} target={profile.water_target_ml} unit="ml" ariaLabel="Daily water intake, last 14 days" tone="water" />
          <p className="small muted" style={{ marginTop: 8 }}>
            Goal reached on {hit7} of the last 7 days.
          </p>
        </Card>
        <Card title="Daily target" icon="target">
          <form
            className="stack-sm"
            onSubmit={async (e) => {
              e.preventDefault();
              const n = parseOptionalNumber(target);
              if (n == null || n < 250 || n > 20000 || !Number.isInteger(n)) return setTargetErr('Choose between 250 and 20000 ml.');
              setTargetErr(undefined);
              await data.saveProfile({ water_target_ml: n }, { toast: 'Water target updated' });
            }}
          >
            <NumberInput label="Target per day" suffix="ml" decimal={false} value={target} onChange={(e) => setTarget(e.target.value)} error={targetErr} />
            <Button type="submit">Save target</Button>
          </form>
          <div className="divider" style={{ margin: '14px 0' }} />
          <Stat label="7-day average" value={fmtNum(last7.reduce((a, d) => a + (byDay[d] ?? 0), 0) / 7)} unit="ml" />
        </Card>
      </div>
    </div>
  );
}
