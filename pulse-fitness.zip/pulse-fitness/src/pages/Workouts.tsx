import { useMemo, useState } from 'react';
import { useData } from '../hooks/useData';
import { useRouter, Link } from '../router';
import { PageHeader, EmptyState, SearchBox, StatusBadge, Card, Badge } from '../components/ui/Misc';
import { Button } from '../components/ui/Button';
import { Select } from '../components/ui/Field';
import { Icon } from '../components/Icon';
import { MUSCLE_GROUPS } from '../data/exercises';
import { WORKOUT_TYPES } from '../data/goals';
import { endOfMonth, endOfWeek, fmtDate, fmtMonth, relativeDay, startOfMonth, startOfWeek, todayISO } from '../utils/date';
import { fmtMinutes, label } from '../utils/format';
import { workoutMinutes, workoutTotals } from '../utils/calc';
import { blankWorkout } from '../utils/workout';
import { useUnits } from '../hooks/useUnits';
import type { Workout } from '../types';

type Period = 'all' | 'week' | 'month' | 'year' | 'date';

export function WorkoutRow({ w }: { w: Workout }) {
  const u = useUnits();
  const t = workoutTotals(w);
  const mins = workoutMinutes(w);
  const tone = w.status === 'completed' ? 'tone-success' : w.status === 'skipped' ? '' : w.status === 'in_progress' ? 'tone-accent' : 'tone-info';
  return (
    <Link to={`/workouts/${w.id}`} className="list-item">
      <span className={`list-icon ${tone}`} style={w.status === 'skipped' ? { background: 'var(--surface-2)', color: 'var(--faint)' } : undefined}>
        <Icon name={w.workout_type === 'cardio' ? 'run' : w.workout_type === 'mobility' || w.workout_type === 'stretching' ? 'heart' : 'dumbbell'} size={20} />
      </span>
      <span className="grow">
        <span className="list-title" style={{ display: 'block' }}>
          {w.name}
        </span>
        <span className="list-sub" style={{ display: 'block' }}>
          {relativeDay(w.date)} · {label(w.workout_type)}
          {w.exercises.length ? ` · ${w.exercises.length} exercises` : ''}
          {mins ? ` · ${fmtMinutes(mins)}` : ''}
          {t.volumeKg ? ` · ${u.fmtWeight(t.volumeKg, 0)}` : ''}
        </span>
      </span>
      <span className="list-meta">
        <StatusBadge status={w.status} />
      </span>
    </Link>
  );
}

export default function WorkoutsPage() {
  const { workouts, saveWorkout } = useData();
  const { navigate } = useRouter();
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('all');
  const [type, setType] = useState('all');
  const [muscle, setMuscle] = useState('all');
  const [exercise, setExercise] = useState('all');
  const [period, setPeriod] = useState<Period>('all');
  const [date, setDate] = useState(todayISO());
  const [showFilters, setShowFilters] = useState(false);
  const [starting, setStarting] = useState(false);

  const exerciseNames = useMemo(() => [...new Set(workouts.flatMap((w) => w.exercises.map((e) => e.name)))].sort(), [workouts]);
  const today = todayISO();

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    let from = '0000', to = '9999';
    if (period === 'week') [from, to] = [startOfWeek(date), endOfWeek(date)];
    if (period === 'month') [from, to] = [startOfMonth(date), endOfMonth(date)];
    if (period === 'year') [from, to] = [date.slice(0, 4) + '-01-01', date.slice(0, 4) + '-12-31'];
    if (period === 'date') [from, to] = [date, date];
    return workouts
      .filter((w) => w.date >= from && w.date <= to)
      .filter((w) => status === 'all' || w.status === status)
      .filter((w) => type === 'all' || w.workout_type === type)
      .filter((w) => muscle === 'all' || w.muscle_groups.includes(muscle) || w.exercises.some((e) => e.muscle_group === muscle))
      .filter((w) => exercise === 'all' || w.exercises.some((e) => e.name === exercise))
      .filter((w) => !term || [w.name, w.notes, w.workout_type, ...w.muscle_groups, ...w.exercises.map((e) => e.name)].some((s) => s?.toLowerCase().includes(term)))
      .sort((a, b) => b.date.localeCompare(a.date) || (b.start_time ?? '').localeCompare(a.start_time ?? ''));
  }, [workouts, q, status, type, muscle, exercise, period, date]);

  const activeFilters = [status, type, muscle, exercise].filter((x) => x !== 'all').length + (period !== 'all' ? 1 : 0);
  const upcoming = filtered.filter((w) => w.date >= today && (w.status === 'planned' || w.status === 'in_progress')).reverse();
  const history = filtered.filter((w) => !upcoming.includes(w));
  const byMonth = history.reduce<Record<string, Workout[]>>((acc, w) => {
    const k = w.date.slice(0, 7);
    (acc[k] ??= []).push(w);
    return acc;
  }, {});

  async function startEmpty() {
    if (starting) return;
    setStarting(true);
    const w = { ...blankWorkout(), name: 'Quick workout', status: 'in_progress' as const };
    const r = await saveWorkout(w);
    setStarting(false);
    if (r.ok) navigate(`/live/${w.id}`);
  }

  const clear = () => {
    setStatus('all');
    setType('all');
    setMuscle('all');
    setExercise('all');
    setPeriod('all');
  };

  return (
    <div className="stack">
      <PageHeader
        title="Workouts"
        subtitle={`${workouts.filter((w) => w.status === 'completed').length} completed · ${workouts.filter((w) => w.status === 'planned' && w.date >= today).length} planned`}
        actions={
          <>
            <Button icon="play" onClick={startEmpty} loading={starting}>
              Start now
            </Button>
            <Button icon="plus" variant="primary" onClick={() => navigate('/workouts/new')}>
              New workout
            </Button>
          </>
        }
      />

      {workouts.length === 0 ? (
        <Card>
          <EmptyState
            icon="dumbbell"
            title="No workouts recorded yet."
            message="Log a session you've done, plan one for later, or start a live workout and track sets as you go."
            action={
              <div className="row-wrap" style={{ justifyContent: 'center' }}>
                <Button variant="primary" icon="play" onClick={startEmpty} loading={starting}>
                  Start Your First Workout
                </Button>
                <Button icon="layers" onClick={() => navigate('/programs')}>
                  Browse programs
                </Button>
              </div>
            }
          />
        </Card>
      ) : (
        <>
          <div className="row">
            <div className="grow">
              <SearchBox value={q} onChange={setQ} placeholder="Search workouts or exercises" />
            </div>
            <Button icon="filter" onClick={() => setShowFilters((s) => !s)} aria-expanded={showFilters}>
              {activeFilters ? `Filters (${activeFilters})` : 'Filters'}
            </Button>
          </div>

          {showFilters && (
            <Card>
              <div className="form-grid cols-3">
                <Select label="Status" value={status} onChange={(e) => setStatus(e.target.value)}>
                  <option value="all">All statuses</option>
                  <option value="completed">Completed</option>
                  <option value="planned">Planned</option>
                  <option value="in_progress">In progress</option>
                  <option value="skipped">Skipped</option>
                </Select>
                <Select label="Workout type" value={type} onChange={(e) => setType(e.target.value)}>
                  <option value="all">All types</option>
                  {WORKOUT_TYPES.map((t) => (
                    <option key={t} value={t}>
                      {label(t)}
                    </option>
                  ))}
                </Select>
                <Select label="Muscle group" value={muscle} onChange={(e) => setMuscle(e.target.value)}>
                  <option value="all">All muscle groups</option>
                  {MUSCLE_GROUPS.map((m) => (
                    <option key={m}>{m}</option>
                  ))}
                </Select>
                <Select label="Exercise" value={exercise} onChange={(e) => setExercise(e.target.value)}>
                  <option value="all">Any exercise</option>
                  {exerciseNames.map((m) => (
                    <option key={m}>{m}</option>
                  ))}
                </Select>
                <Select label="Period" value={period} onChange={(e) => setPeriod(e.target.value as Period)}>
                  <option value="all">All time</option>
                  <option value="date">Specific date</option>
                  <option value="week">Week of…</option>
                  <option value="month">Month of…</option>
                  <option value="year">Year of…</option>
                </Select>
                {period !== 'all' && (
                  <div className="field">
                    <label className="field-label" htmlFor="wf-date">
                      {period === 'date' ? 'Date' : period === 'week' ? 'Any day in week' : period === 'month' ? 'Any day in month' : 'Any day in year'}
                    </label>
                    <input id="wf-date" className="input" type="date" value={date} onChange={(e) => e.target.value && setDate(e.target.value)} />
                  </div>
                )}
              </div>
              {activeFilters > 0 && (
                <div style={{ marginTop: 12 }}>
                  <Button size="sm" variant="ghost" icon="x" onClick={clear}>
                    Clear filters
                  </Button>
                </div>
              )}
            </Card>
          )}

          {filtered.length === 0 && <EmptyState icon="search" title="No matching workouts" message="Try a different search or clear the filters." action={<Button onClick={() => { clear(); setQ(''); }}>Clear all</Button>} />}

          {upcoming.length > 0 && (
            <Card title="Upcoming" icon="calendar" padded={false}>
              <div className="list">
                {upcoming.map((w) => (
                  <WorkoutRow key={w.id} w={w} />
                ))}
              </div>
            </Card>
          )}

          {Object.entries(byMonth).map(([month, list]) => (
            <Card
              key={month}
              padded={false}
              title={fmtMonth(month + '-01')}
              action={<Badge>{list.filter((w) => w.status === 'completed').length} done</Badge>}
            >
              <div className="list">
                {list.map((w) => (
                  <WorkoutRow key={w.id} w={w} />
                ))}
              </div>
            </Card>
          ))}
          {filtered.length > 0 && <p className="center faint xs">Showing {filtered.length} workouts{filtered.length && filtered[filtered.length - 1] ? ` since ${fmtDate(filtered[filtered.length - 1].date, { month: 'short', day: 'numeric', year: 'numeric' })}` : ''}</p>}
        </>
      )}
    </div>
  );
}
