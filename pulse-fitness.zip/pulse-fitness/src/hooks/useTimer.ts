import { useCallback, useEffect, useRef, useState } from 'react';

/**
 * Wall-clock based stopwatch. Survives tab throttling and can be persisted:
 * state = { startedAt (ms) | null, accumulated (ms) }.
 */
export interface StopwatchState {
  startedAt: number | null;
  accumulated: number;
}

export function elapsedOf(s: StopwatchState, now = Date.now()) {
  return s.accumulated + (s.startedAt ? now - s.startedAt : 0);
}

export function useTicker(active: boolean, intervalMs = 250) {
  const [, setTick] = useState(0);
  useEffect(() => {
    if (!active) return;
    const id = window.setInterval(() => setTick((t) => t + 1), intervalMs);
    return () => window.clearInterval(id);
  }, [active, intervalMs]);
}

export function useStopwatch(initial?: StopwatchState, intervalMs = 250) {
  const [state, setState] = useState<StopwatchState>(initial ?? { startedAt: null, accumulated: 0 });
  useTicker(state.startedAt !== null, intervalMs);
  const start = useCallback(() => setState((s) => (s.startedAt ? s : { ...s, startedAt: Date.now() })), []);
  const pause = useCallback(() => setState((s) => (s.startedAt ? { startedAt: null, accumulated: elapsedOf(s) } : s)), []);
  const reset = useCallback(() => setState({ startedAt: null, accumulated: 0 }), []);
  return { state, setState, elapsed: elapsedOf(state), running: state.startedAt !== null, start, pause, reset };
}

/** Countdown that fires onDone once when it reaches zero. */
export function useCountdown(onDone: () => void) {
  const [st, setSt] = useState<{ total: number; endsAt: number | null; paused: number | null; finished: boolean }>({
    total: 0,
    endsAt: null,
    paused: null,
    finished: false,
  });
  const doneRef = useRef(onDone);
  doneRef.current = onDone;
  useTicker(st.endsAt !== null, 200);

  const remaining = st.endsAt !== null ? Math.max(0, st.endsAt - Date.now()) : st.paused ?? 0;

  useEffect(() => {
    if (st.endsAt !== null && remaining <= 0) {
      setSt((s) => ({ ...s, endsAt: null, paused: 0, finished: true }));
      doneRef.current();
    }
  }, [st.endsAt, remaining]);

  const start = useCallback((ms: number) => setSt({ total: ms, endsAt: Date.now() + ms, paused: null, finished: false }), []);
  const pause = useCallback(
    () => setSt((s) => (s.endsAt === null ? s : { ...s, endsAt: null, paused: Math.max(0, s.endsAt - Date.now()) })),
    [],
  );
  const resume = useCallback(
    () => setSt((s) => (s.paused === null || s.paused <= 0 ? s : { ...s, endsAt: Date.now() + s.paused, paused: null })),
    [],
  );
  const reset = useCallback(() => setSt({ total: 0, endsAt: null, paused: null, finished: false }), []);
  const addTime = useCallback(
    (ms: number) =>
      setSt((s) => ({
        ...s,
        total: s.total + ms,
        endsAt: s.endsAt === null ? null : s.endsAt + ms,
        paused: s.paused === null ? null : Math.max(0, s.paused + ms),
      })),
    [],
  );

  return {
    total: st.total,
    remaining,
    running: st.endsAt !== null,
    paused: st.endsAt === null && st.paused !== null && st.paused > 0,
    finished: st.finished,
    start,
    pause,
    resume,
    reset,
    addTime,
    dismiss: () => setSt((s) => ({ ...s, finished: false })),
  };
}
