import { useMemo } from 'react';
import { BUILTIN_EXERCISES } from '../data/exercises';
import type { CustomExercise, Exercise } from '../types';
import { useData } from './useData';

export const customKey = (id: string) => `custom:${id}`;

export function customToExercise(c: CustomExercise): Exercise {
  return {
    key: customKey(c.id),
    name: c.name,
    muscle_group: c.muscle_group,
    secondary_muscles: c.secondary_muscles ?? [],
    equipment: c.equipment,
    difficulty: c.difficulty,
    instructions: c.instructions ?? '',
    sets: c.sets,
    reps: c.reps,
    rest_seconds: c.rest_seconds,
    mistakes: c.mistakes ?? '',
    tips: c.tips ?? '',
    custom: true,
  };
}

/** Built-in library + the user's custom exercises. */
export function useExercises() {
  const { tables } = useData();
  return useMemo(() => {
    const all = [...tables.custom_exercises.map(customToExercise), ...BUILTIN_EXERCISES];
    const byKey: Record<string, Exercise> = Object.fromEntries(all.map((e) => [e.key, e]));
    const favorites = new Set(tables.favorite_exercises.map((f) => f.exercise_key));
    return { all, byKey, favorites };
  }, [tables.custom_exercises, tables.favorite_exercises]);
}
