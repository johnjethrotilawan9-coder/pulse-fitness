import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { CONFLICT_TARGET, fetchAll, fetchProfile, fetchWorkouts, isNetworkError, normalizeRow, runOp, toApiError, type Op } from '../services/api';
import type { Profile, TableName, TableRows, Workout } from '../types';
import { useAuth } from './useAuth';
import { useToast } from './useToast';

export const TABLES: TableName[] = [
  'custom_exercises',
  'favorite_exercises',
  'workout_programs',
  'calendar_events',
  'running_sessions',
  'body_measurements',
  'progress_photos',
  'daily_metrics',
  'nutrition_entries',
  'foods',
  'meal_plans',
  'meal_templates',
  'water_entries',
  'habits',
  'habit_logs',
  'personal_records',
];

type Tables = { [K in TableName]: TableRows[K][] };

interface Store {
  profile: Profile | null;
  workouts: Workout[];
  tables: Tables;
}

export interface SaveResult {
  ok: boolean;
  queued?: boolean;
}

interface SaveOpts {
  /** Toast shown on success (omit for silent saves). */
  toast?: string;
}

export interface DataApi extends Store {
  loaded: boolean;
  loadError: string | null;
  syncing: boolean;
  pending: number;
  lastSync: number | null;
  refresh: () => Promise<void>;
  save: <T extends TableName>(table: T, row: TableRows[T], opts?: SaveOpts) => Promise<SaveResult>;
  saveMany: <T extends TableName>(table: T, rows: TableRows[T][], opts?: SaveOpts) => Promise<SaveResult>;
  remove: <T extends TableName>(table: T, row: TableRows[T], opts?: SaveOpts) => Promise<SaveResult>;
  saveWorkout: (w: Workout, opts?: SaveOpts) => Promise<SaveResult>;
  saveWorkouts: (ws: Workout[], opts?: SaveOpts) => Promise<SaveResult>;
  deleteWorkout: (id: string, opts?: SaveOpts) => Promise<SaveResult>;
  saveProfile: (patch: Partial<Profile>, opts?: SaveOpts) => Promise<SaveResult>;
}

const emptyTables = (): Tables => Object.fromEntries(TABLES.map((t) => [t, []])) as unknown as Tables;

export const DEFAULT_PROFILE: Omit<Profile, 'user_id'> = {
  name: null,
  height_cm: null,
  weight_kg: null,
  start_weight_kg: null,
  goal_weight_kg: null,
  date_of_birth: null,
  sex: null,
  weight_unit: 'kg',
  distance_unit: 'km',
  length_unit: 'cm',
  goals: [],
  calorie_target: 2000,
  protein_target: 120,
  carbs_target: 225,
  fat_target: 65,
  fiber_target: 25,
  water_target_ml: 2500,
  weekly_workout_target: 4,
  weekly_run_km_target: 10,
  step_target: 8000,
  default_rest_seconds: 90,
  theme: 'system',
  notifications_enabled: true,
  sound_enabled: true,
  show_meals_in_calendar: true,
};

// ---------- local persistence (offline cache + pending queue) ----------
const cacheKey = (uid: string) => `pulse.cache.v1.${uid}`;
const queueKey = (uid: string) => `pulse.queue.v1.${uid}`;

function readJSON<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}
function writeJSON(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage full or unavailable — the server remains the source of truth */
  }
}

/** Compact snapshot for offline start-up (GPS routes are left out to stay small). */
function snapshot(store: Store): Store {
  return {
    ...store,
    tables: { ...store.tables, running_sessions: store.tables.running_sessions.map((r) => ({ ...r, route: null })) },
  };
}

// ---------- pure state transitions ----------
function sameRow(table: string, a: Record<string, unknown>, b: Record<string, unknown>): boolean {
  if (a.id === b.id) return true;
  const target = CONFLICT_TARGET[table as TableName];
  if (!target || target === 'id') return false;
  return target
    .split(',')
    .filter((k) => k !== 'user_id')
    .every((k) => a[k] === b[k]);
}

function applyOp(store: Store, op: Op): Store {
  if (op.kind === 'saveWorkout') {
    const others = store.workouts.filter((w) => w.id !== op.workout.id);
    return { ...store, workouts: [...others, op.workout] };
  }
  if (op.kind === 'upsert') {
    if (op.table === 'profiles') return { ...store, profile: { ...(store.profile as Profile), ...(op.row as Partial<Profile>) } };
    const t = op.table as TableName;
    const rows = store.tables[t] as unknown as Record<string, unknown>[];
    const idx = rows.findIndex((r) => sameRow(t, r, op.row));
    const next = idx >= 0 ? rows.map((r, i) => (i === idx ? { ...r, ...op.row } : r)) : [...rows, { created_at: new Date().toISOString(), ...op.row }];
    return { ...store, tables: { ...store.tables, [t]: next } };
  }
  // delete
  const matches = (r: Record<string, unknown>) => Object.entries(op.match).every(([k, v]) => r[k] === v);
  if (op.table === 'workouts') return { ...store, workouts: store.workouts.filter((w) => !matches(w as unknown as Record<string, unknown>)) };
  const t = op.table as TableName;
  let tables = { ...store.tables, [t]: (store.tables[t] as unknown as Record<string, unknown>[]).filter((r) => !matches(r)) } as Tables;
  // mirror database cascades locally
  if (t === 'habits') tables = { ...tables, habit_logs: tables.habit_logs.filter((l) => l.habit_id !== op.match.id) };
  return { ...store, tables };
}

function deleteMatch(table: TableName, row: Record<string, unknown>): Record<string, unknown> {
  if (table === 'habit_logs') return { habit_id: row.habit_id, date: row.date };
  return { id: row.id };
}

const DataContext = createContext<DataApi | null>(null);

export function DataProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const toast = useToast();
  const uid = user?.id ?? null;

  const [store, setStore] = useState<Store>({ profile: null, workouts: [], tables: emptyTables() });
  const [loaded, setLoaded] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [syncing, setSyncing] = useState(false);
  const [queue, setQueue] = useState<Op[]>([]);
  const [lastSync, setLastSync] = useState<number | null>(null);

  const storeRef = useRef(store);
  storeRef.current = store;
  const queueRef = useRef<Op[]>([]);
  const flushing = useRef(false);
  const refreshing = useRef(false);

  const setQueueBoth = useCallback(
    (q: Op[]) => {
      queueRef.current = q;
      setQueue(q);
      if (uid) writeJSON(queueKey(uid), q);
    },
    [uid],
  );

  const commit = useCallback(
    (next: Store) => {
      storeRef.current = next;
      setStore(next);
      if (uid) writeJSON(cacheKey(uid), snapshot(next));
    },
    [uid],
  );

  // ---------- load from server ----------
  const refresh = useCallback(async () => {
    if (!uid || refreshing.current) return;
    refreshing.current = true;
    setSyncing(true);
    try {
      const [profileRow, workouts, ...lists] = await Promise.all([
        fetchProfile(uid),
        fetchWorkouts(),
        ...TABLES.map((t) => fetchAll<Record<string, unknown>>(t)),
      ]);
      let profile = profileRow;
      if (!profile) {
        profile = { ...DEFAULT_PROFILE, user_id: uid, name: (user?.user_metadata?.name as string) || null };
        await runOp({ kind: 'upsert', table: 'profiles', row: profile as unknown as Record<string, unknown> }).catch(() => undefined);
      }
      const tables = emptyTables();
      TABLES.forEach((t, i) => {
        (tables as unknown as Record<string, unknown[]>)[t] = lists[i].map((r) => normalizeRow(r));
      });
      let next: Store = { profile: { ...DEFAULT_PROFILE, ...profile }, workouts, tables };
      // keep not-yet-synced local changes visible
      for (const op of queueRef.current) next = applyOp(next, op);
      commit(next);
      setLoaded(true);
      setLoadError(null);
      setLastSync(Date.now());
    } catch (err) {
      const e = toApiError(err);
      if (!storeRef.current.profile) setLoadError(e.network ? 'You are offline and no saved copy is available on this device yet.' : e.message);
      else if (!e.network) toast.error(`Sync failed: ${e.message}`);
    } finally {
      refreshing.current = false;
      setSyncing(false);
    }
  }, [uid, user, commit, toast]);

  // ---------- replay queued offline changes ----------
  const flush = useCallback(async () => {
    if (!uid || flushing.current || queueRef.current.length === 0 || !navigator.onLine) return;
    flushing.current = true;
    setSyncing(true);
    let synced = 0;
    let failed = 0;
    try {
      while (queueRef.current.length) {
        const op = queueRef.current[0];
        try {
          await runOp(op);
          synced++;
        } catch (err) {
          if (isNetworkError(err)) break; // still offline — keep the rest
          failed++;
          toast.error(`A change could not be synced and was discarded: ${toApiError(err).message}`);
        }
        setQueueBoth(queueRef.current.slice(1));
      }
    } finally {
      flushing.current = false;
      setSyncing(false);
    }
    if (synced && !queueRef.current.length) toast.success(`Synced ${synced} offline change${synced === 1 ? '' : 's'}.`);
    if (synced || failed) await refresh();
  }, [uid, refresh, setQueueBoth, toast]);

  // ---------- boot / user change ----------
  useEffect(() => {
    if (!uid) {
      setStore({ profile: null, workouts: [], tables: emptyTables() });
      storeRef.current = { profile: null, workouts: [], tables: emptyTables() };
      queueRef.current = [];
      setQueue([]);
      setLoaded(false);
      return;
    }
    const cached = readJSON<Store>(cacheKey(uid));
    const q = readJSON<Op[]>(queueKey(uid)) ?? [];
    queueRef.current = q;
    setQueue(q);
    if (cached?.profile) {
      const merged: Store = { profile: cached.profile, workouts: cached.workouts ?? [], tables: { ...emptyTables(), ...cached.tables } };
      storeRef.current = merged;
      setStore(merged);
      setLoaded(true);
    }
    void (async () => {
      await flush();
      await refresh();
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [uid]);

  // ---------- keep devices in sync ----------
  useEffect(() => {
    if (!uid) return;
    let last = Date.now();
    const sync = () => {
      if (document.visibilityState !== 'visible') return;
      if (Date.now() - last < 20_000) return;
      last = Date.now();
      void flush().then(() => refresh());
    };
    const onOnline = () => {
      last = 0;
      sync();
    };
    document.addEventListener('visibilitychange', sync);
    window.addEventListener('focus', sync);
    window.addEventListener('online', onOnline);
    const timer = window.setInterval(sync, 180_000);
    return () => {
      document.removeEventListener('visibilitychange', sync);
      window.removeEventListener('focus', sync);
      window.removeEventListener('online', onOnline);
      window.clearInterval(timer);
    };
  }, [uid, flush, refresh]);

  // ---------- write path ----------
  const perform = useCallback(
    async (ops: Op[], opts?: SaveOpts): Promise<SaveResult> => {
      if (!uid) return { ok: false };
      const queueUp = () => {
        let next = storeRef.current;
        for (const op of ops) next = applyOp(next, op);
        commit(next);
        setQueueBoth([...queueRef.current, ...ops]);
        toast.warning('Saved on this device only — it will sync to your account when you are back online.');
        return { ok: true, queued: true };
      };
      if (!navigator.onLine || queueRef.current.length > 0) {
        // Keep order: if older changes are still waiting, queue behind them.
        const res = queueUp();
        if (navigator.onLine) void flush();
        return res;
      }
      let done = 0;
      try {
        for (const op of ops) {
          await runOp(op);
          commit(applyOp(storeRef.current, op));
          done++;
        }
        if (opts?.toast) toast.success(opts.toast);
        return { ok: true };
      } catch (err) {
        if (isNetworkError(err)) {
          ops = ops.slice(done);
          return queueUp();
        }
        toast.error(`Not saved: ${toApiError(err).message}`);
        return { ok: false };
      }
    },
    [uid, commit, setQueueBoth, toast, flush],
  );

  const withUser = useCallback(<R extends object>(row: R) => ({ ...row, user_id: uid }), [uid]);

  const api = useMemo<DataApi>(
    () => ({
      ...store,
      loaded,
      loadError,
      syncing,
      pending: queue.length,
      lastSync,
      refresh: async () => {
        await flush();
        await refresh();
      },
      save: (table, row, opts) => {
        const { created_at: _c, updated_at: _u, ...clean } = row as unknown as Record<string, unknown>;
        return perform([{ kind: 'upsert', table, row: withUser(clean) }], opts);
      },
      saveMany: (table, rows, opts) =>
        perform(
          rows.map((row) => {
            const { created_at: _c, updated_at: _u, ...clean } = row as unknown as Record<string, unknown>;
            return { kind: 'upsert', table, row: withUser(clean) } as Op;
          }),
          opts,
        ),
      remove: (table, row, opts) => perform([{ kind: 'delete', table, match: deleteMatch(table, row as unknown as Record<string, unknown>) }], opts),
      saveWorkout: (w, opts) => perform([{ kind: 'saveWorkout', workout: { ...w, user_id: uid ?? undefined } }], opts),
      saveWorkouts: (ws, opts) => perform(ws.map((w) => ({ kind: 'saveWorkout', workout: { ...w, user_id: uid ?? undefined } }) as Op), opts),
      deleteWorkout: (id, opts) => perform([{ kind: 'delete', table: 'workouts', match: { id } }], opts),
      saveProfile: (patch, opts) => {
        const base = storeRef.current.profile ?? ({ ...DEFAULT_PROFILE, user_id: uid } as Profile);
        const { created_at: _c, updated_at: _u, ...row } = { ...base, ...patch, user_id: uid };
        return perform([{ kind: 'upsert', table: 'profiles', row: row as Record<string, unknown> }], opts);
      },
    }),
    [store, loaded, loadError, syncing, queue.length, lastSync, flush, refresh, perform, withUser, uid],
  );

  return <DataContext.Provider value={api}>{children}</DataContext.Provider>;
}

export function useData(): DataApi {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData outside DataProvider');
  return ctx;
}

/** Profile is guaranteed once the app shell renders. */
export function useProfile(): Profile {
  const { profile } = useData();
  return profile as Profile;
}

/** Clear this device's cached copy (used on sign-out). */
export function clearLocalData(uid: string) {
  try {
    localStorage.removeItem(cacheKey(uid));
    localStorage.removeItem(queueKey(uid));
  } catch {
    /* ignore */
  }
}

export function pendingCount(uid: string): number {
  return readJSON<Op[]>(queueKey(uid))?.length ?? 0;
}


