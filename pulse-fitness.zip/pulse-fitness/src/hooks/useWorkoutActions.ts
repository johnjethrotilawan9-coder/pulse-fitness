import { useData } from './useData';
import { useConfirm } from '../components/ui/Confirm';
import { duplicateWorkout } from '../utils/workout';
import { workoutTotals } from '../utils/calc';
import { fmtDate } from '../utils/date';
import type { Workout, WorkoutStatus } from '../types';

export function useWorkoutActions() {
  const { saveWorkout, deleteWorkout } = useData();
  const confirm = useConfirm();

  return {
    setStatus: (w: Workout, status: WorkoutStatus) => {
      const next: Workout = { ...w, status };
      if (status === 'completed') {
        // When marking complete without live tracking, treat every logged set as done.
        next.exercises = w.exercises.map((e) => ({ ...e, sets: e.sets.map((s) => ({ ...s, completed: s.completed || s.reps != null || s.weight_kg != null })) }));
        next.total_volume_kg = workoutTotals(next).volumeKg || null;
      }
      const msg = { completed: 'Marked as completed 💪', skipped: 'Marked as skipped', planned: 'Marked as planned', in_progress: 'Marked in progress' }[status];
      return saveWorkout(next, { toast: msg });
    },
    reschedule: (w: Workout, date: string) =>
      saveWorkout({ ...w, date, status: w.status === 'skipped' ? 'planned' : w.status }, { toast: `Moved to ${fmtDate(date, { weekday: 'short', month: 'short', day: 'numeric' })}` }),
    duplicate: async (w: Workout, date: string, keepResults: boolean) => {
      const copy = duplicateWorkout(w, date, keepResults);
      const res = await saveWorkout(copy, { toast: 'Workout duplicated' });
      return res.ok ? copy : null;
    },
    remove: async (w: Workout) => {
      const ok = await confirm({
        title: 'Delete this workout?',
        message: `“${w.name}” on ${fmtDate(w.date, { month: 'long', day: 'numeric', year: 'numeric' })} and all its sets will be permanently deleted.`,
        confirmLabel: 'Delete',
        danger: true,
      });
      if (!ok) return false;
      const res = await deleteWorkout(w.id, { toast: 'Workout deleted' });
      return res.ok;
    },
  };
}
