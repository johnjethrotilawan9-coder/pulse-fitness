import { useMemo } from 'react';
import { useProfile } from './useData';
import { cmTo, kgTo, kmTo, round, toCm, toKg, toKm } from '../utils/units';
import { fmtDuration, fmtNum } from '../utils/format';

/** Unit-aware formatting and parsing based on the user's settings. */
export function useUnits() {
  const p = useProfile();
  return useMemo(() => {
    const w = p?.weight_unit ?? 'kg';
    const d = p?.distance_unit ?? 'km';
    const l = p?.length_unit ?? 'cm';
    return {
      w,
      d,
      l,
      /** kg → display number */
      weight: (kg: number | null | undefined) => (kg == null ? null : round(kgTo(kg, w), 1)),
      fmtWeight: (kg: number | null | undefined, digits = 1) => (kg == null ? '–' : `${fmtNum(kgTo(kg, w), digits)} ${w}`),
      fromWeight: (v: number | null) => (v == null ? null : round(toKg(v, w), 3)),
      dist: (km: number | null | undefined) => (km == null ? null : round(kmTo(km, d), 2)),
      fmtDist: (km: number | null | undefined, digits = 2) => (km == null ? '–' : `${fmtNum(kmTo(km, d), digits)} ${d}`),
      fromDist: (v: number | null) => (v == null ? null : round(toKm(v, d), 4)),
      len: (cm: number | null | undefined) => (cm == null ? null : round(cmTo(cm, l), 1)),
      fmtLen: (cm: number | null | undefined) => (cm == null ? '–' : `${fmtNum(cmTo(cm, l), 1)} ${l}`),
      fromLen: (v: number | null) => (v == null ? null : round(toCm(v, l), 2)),
      /** seconds per km → 'M:SS /km' or '/mi' */
      fmtPace: (secPerKm: number | null | undefined) =>
        secPerKm == null || !isFinite(secPerKm) || secPerKm <= 0 ? '–' : `${fmtDuration(d === 'mi' ? secPerKm * 1.609344 : secPerKm)} /${d}`,
      fmtSpeed: (kmh: number | null | undefined) => (kmh == null ? '–' : `${fmtNum(kmTo(kmh, d), 1)} ${d === 'mi' ? 'mph' : 'km/h'}`),
    };
  }, [p?.weight_unit, p?.distance_unit, p?.length_unit]);
}
