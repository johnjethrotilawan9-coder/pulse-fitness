import { useEffect } from 'react';
import type { ThemeMode } from '../types';

const KEY = 'pulse.theme';

export function applyTheme(mode: ThemeMode) {
  const dark = mode === 'dark' || (mode === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', dark ? '#0d0f12' : '#f5f6f8');
  try {
    localStorage.setItem(KEY, mode);
  } catch {
    /* ignore */
  }
}

export function storedTheme(): ThemeMode {
  try {
    const v = localStorage.getItem(KEY);
    if (v === 'light' || v === 'dark' || v === 'system') return v;
  } catch {
    /* ignore */
  }
  return 'system';
}

export function useTheme(mode: ThemeMode | undefined) {
  useEffect(() => {
    const m = mode ?? storedTheme();
    applyTheme(m);
    if (m !== 'system') return;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const on = () => applyTheme('system');
    mq.addEventListener('change', on);
    return () => mq.removeEventListener('change', on);
  }, [mode]);
}
