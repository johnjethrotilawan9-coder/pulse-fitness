import type { ISODate } from '../types';

const pad = (n: number) => String(n).padStart(2, '0');

/** Local-calendar date string (never UTC-shifted). */
export function toISO(d: Date): ISODate {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
export const todayISO = (): ISODate => toISO(new Date());

export function parseISO(s: ISODate): Date {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}
export function isValidISO(s: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = parseISO(s);
  return toISO(d) === s && d.getFullYear() > 1900 && d.getFullYear() < 2200;
}
export function addDays(s: ISODate, n: number): ISODate {
  const d = parseISO(s);
  d.setDate(d.getDate() + n);
  return toISO(d);
}
export function diffDays(a: ISODate, b: ISODate): number {
  return Math.round((parseISO(a).getTime() - parseISO(b).getTime()) / 86400000);
}
/** Monday-based week start. */
export function startOfWeek(s: ISODate): ISODate {
  const d = parseISO(s);
  const dow = (d.getDay() + 6) % 7;
  return addDays(s, -dow);
}
export const endOfWeek = (s: ISODate) => addDays(startOfWeek(s), 6);
export const startOfMonth = (s: ISODate) => s.slice(0, 8) + '01';
export function endOfMonth(s: ISODate): ISODate {
  const d = parseISO(startOfMonth(s));
  return toISO(new Date(d.getFullYear(), d.getMonth() + 1, 0));
}
export function addMonths(s: ISODate, n: number): ISODate {
  const d = parseISO(startOfMonth(s));
  return toISO(new Date(d.getFullYear(), d.getMonth() + n, 1));
}
export const inRange = (s: ISODate, from: ISODate, to: ISODate) => s >= from && s <= to;

export function daysBetween(from: ISODate, to: ISODate): ISODate[] {
  const out: ISODate[] = [];
  for (let d = from; d <= to; d = addDays(d, 1)) out.push(d);
  return out;
}

export function fmtDate(s: ISODate, opts: Intl.DateTimeFormatOptions = { month: 'short', day: 'numeric' }): string {
  return parseISO(s).toLocaleDateString(undefined, opts);
}
export const fmtLongDate = (s: ISODate) =>
  fmtDate(s, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
export const fmtWeekday = (s: ISODate) => fmtDate(s, { weekday: 'short' });
export const fmtMonth = (s: ISODate) => fmtDate(s, { month: 'long', year: 'numeric' });

export function relativeDay(s: ISODate): string {
  const diff = diffDays(s, todayISO());
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Tomorrow';
  if (diff === -1) return 'Yesterday';
  if (diff > 1 && diff < 7) return fmtDate(s, { weekday: 'long' });
  return fmtDate(s, { weekday: 'short', month: 'short', day: 'numeric' });
}

export function nowTime(): string {
  const d = new Date();
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
/** Minutes between two 'HH:MM' times (crossing midnight allowed). */
export function minutesBetween(start: string, end: string): number | null {
  if (!/^\d{2}:\d{2}/.test(start) || !/^\d{2}:\d{2}/.test(end)) return null;
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  let m = eh * 60 + em - (sh * 60 + sm);
  if (m < 0) m += 1440;
  return m;
}
export function greeting(): string {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
}
