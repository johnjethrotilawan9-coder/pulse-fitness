import type { DistanceUnit, LengthUnit, WeightUnit } from '../types';

export const KG_PER_LB = 0.45359237;
export const KM_PER_MI = 1.609344;
export const CM_PER_IN = 2.54;

export const kgTo = (kg: number, u: WeightUnit) => (u === 'lb' ? kg / KG_PER_LB : kg);
export const toKg = (v: number, u: WeightUnit) => (u === 'lb' ? v * KG_PER_LB : v);
export const kmTo = (km: number, u: DistanceUnit) => (u === 'mi' ? km / KM_PER_MI : km);
export const toKm = (v: number, u: DistanceUnit) => (u === 'mi' ? v * KM_PER_MI : v);
export const cmTo = (cm: number, u: LengthUnit) => (u === 'in' ? cm / CM_PER_IN : cm);
export const toCm = (v: number, u: LengthUnit) => (u === 'in' ? v * CM_PER_IN : v);

export const round = (n: number, d = 1) => Math.round(n * 10 ** d) / 10 ** d;
