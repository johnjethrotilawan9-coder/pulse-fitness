import type { BodyMeasurement, RunningSession, Workout, WaterEntry, NutritionEntry } from '../types';
import { addDays, inRange, startOfWeek, todayISO } from './date';
import { paceSecPerKm, runDurationMin, workoutMinutes, workoutTotals } from './calc';

export const isDoneWorkout = (w: Workout) => w.status === 'completed';
export const isDoneRun = (r: RunningSession) => r.status === 'completed';

/** Days with a completed workout or run. */
export function activeDays(workouts: Workout[], runs: RunningSession[]): Set<string> {
  const s = new Set<string>();
  workouts.filter(isDoneWorkout).forEach((w) => s.add(w.date));
  runs.filter(isDoneRun).forEach((r) => s.add(r.date));
  return s;
}

/** Consecutive active days ending today (or yesterday, if today isn't done yet). */
export function currentStreak(days: Set<string>, today = todayISO()): number {
  let d = days.has(today) ? today : addDays(today, -1);
  let n = 0;
  while (days.has(d)) {
    n++;
    d = addDays(d, -1);
  }
  return n;
}

export function longestStreak(days: Set<string>): number {
  const sorted = [...days].sort();
  let best = 0, cur = 0;
  let prev: string | null = null;
  for (const d of sorted) {
    cur = prev && addDays(prev, 1) === d ? cur + 1 : 1;
    best = Math.max(best, cur);
    prev = d;
  }
  return best;
}

export interface PeriodStats {
  workouts: number;
  completed: number;
  skipped: number;
  planned: number;
  minutes: number;
  calories: number;
  runKm: number;
  runMin: number;
  runs: number;
  avgWorkoutMin: number;
  volumeKg: number;
  muscleCounts: Record<string, number>;
  exerciseCounts: Record<string, number>;
}

export function periodStats(workouts: Workout[], runs: RunningSession[], from: string, to: string): PeriodStats {
  const ws = workouts.filter((w) => inRange(w.date, from, to));
  const done = ws.filter(isDoneWorkout);
  const rs = runs.filter((r) => isDoneRun(r) && inRange(r.date, from, to));
  const muscleCounts: Record<string, number> = {};
  const exerciseCounts: Record<string, number> = {};
  let minutes = 0, calories = 0, volumeKg = 0;
  for (const w of done) {
    const m = workoutMinutes(w);
    minutes += m;
    calories += w.calories ?? 0;
    volumeKg += workoutTotals(w).volumeKg;
    const groups = new Set<string>(w.muscle_groups);
    w.exercises.forEach((e) => {
      if (e.skipped) return;
      if (e.muscle_group) groups.add(e.muscle_group);
      exerciseCounts[e.name] = (exerciseCounts[e.name] ?? 0) + 1;
    });
    groups.forEach((g) => (muscleCounts[g] = (muscleCounts[g] ?? 0) + 1));
  }
  const runMin = rs.reduce((a, r) => a + runDurationMin(r), 0);
  calories += rs.reduce((a, r) => a + (r.calories ?? 0), 0);
  return {
    workouts: ws.length,
    completed: done.length,
    skipped: ws.filter((w) => w.status === 'skipped').length,
    planned: ws.filter((w) => w.status === 'planned').length,
    minutes: minutes + runMin,
    calories,
    runKm: rs.reduce((a, r) => a + (r.distance_km ?? 0), 0),
    runMin,
    runs: rs.length,
    avgWorkoutMin: done.length ? minutes / done.length : 0,
    volumeKg,
    muscleCounts,
    exerciseCounts,
  };
}

export const topKey = (rec: Record<string, number>): string | null =>
  Object.entries(rec).sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;

/** Latest and earliest measurement with a value for `key` in [from, to]. */
export function measurementChange(ms: BodyMeasurement[], key: keyof BodyMeasurement, from: string, to: string) {
  const vals = ms
    .filter((m) => inRange(m.date, from, to) && m[key] != null)
    .sort((a, b) => a.date.localeCompare(b.date));
  if (vals.length < 2) return null;
  return { first: vals[0][key] as number, last: vals[vals.length - 1][key] as number, delta: (vals[vals.length - 1][key] as number) - (vals[0][key] as number) };
}

export function latestWeight(ms: BodyMeasurement[]): { value: number; date: string } | null {
  const w = ms.filter((m) => m.weight_kg != null).sort((a, b) => a.date.localeCompare(b.date) || (a.created_at ?? '').localeCompare(b.created_at ?? ''));
  const last = w[w.length - 1];
  return last ? { value: last.weight_kg as number, date: last.date } : null;
}
export function firstWeight(ms: BodyMeasurement[]): { value: number; date: string } | null {
  const w = ms.filter((m) => m.weight_kg != null).sort((a, b) => a.date.localeCompare(b.date));
  return w[0] ? { value: w[0].weight_kg as number, date: w[0].date } : null;
}

export function waterByDay(entries: WaterEntry[]): Record<string, number> {
  const out: Record<string, number> = {};
  entries.forEach((e) => (out[e.date] = (out[e.date] ?? 0) + e.amount_ml));
  return out;
}

export function nutritionTotals(entries: NutritionEntry[]) {
  return entries.reduce(
    (a, e) => ({
      calories: a.calories + (e.calories ?? 0),
      protein: a.protein + (e.protein_g ?? 0),
      carbs: a.carbs + (e.carbs_g ?? 0),
      fat: a.fat + (e.fat_g ?? 0),
      fiber: a.fiber + (e.fiber_g ?? 0),
      sugar: a.sugar + (e.sugar_g ?? 0),
    }),
    { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0, sugar: 0 },
  );
}

/** Most workouts completed in any Monday–Sunday week. */
export function bestWeek(workouts: Workout[]): { count: number; week: string } | null {
  const byWeek: Record<string, number> = {};
  workouts.filter(isDoneWorkout).forEach((w) => {
    const k = startOfWeek(w.date);
    byWeek[k] = (byWeek[k] ?? 0) + 1;
  });
  const top = Object.entries(byWeek).sort((a, b) => b[1] - a[1])[0];
  return top ? { week: top[0], count: top[1] } : null;
}

export interface AutoPR {
  id: string;
  title: string;
  value: number;
  kind: 'distance' | 'duration' | 'minutes' | 'weight' | 'count' | 'days' | 'reps';
  date: string;
  detail?: string;
  estimated?: boolean;
}

/** Personal records derived from the workout and running history. */
export function autoRecords(workouts: Workout[], runs: RunningSession[]): { general: AutoPR[]; lifts: AutoPR[] } {
  const general: AutoPR[] = [];
  const doneRuns = runs.filter((r) => isDoneRun(r) && (r.distance_km ?? 0) > 0);
  const longest = [...doneRuns].sort((a, b) => (b.distance_km ?? 0) - (a.distance_km ?? 0))[0];
  if (longest) general.push({ id: 'longest-run', title: 'Longest run', value: longest.distance_km!, kind: 'distance', date: longest.date, detail: longest.route_name ?? undefined });

  let best1k: AutoPR | null = null;
  for (const r of doneRuns) {
    for (const s of r.splits ?? []) {
      if (s.km >= 0.99 && s.sec >= 100 && (!best1k || s.sec < best1k.value)) best1k = { id: 'fastest-1k', title: 'Fastest 1 km', value: s.sec, kind: 'duration', date: r.date, detail: 'GPS split' };
    }
    const pace = paceSecPerKm(r.duration_sec, r.distance_km);
    if (pace && pace >= 100 && (r.distance_km ?? 0) >= 1 && (!best1k || pace < best1k.value)) {
      best1k = { id: 'fastest-1k', title: 'Fastest 1 km', value: pace, kind: 'duration', date: r.date, detail: 'from average pace', estimated: true };
    }
  }
  if (best1k) general.push(best1k);

  const fives = doneRuns.filter((r) => (r.distance_km ?? 0) >= 5 && r.duration_sec && (paceSecPerKm(r.duration_sec, r.distance_km) ?? 0) >= 100);
  const best5 = fives
    .map((r) => ({ r, t: (paceSecPerKm(r.duration_sec, r.distance_km) ?? 0) * 5 }))
    .sort((a, b) => a.t - b.t)[0];
  if (best5) general.push({ id: 'fastest-5k', title: 'Fastest 5 km', value: best5.t, kind: 'duration', date: best5.r.date, detail: (best5.r.distance_km ?? 0) > 5.05 ? 'from average pace' : undefined, estimated: (best5.r.distance_km ?? 0) > 5.05 });

  const doneW = workouts.filter(isDoneWorkout);
  const longestW = [...doneW].sort((a, b) => workoutMinutes(b) - workoutMinutes(a))[0];
  if (longestW && workoutMinutes(longestW) > 0) general.push({ id: 'longest-workout', title: 'Longest workout', value: workoutMinutes(longestW), kind: 'minutes', date: longestW.date, detail: longestW.name });

  const bw = bestWeek(workouts);
  if (bw) general.push({ id: 'best-week', title: 'Most workouts in a week', value: bw.count, kind: 'count', date: bw.week, detail: 'week of' });

  const days = activeDays(workouts, runs);
  const ls = longestStreak(days);
  if (ls > 0) general.push({ id: 'streak', title: 'Longest activity streak', value: ls, kind: 'days', date: todayISO() });

  const lifts: AutoPR[] = [];
  const heaviest: Record<string, AutoPR> = {};
  const mostReps: Record<string, AutoPR> = {};
  for (const w of doneW) {
    for (const ex of w.exercises) {
      if (ex.skipped) continue;
      for (const s of ex.sets) {
        if (!(s.completed || w.status === 'completed')) continue;
        if ((s.weight_kg ?? 0) > 0 && (!heaviest[ex.name] || s.weight_kg! > heaviest[ex.name].value)) {
          heaviest[ex.name] = { id: `w-${ex.name}`, title: ex.name, value: s.weight_kg!, kind: 'weight', date: w.date, detail: s.reps ? `${s.reps} reps` : undefined };
        }
        if ((s.reps ?? 0) > 0 && (!mostReps[ex.name] || s.reps! > mostReps[ex.name].value)) {
          mostReps[ex.name] = { id: `r-${ex.name}`, title: ex.name, value: s.reps!, kind: 'reps', date: w.date };
        }
      }
    }
  }
  Object.values(heaviest).forEach((p) => lifts.push(p));
  Object.values(mostReps).forEach((p) => {
    if (!heaviest[p.title]) lifts.push(p);
  });
  lifts.sort((a, b) => a.title.localeCompare(b.title));
  return { general, lifts };
}

/** Per-week totals for the last `n` weeks (oldest first). */
export function weeklySeries(n: number, fn: (from: string, to: string) => number, today = todayISO()) {
  const start = startOfWeek(today);
  const out: { label: string; value: number; from: string }[] = [];
  for (let i = n - 1; i >= 0; i--) {
    const from = addDays(start, -7 * i);
    out.push({ from, label: from.slice(5).replace('-', '/'), value: fn(from, addDays(from, 6)) });
  }
  return out;
}
