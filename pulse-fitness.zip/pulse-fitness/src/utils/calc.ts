import type { GeoPoint, RunningSession, Workout } from '../types';

/** Pace in seconds per km. */
export function paceSecPerKm(durationSec: number | null, distanceKm: number | null): number | null {
  if (!durationSec || !distanceKm || distanceKm <= 0) return null;
  return durationSec / distanceKm;
}
export function speedKmh(durationSec: number | null, distanceKm: number | null): number | null {
  if (!durationSec || !distanceKm || durationSec <= 0) return null;
  return distanceKm / (durationSec / 3600);
}

/** MET values used for rough calorie estimates (general guidance, not medical). */
export const MET: Record<string, number> = {
  strength: 5,
  hiit: 8,
  cardio: 7,
  circuit: 6.5,
  core: 4,
  mobility: 2.5,
  yoga: 2.5,
  stretching: 2.3,
  sports: 6,
  cycling: 7,
  swimming: 7,
  walking: 3.5,
  other: 4.5,
};

export function estimateWorkoutCalories(type: string, minutes: number | null, weightKg: number | null): number | null {
  if (!minutes || minutes <= 0) return null;
  const met = MET[type] ?? MET.other;
  return Math.round(met * (weightKg || 70) * (minutes / 60));
}

/** Running ≈ 1.0 kcal/kg/km, walking ≈ 0.55 kcal/kg/km (common rule of thumb). */
export function estimateRunCalories(activity: string, distanceKm: number | null, weightKg: number | null): number | null {
  if (!distanceKm || distanceKm <= 0) return null;
  const factor = activity === 'walk' ? 0.55 : activity === 'jog' ? 0.9 : 1.0;
  return Math.round(factor * (weightKg || 70) * distanceKm);
}

export interface WorkoutTotals {
  exercises: number;
  sets: number;
  reps: number;
  volumeKg: number;
}

/** Totals over sets that were done (completed flag, or every set when logged afterwards). */
export function workoutTotals(w: Pick<Workout, 'exercises' | 'status'>, onlyCompletedSets = false): WorkoutTotals {
  let sets = 0, reps = 0, volumeKg = 0, exercises = 0;
  for (const ex of w.exercises) {
    if (ex.skipped) continue;
    const done = ex.sets.filter((s) => (onlyCompletedSets ? s.completed : s.completed || w.status === 'completed'));
    if (done.length) exercises++;
    for (const s of done) {
      sets++;
      reps += s.reps ?? 0;
      volumeKg += (s.reps ?? 0) * (s.weight_kg ?? 0);
    }
  }
  return { exercises, sets, reps, volumeKg: Math.round(volumeKg * 10) / 10 };
}

export function haversineKm(a: GeoPoint, b: GeoPoint): number {
  const R = 6371;
  const toRad = (x: number) => (x * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

export function runDurationMin(r: RunningSession): number {
  return (r.duration_sec ?? 0) / 60;
}

/** Workout minutes: stored duration, or derived from start/end time. */
export function workoutMinutes(w: Workout): number {
  if (w.duration_min != null) return w.duration_min;
  if (w.start_time && w.end_time) {
    const [sh, sm] = w.start_time.split(':').map(Number);
    const [eh, em] = w.end_time.split(':').map(Number);
    let m = eh * 60 + em - (sh * 60 + sm);
    if (m < 0) m += 1440;
    return m;
  }
  return 0;
}
