import type { Exercise, ProgramDay, ProgramExercise, Workout, WorkoutExercise, WorkoutSet } from '../types';
import { uuid } from './id';
import { todayISO } from './date';

export function newSet(prev?: Partial<WorkoutSet>): WorkoutSet {
  return { id: uuid(), reps: prev?.reps ?? null, weight_kg: prev?.weight_kg ?? null, duration_sec: prev?.duration_sec ?? null, distance_km: prev?.distance_km ?? null, completed: false };
}

/** First number in a reps string like '8–12' or '30 s'. */
export function firstNumber(s: string | null | undefined): number | null {
  const m = String(s ?? '').match(/\d+/);
  return m ? Number(m[0]) : null;
}

export function exerciseFromLibrary(e: Exercise, defaultRest = 90): WorkoutExercise {
  const sets = Math.max(1, e.sets ?? 3);
  const reps = firstNumber(e.reps);
  const timed = /\bs\b|sec|min/.test(e.reps ?? '');
  return {
    id: uuid(),
    exercise_key: e.key,
    name: e.name,
    muscle_group: e.muscle_group,
    rest_seconds: e.rest_seconds ?? defaultRest,
    target_sets: sets,
    target_reps: e.reps,
    notes: null,
    skipped: false,
    sets: Array.from({ length: sets }, () => newSet({ reps: timed ? null : reps })),
  };
}

export function exerciseFromProgram(p: ProgramExercise): WorkoutExercise {
  const timed = /\bs\b|sec|min/.test(p.reps ?? '');
  const reps = timed ? null : firstNumber(p.reps);
  return {
    id: uuid(),
    exercise_key: p.exercise_key,
    name: p.name,
    muscle_group: p.muscle_group,
    rest_seconds: p.rest_seconds,
    target_sets: p.sets,
    target_reps: p.reps,
    notes: null,
    skipped: false,
    sets: Array.from({ length: Math.max(1, p.sets) }, () => newSet({ reps })),
  };
}

export function blankWorkout(date = todayISO()): Workout {
  return {
    id: uuid(),
    date,
    name: '',
    workout_type: 'strength',
    status: 'planned',
    start_time: null,
    end_time: null,
    duration_min: null,
    muscle_groups: [],
    distance_km: null,
    calories: null,
    difficulty: null,
    energy_level: null,
    mood: null,
    notes: null,
    total_volume_kg: null,
    program_name: null,
    exercises: [],
  };
}

export function workoutFromProgramDay(day: ProgramDay, date: string, programName: string | null): Workout {
  const muscles = [...new Set(day.exercises.map((e) => e.muscle_group).filter(Boolean) as string[])];
  return {
    ...blankWorkout(date),
    name: day.name,
    workout_type: day.type === 'run' ? 'cardio' : day.type,
    muscle_groups: muscles,
    notes: day.focus || null,
    program_name: programName,
    exercises: day.exercises.map(exerciseFromProgram),
  };
}

/** Deep copy with fresh ids — used for Duplicate. Results are reset to a planned session. */
export function duplicateWorkout(w: Workout, date: string, keepResults = false): Workout {
  return {
    ...w,
    id: uuid(),
    date,
    status: keepResults ? w.status : 'planned',
    start_time: keepResults ? w.start_time : null,
    end_time: keepResults ? w.end_time : null,
    created_at: undefined,
    updated_at: undefined,
    exercises: w.exercises.map((e) => ({
      ...e,
      id: uuid(),
      skipped: false,
      sets: e.sets.map((s) => ({ ...s, id: uuid(), completed: keepResults ? s.completed : false })),
    })),
  };
}

/** Most recent completed performance of an exercise before a given workout. */
export function previousPerformance(workouts: Workout[], exerciseName: string, beforeDate: string, excludeId: string): WorkoutSet[] | null {
  const prior = workouts
    .filter((w) => w.id !== excludeId && w.status === 'completed' && w.date <= beforeDate)
    .sort((a, b) => b.date.localeCompare(a.date) || (b.updated_at ?? '').localeCompare(a.updated_at ?? ''));
  for (const w of prior) {
    const ex = w.exercises.find((e) => e.name.toLowerCase() === exerciseName.toLowerCase() && !e.skipped);
    if (ex) {
      const done = ex.sets.filter((s) => s.completed || w.status === 'completed');
      if (done.length) return done;
    }
  }
  return null;
}
