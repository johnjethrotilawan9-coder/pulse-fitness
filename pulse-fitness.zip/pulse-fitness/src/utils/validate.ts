import { isValidISO } from './date';

export type Errors = Record<string, string>;

/** Parse an optional numeric input. Returns undefined when invalid. */
export function parseOptionalNumber(v: string | number | null | undefined): number | null | undefined {
  if (v === null || v === undefined) return null;
  const s = String(v).trim().replace(',', '.');
  if (s === '') return null;
  if (!/^-?\d*\.?\d+$/.test(s)) return undefined;
  const n = Number(s);
  return isFinite(n) ? n : undefined;
}

export class Validator {
  errors: Errors = {};
  required(field: string, value: unknown, msg = 'This field is required.') {
    if (value === null || value === undefined || String(value).trim() === '') this.errors[field] ??= msg;
    return this;
  }
  date(field: string, value: string, required = true) {
    if (!value) {
      if (required) this.errors[field] ??= 'Please choose a date.';
    } else if (!isValidISO(value)) this.errors[field] ??= 'Please enter a valid date.';
    return this;
  }
  /** Validates an optional number field; returns the parsed value (null if blank). */
  number(field: string, raw: string | number | null | undefined, opts: { min?: number; max?: number; int?: boolean; required?: boolean; label?: string } = {}) {
    const n = parseOptionalNumber(raw);
    const name = opts.label ?? 'Value';
    if (n === undefined) this.errors[field] ??= `${name} must be a number.`;
    else if (n === null) {
      if (opts.required) this.errors[field] ??= `${name} is required.`;
    } else {
      if (opts.int && !Number.isInteger(n)) this.errors[field] ??= `${name} must be a whole number.`;
      if (opts.min !== undefined && n < opts.min) this.errors[field] ??= opts.min === 0 ? `${name} cannot be negative.` : `${name} must be at least ${opts.min}.`;
      if (opts.max !== undefined && n > opts.max) this.errors[field] ??= `${name} must be at most ${opts.max}.`;
    }
    return n ?? null;
  }
  check(field: string, ok: boolean, msg: string) {
    if (!ok) this.errors[field] ??= msg;
    return this;
  }
  get ok() {
    return Object.keys(this.errors).length === 0;
  }
}
