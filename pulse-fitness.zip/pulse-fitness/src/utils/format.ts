export function fmtNum(n: number | null | undefined, digits = 0): string {
  if (n === null || n === undefined || !isFinite(n)) return '–';
  return n.toLocaleString(undefined, { maximumFractionDigits: digits, minimumFractionDigits: 0 });
}
/** Seconds → 'H:MM:SS' or 'M:SS'. */
export function fmtDuration(sec: number | null | undefined): string {
  if (sec === null || sec === undefined || !isFinite(sec)) return '–';
  const s = Math.max(0, Math.round(sec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = s % 60;
  return h > 0 ? `${h}:${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}` : `${m}:${String(r).padStart(2, '0')}`;
}
/** Minutes → '1h 25m'. */
export function fmtMinutes(min: number | null | undefined): string {
  if (min === null || min === undefined || !isFinite(min)) return '–';
  const m = Math.round(min);
  if (m < 60) return `${m}m`;
  return `${Math.floor(m / 60)}h ${m % 60 ? `${m % 60}m` : ''}`.trim();
}
/** Milliseconds → 'MM:SS.cc' (with hours when needed). */
export function fmtStopwatch(ms: number): string {
  const total = Math.max(0, Math.floor(ms));
  const h = Math.floor(total / 3600000);
  const m = Math.floor((total % 3600000) / 60000);
  const s = Math.floor((total % 60000) / 1000);
  const cs = Math.floor((total % 1000) / 10);
  const core = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${String(cs).padStart(2, '0')}`;
  return h > 0 ? `${h}:${core}` : core;
}
export const cap = (s: string) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s);
export const label = (s: string) => cap(s.replace(/_/g, ' '));
export function plural(n: number, word: string, pluralWord = word + 's') {
  return `${fmtNum(n)} ${n === 1 ? word : pluralWord}`;
}

/**
 * Parse a duration typed by the user: 'h:mm:ss', 'mm:ss' or plain minutes ('32', '32.5').
 * Returns seconds, null for blank, undefined for invalid.
 */
export function parseDuration(input: string): number | null | undefined {
  const s = input.trim();
  if (!s) return null;
  if (/^\d+(\.\d+)?$/.test(s)) return Math.round(Number(s) * 60);
  const parts = s.split(':');
  if (parts.length < 2 || parts.length > 3 || parts.some((p) => !/^\d+$/.test(p))) return undefined;
  const nums = parts.map(Number);
  if (nums.slice(1).some((n) => n >= 60)) return undefined;
  return parts.length === 3 ? nums[0] * 3600 + nums[1] * 60 + nums[2] : nums[0] * 60 + nums[1];
}

/** Seconds → editable string 'h:mm:ss' / 'mm:ss'. */
export function durationInput(sec: number | null | undefined): string {
  return sec == null ? '' : fmtDuration(sec);
}
