import { supabase } from './supabase';
import type { Profile, TableName, Workout, WorkoutExercise, WorkoutSet } from '../types';

export interface ApiError {
  message: string;
  network: boolean;
}

export type Op =
  | { kind: 'upsert'; table: TableName | 'profiles'; row: Record<string, unknown>; onConflict?: string }
  | { kind: 'delete'; table: TableName | 'workouts'; match: Record<string, unknown> }
  | { kind: 'saveWorkout'; workout: Workout };

const PAGE = 1000;

/** Unique constraints used as upsert targets (everything else upserts on id). */
export const CONFLICT_TARGET: Partial<Record<TableName | 'profiles', string>> = {
  profiles: 'user_id',
  habit_logs: 'habit_id,date',
  daily_metrics: 'user_id,date',
  favorite_exercises: 'user_id,exercise_key',
};

export function isNetworkError(err: unknown): boolean {
  if (typeof navigator !== 'undefined' && !navigator.onLine) return true;
  const msg = String((err as { message?: string })?.message ?? err ?? '');
  return /failed to fetch|network|load failed|fetch failed|networkerror|timed? ?out/i.test(msg);
}

export function toApiError(err: unknown): ApiError {
  const e = err as { message?: string; details?: string; hint?: string; code?: string };
  const network = isNetworkError(err);
  let message = e?.message || 'Something went wrong.';
  if (network) message = 'No connection to the server.';
  else if (e?.code === '23514') message = 'A value is outside the allowed range. Please check your entries.';
  else if (e?.code === '23505') message = 'That entry already exists.';
  else if (e?.code === '42501' || /row-level security/i.test(message)) message = 'Not allowed. Please sign in again.';
  else if (/JWT|token/i.test(message)) message = 'Your session expired. Please sign in again.';
  return { message, network };
}

/** Fetch every row of a table for the signed-in user, paging past the 1000-row API limit. */
export async function fetchAll<T>(table: string, select = '*'): Promise<T[]> {
  const out: T[] = [];
  for (let from = 0; ; from += PAGE) {
    const { data, error } = await supabase
      .from(table)
      .select(select)
      .order('created_at', { ascending: true })
      .range(from, from + PAGE - 1);
    if (error) throw error;
    const rows = (data ?? []) as T[];
    out.push(...rows);
    if (rows.length < PAGE) break;
  }
  return out;
}

const num = (v: unknown): number | null => (v === null || v === undefined || v === '' ? null : Number(v));

type RawSet = Omit<WorkoutSet, 'weight_kg' | 'distance_km'> & { position: number; weight_kg: unknown; distance_km: unknown };
type RawExercise = Omit<WorkoutExercise, 'sets'> & { position: number; workout_sets: RawSet[] };
type RawWorkout = Omit<Workout, 'exercises'> & { workout_exercises: RawExercise[] };

export async function fetchWorkouts(): Promise<Workout[]> {
  const raw = await fetchAll<RawWorkout>('workouts', '*, workout_exercises(*, workout_sets(*))');
  return raw.map(normalizeWorkout);
}

function normalizeWorkout(w: RawWorkout): Workout {
  const { workout_exercises, ...rest } = w;
  return {
    ...rest,
    duration_min: num(rest.duration_min),
    distance_km: num(rest.distance_km),
    total_volume_kg: num(rest.total_volume_kg),
    start_time: rest.start_time ? rest.start_time.slice(0, 5) : null,
    end_time: rest.end_time ? rest.end_time.slice(0, 5) : null,
    muscle_groups: rest.muscle_groups ?? [],
    exercises: [...(workout_exercises ?? [])]
      .sort((a, b) => a.position - b.position)
      .map(({ workout_sets, position: _p, ...ex }) => ({
        ...ex,
        sets: [...(workout_sets ?? [])]
          .sort((a, b) => a.position - b.position)
          .map((s) => ({
            id: s.id,
            reps: num(s.reps),
            weight_kg: num(s.weight_kg),
            duration_sec: num(s.duration_sec),
            distance_km: num(s.distance_km),
            completed: Boolean(s.completed),
          })),
      })),
  };
}

/** Numeric columns come back from Postgres as strings; normalise them. */
export function normalizeRow<T>(row: Record<string, unknown>): T {
  const out: Record<string, unknown> = { ...row };
  for (const [k, v] of Object.entries(out)) {
    if (typeof v === 'string' && /(_kg|_cm|_km|_g|_pct|_ml|calories|value|hours|pace_sec_per_km|target)$/.test(k) && v !== '' && !isNaN(Number(v))) {
      out[k] = Number(v);
    }
    if ((k === 'start_time' || k === 'end_time') && typeof v === 'string') out[k] = v.slice(0, 5);
  }
  return out as T;
}

export async function fetchProfile(userId: string): Promise<Profile | null> {
  const { data, error } = await supabase.from('profiles').select('*').eq('user_id', userId).maybeSingle();
  if (error) throw error;
  return data ? normalizeRow<Profile>(data) : null;
}

/** Execute one write against Supabase. Throws on failure. */
export async function runOp(op: Op): Promise<void> {
  if (op.kind === 'upsert') {
    const { error } = await supabase
      .from(op.table)
      .upsert(op.row, { onConflict: op.onConflict ?? CONFLICT_TARGET[op.table] ?? 'id' });
    if (error) throw error;
  } else if (op.kind === 'delete') {
    const { error } = await supabase.from(op.table).delete().match(op.match);
    if (error) throw error;
  } else {
    const { error } = await supabase.rpc('save_workout', { p: workoutPayload(op.workout) });
    if (error) throw error;
  }
}

function workoutPayload(w: Workout) {
  const { user_id: _u, created_at: _c, updated_at: _up, ...rest } = w;
  return rest;
}
