// Row types mirror supabase/schema.sql exactly. All stored values are metric
// (kg, km, cm, ml, seconds); conversion to the user's units happens in the UI.

export type ID = string;
export type ISODate = string; // 'YYYY-MM-DD' (local date)

interface Base {
  id: ID;
  user_id?: ID;
  created_at?: string;
  updated_at?: string;
}

export type WeightUnit = 'kg' | 'lb';
export type DistanceUnit = 'km' | 'mi';
export type LengthUnit = 'cm' | 'in';
export type ThemeMode = 'light' | 'dark' | 'system';

export interface Profile {
  user_id: ID;
  name: string | null;
  height_cm: number | null;
  weight_kg: number | null;
  start_weight_kg: number | null;
  goal_weight_kg: number | null;
  date_of_birth: ISODate | null;
  sex: 'male' | 'female' | 'other' | null;
  weight_unit: WeightUnit;
  distance_unit: DistanceUnit;
  length_unit: LengthUnit;
  goals: string[];
  calorie_target: number;
  protein_target: number;
  carbs_target: number;
  fat_target: number;
  fiber_target: number;
  water_target_ml: number;
  weekly_workout_target: number;
  weekly_run_km_target: number;
  step_target: number;
  default_rest_seconds: number;
  theme: ThemeMode;
  notifications_enabled: boolean;
  sound_enabled: boolean;
  show_meals_in_calendar: boolean;
  created_at?: string;
  updated_at?: string;
}

export type WorkoutStatus = 'planned' | 'in_progress' | 'completed' | 'skipped';

export interface WorkoutSet {
  id: ID;
  reps: number | null;
  weight_kg: number | null;
  duration_sec: number | null;
  distance_km: number | null;
  completed: boolean;
}

export interface WorkoutExercise {
  id: ID;
  exercise_key: string | null;
  name: string;
  muscle_group: string | null;
  rest_seconds: number | null;
  target_sets: number | null;
  target_reps: string | null;
  notes: string | null;
  skipped: boolean;
  sets: WorkoutSet[];
}

export interface Workout extends Base {
  date: ISODate;
  name: string;
  workout_type: string;
  status: WorkoutStatus;
  start_time: string | null;
  end_time: string | null;
  duration_min: number | null;
  muscle_groups: string[];
  distance_km: number | null;
  calories: number | null;
  difficulty: number | null;
  energy_level: number | null;
  mood: string | null;
  notes: string | null;
  total_volume_kg: number | null;
  program_name: string | null;
  exercises: WorkoutExercise[];
}

export interface Exercise {
  key: string; // built-in slug or 'custom:<uuid>'
  name: string;
  muscle_group: string;
  secondary_muscles: string[];
  equipment: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced' | string;
  instructions: string;
  sets: number | null;
  reps: string | null;
  rest_seconds: number | null;
  mistakes: string;
  tips: string;
  custom?: boolean;
}

export interface CustomExercise extends Base {
  name: string;
  muscle_group: string;
  secondary_muscles: string[];
  equipment: string;
  difficulty: string;
  instructions: string | null;
  sets: number | null;
  reps: string | null;
  rest_seconds: number | null;
  mistakes: string | null;
  tips: string | null;
}

export interface FavoriteExercise extends Base {
  exercise_key: string;
}

export interface ProgramExercise {
  exercise_key: string | null;
  name: string;
  muscle_group: string | null;
  sets: number;
  reps: string;
  rest_seconds: number;
}

export interface ProgramDay {
  name: string;
  focus: string;
  type: string; // workout_type or 'run' | 'rest'
  exercises: ProgramExercise[];
}

export interface WorkoutProgram extends Base {
  name: string;
  description: string | null;
  goal: string | null;
  level: string | null;
  days_per_week: number | null;
  days: ProgramDay[];
  builtin?: boolean;
}

export type CalendarEventType = 'rest' | 'note' | 'run' | 'activity' | 'other';

export interface CalendarEvent extends Base {
  date: ISODate;
  title: string;
  event_type: CalendarEventType;
  start_time: string | null;
  notes: string | null;
  completed: boolean;
}

export interface GeoPoint {
  lat: number;
  lng: number;
  t: number; // ms epoch
  acc?: number;
}

export interface Split {
  km: number;
  sec: number;
}

export interface RunningSession extends Base {
  date: ISODate;
  activity_type: 'run' | 'jog' | 'walk' | 'trail' | 'treadmill';
  status: 'planned' | 'completed' | 'skipped';
  start_time: string | null;
  end_time: string | null;
  distance_km: number | null;
  duration_sec: number | null;
  avg_pace_sec_per_km: number | null;
  calories: number | null;
  route_name: string | null;
  notes: string | null;
  gps_used: boolean;
  route: GeoPoint[] | null;
  splits: Split[] | null;
}

export interface BodyMeasurement extends Base {
  date: ISODate;
  weight_kg: number | null;
  body_fat_pct: number | null;
  waist_cm: number | null;
  chest_cm: number | null;
  arms_cm: number | null;
  thighs_cm: number | null;
  hips_cm: number | null;
  neck_cm: number | null;
  notes: string | null;
}

export interface ProgressPhoto extends Base {
  date: ISODate;
  storage_path: string;
  caption: string | null;
}

export interface DailyMetric extends Base {
  date: ISODate;
  steps: number | null;
  sleep_hours: number | null;
  notes: string | null;
}

export type MealType =
  | 'breakfast'
  | 'morning_snack'
  | 'lunch'
  | 'afternoon_snack'
  | 'dinner'
  | 'evening_snack';

export interface Macros {
  calories: number | null;
  protein_g: number | null;
  carbs_g: number | null;
  fat_g: number | null;
}

export interface NutritionEntry extends Base, Macros {
  date: ISODate;
  meal_type: MealType;
  food_name: string;
  serving_size: string | null;
  fiber_g: number | null;
  sugar_g: number | null;
  notes: string | null;
}

export interface Food extends Base, Macros {
  name: string;
  serving_size: string | null;
  fiber_g: number | null;
  sugar_g: number | null;
}

export type PlanMealType = 'breakfast' | 'lunch' | 'dinner' | 'snack';

export interface MealPlan extends Base, Macros {
  date: ISODate;
  meal_type: PlanMealType;
  title: string;
  description: string | null;
}

export interface MealTemplate extends Base, Macros {
  meal_type: PlanMealType;
  title: string;
  description: string | null;
}

export interface WaterEntry extends Base {
  date: ISODate;
  amount_ml: number;
}

export interface Habit extends Base {
  name: string;
  icon: string;
  position: number;
  active: boolean;
}

export interface HabitLog extends Base {
  habit_id: ID;
  date: ISODate;
}

export interface PersonalRecord extends Base {
  title: string;
  category: string;
  value: number;
  unit: string | null;
  date: ISODate;
  exercise_name: string | null;
  notes: string | null;
}

/** Tables handled by the generic synced store (workouts use an RPC). */
export interface TableRows {
  custom_exercises: CustomExercise;
  favorite_exercises: FavoriteExercise;
  workout_programs: WorkoutProgram;
  calendar_events: CalendarEvent;
  running_sessions: RunningSession;
  body_measurements: BodyMeasurement;
  progress_photos: ProgressPhoto;
  daily_metrics: DailyMetric;
  nutrition_entries: NutritionEntry;
  foods: Food;
  meal_plans: MealPlan;
  meal_templates: MealTemplate;
  water_entries: WaterEntry;
  habits: Habit;
  habit_logs: HabitLog;
  personal_records: PersonalRecord;
}
export type TableName = keyof TableRows;
