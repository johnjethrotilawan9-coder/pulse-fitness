import { useEffect, useState } from 'react';
import { useCountdown } from '../hooks/useTimer';
import { playChime, primeAudio, notify } from '../utils/sound';
import { fmtDuration } from '../utils/format';
import { Button } from './ui/Button';
import { Icon } from './Icon';

export const REST_PRESETS = [30, 45, 60, 90, 120, 180];

interface Props {
  /** Change `n` to (re)start the timer for `sec` seconds. */
  trigger?: { sec: number; n: number } | null;
  sound?: boolean;
  compact?: boolean;
  onFinish?: () => void;
}

export function RestTimer({ trigger, sound = true, compact = false, onFinish }: Props) {
  const [custom, setCustom] = useState('');
  const [customErr, setCustomErr] = useState<string | null>(null);
  const cd = useCountdown(() => {
    if (sound) playChime();
    notify('Rest is over', 'Time for your next set 💪');
    onFinish?.();
  });

  useEffect(() => {
    if (trigger && trigger.sec > 0) cd.start(trigger.sec * 1000);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [trigger?.n]);

  const start = (sec: number) => {
    primeAudio();
    cd.start(sec * 1000);
  };
  const active = cd.running || cd.paused;
  const pct = cd.total > 0 ? cd.remaining / cd.total : 0;

  return (
    <div className={`rest-overlay ${cd.finished ? 'done' : ''}`} style={!active && !cd.finished ? { background: 'var(--surface-2)', color: 'var(--text)' } : undefined} aria-live="polite">
      <div className="row" style={{ gap: 6, fontWeight: 700, fontSize: 13, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
        <Icon name="timer" size={16} /> {cd.finished ? 'Rest finished — go!' : active ? (cd.paused ? 'Rest paused' : 'Resting') : 'Rest timer'}
      </div>
      {(active || cd.finished) && (
        <>
          <div className="rest-time" role="timer" aria-label={`${Math.ceil(cd.remaining / 1000)} seconds left`}>
            {fmtDuration(Math.ceil(cd.remaining / 1000))}
          </div>
          {!cd.finished && (
            <div className="pbar" style={{ width: '100%', maxWidth: 320 }}>
              <div className="pbar-fill tone-info" style={{ width: `${pct * 100}%`, transition: 'width 0.2s linear' }} />
            </div>
          )}
        </>
      )}
      <div className="timer-controls">
        {cd.running && (
          <>
            <Button size="sm" icon="pause" onClick={cd.pause}>
              Pause
            </Button>
            <Button size="sm" icon="plus" onClick={() => cd.addTime(15000)}>
              15s
            </Button>
          </>
        )}
        {cd.paused && (
          <Button size="sm" icon="play" variant="primary" onClick={cd.resume}>
            Resume
          </Button>
        )}
        {(active || cd.finished) && (
          <Button size="sm" icon="rotate" onClick={cd.reset}>
            {cd.finished ? 'Dismiss' : 'Reset'}
          </Button>
        )}
      </div>
      {(!active || !compact) && (
        <div className="preset-grid" style={{ width: '100%', maxWidth: 360 }}>
          {REST_PRESETS.map((s) => (
            <Button key={s} size="sm" onClick={() => start(s)} aria-label={`Start ${s} second rest`}>
              {s < 120 ? `${s}s` : `${s / 60} min`}
            </Button>
          ))}
        </div>
      )}
      {!compact && (
        <form
          className="row"
          style={{ width: '100%', maxWidth: 360 }}
          onSubmit={(e) => {
            e.preventDefault();
            const m = custom.trim().match(/^(\d{1,3})(?::(\d{1,2}))?$/);
            if (!m) return setCustomErr('Use seconds (e.g. 75) or m:ss (e.g. 1:15).');
            const sec = m[2] !== undefined ? Number(m[1]) * 60 + Number(m[2]) : Number(m[1]);
            if (sec <= 0 || sec > 3600) return setCustomErr('Choose between 1 second and 60 minutes.');
            setCustomErr(null);
            start(sec);
          }}
        >
          <input className="input grow" value={custom} onChange={(e) => setCustom(e.target.value)} placeholder="Custom (sec or m:ss)" aria-label="Custom rest time" inputMode="numeric" style={{ height: 38 }} />
          <Button size="sm" type="submit" variant="primary">
            Start
          </Button>
        </form>
      )}
      {customErr && <p className="field-msg">{customErr}</p>}
    </div>
  );
}
