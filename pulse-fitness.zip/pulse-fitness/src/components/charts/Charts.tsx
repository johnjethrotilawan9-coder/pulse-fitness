import { useEffect, useId, useRef, useState, type ReactNode } from 'react';
import { addDays, fmtDate, parseISO, startOfWeek, todayISO } from '../../utils/date';
import { fmtNum } from '../../utils/format';

/** Width of a container, so SVG charts render at real pixel size (crisp text on any screen). */
function useWidth(fallback = 600) {
  const ref = useRef<HTMLDivElement>(null);
  const [w, setW] = useState(fallback);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const update = () => setW(Math.max(120, Math.round(el.clientWidth)));
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return [ref, w] as const;
}

// ------------------------------------------------------------------ Ring
export function Ring({ value, max, size = 120, stroke = 11, tone = 'accent', children, label }: { value: number; max: number; size?: number; stroke?: number; tone?: string; children?: ReactNode; label: string }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const pct = max > 0 ? Math.min(1, Math.max(0, value / max)) : 0;
  return (
    <div className="ring" style={{ width: size, height: size }} role="img" aria-label={`${label}: ${Math.round(pct * 100)}%`}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--track)" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          className={`ring-fill stroke-${tone}`}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - pct)}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
        />
      </svg>
      <div className="ring-center">{children}</div>
    </div>
  );
}

// ------------------------------------------------------------------ Line
export interface LinePoint {
  label: string;
  value: number | null;
}

export function LineChart({ data, height = 180, unit = '', goal, digits = 1, tone = 'accent', ariaLabel }: { data: LinePoint[]; height?: number; unit?: string; goal?: number | null; digits?: number; tone?: string; ariaLabel: string }) {
  const gid = useId().replace(/:/g, '');
  const [ref, W] = useWidth();
  const pts = data.filter((d) => d.value !== null) as { label: string; value: number }[];
  if (pts.length === 0) return <div ref={ref} className="chart-wrap"><p className="muted small chart-empty">No data yet.</p></div>;
  const H = height, padL = 44, padR = 14, padT = 14, padB = 26;
  const vals = pts.map((p) => p.value).concat(goal != null ? [goal] : []);
  let min = Math.min(...vals), max = Math.max(...vals);
  if (min === max) {
    min -= 1;
    max += 1;
  }
  const span = max - min;
  min -= span * 0.1;
  max += span * 0.1;
  const x = (i: number) => padL + (pts.length === 1 ? (W - padL - padR) / 2 : (i / (pts.length - 1)) * (W - padL - padR));
  const y = (v: number) => padT + (1 - (v - min) / (max - min)) * (H - padT - padB);
  const path = pts.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p.value).toFixed(1)}`).join(' ');
  const area = `${path} L${x(pts.length - 1).toFixed(1)},${H - padB} L${x(0).toFixed(1)},${H - padB} Z`;
  const ticks = [max - (max - min) * 0.1, (max + min) / 2, min + (max - min) * 0.1];
  const labelEvery = Math.max(1, Math.ceil(pts.length / Math.max(2, Math.floor(W / 80))));
  return (
    <div ref={ref} className="chart-wrap">
    <svg className={`chart tone-${tone}`} width={W} height={H} viewBox={`0 0 ${W} ${H}`} role="img" aria-label={ariaLabel}>
      <defs>
        <linearGradient id={`g${gid}`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="currentColor" stopOpacity="0.22" />
          <stop offset="100%" stopColor="currentColor" stopOpacity="0" />
        </linearGradient>
      </defs>
      {ticks.map((t, i) => (
        <g key={i}>
          <line x1={padL} x2={W - padR} y1={y(t)} y2={y(t)} className="grid" />
          <text x={padL - 6} y={y(t) + 4} textAnchor="end" className="axis">
            {fmtNum(t, digits)}
          </text>
        </g>
      ))}
      {goal != null && (
        <g>
          <line x1={padL} x2={W - padR} y1={y(goal)} y2={y(goal)} className="goal-line" />
          <text x={W - padR} y={y(goal) - 5} textAnchor="end" className="axis goal-text">
            goal {fmtNum(goal, digits)}
          </text>
        </g>
      )}
      <path d={area} fill={`url(#g${gid})`} />
      <path d={path} fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinejoin="round" />
      {pts.map((p, i) => (
        <g key={i}>
          <circle cx={x(i)} cy={y(p.value)} r={pts.length > 40 ? 0 : 3.5} fill="var(--surface)" stroke="currentColor" strokeWidth={2}>
            <title>{`${p.label}: ${fmtNum(p.value, digits)}${unit ? ' ' + unit : ''}`}</title>
          </circle>
          {i % labelEvery === 0 && (
            <text x={x(i)} y={H - 8} textAnchor="middle" className="axis">
              {p.label}
            </text>
          )}
        </g>
      ))}
    </svg>
    </div>
  );
}

// ------------------------------------------------------------------ Bars
export function BarChart({ data, height = 170, unit = '', target, digits = 0, tone = 'accent', ariaLabel, highlightLast = true }: { data: { label: string; value: number }[]; height?: number; unit?: string; target?: number | null; digits?: number; tone?: string; ariaLabel: string; highlightLast?: boolean }) {
  const [ref, W] = useWidth();
  if (!data.length) return <div ref={ref} className="chart-wrap"><p className="muted small chart-empty">No data yet.</p></div>;
  const H = height, padT = 18, padB = 26, padX = 8;
  const max = Math.max(1, ...data.map((d) => d.value), target ?? 0) * 1.1;
  const bw = (W - padX * 2) / data.length;
  const y = (v: number) => padT + (1 - v / max) * (H - padT - padB);
  return (
    <div ref={ref} className="chart-wrap">
    <svg className={`chart tone-${tone}`} width={W} height={H} viewBox={`0 0 ${W} ${H}`} role="img" aria-label={ariaLabel}>
      <line x1={0} x2={W} y1={H - padB} y2={H - padB} className="grid" />
      {target != null && target > 0 && <line x1={0} x2={W} y1={y(target)} y2={y(target)} className="goal-line" />}
      {data.map((d, i) => {
        const bx = padX + i * bw + bw * 0.18;
        const w = bw * 0.64;
        const h = Math.max(d.value > 0 ? 3 : 0, H - padB - y(d.value));
        const last = highlightLast && i === data.length - 1;
        return (
          <g key={i}>
            <rect x={bx} y={H - padB - h} width={w} height={h} rx={Math.min(6, w / 3)} fill="currentColor" opacity={last ? 1 : 0.45}>
              <title>{`${d.label}: ${fmtNum(d.value, digits)}${unit ? ' ' + unit : ''}`}</title>
            </rect>
            {d.value > 0 && bw > 26 && (
              <text x={bx + w / 2} y={H - padB - h - 5} textAnchor="middle" className="axis bar-val">
                {fmtNum(d.value, digits)}
              </text>
            )}
            {i % Math.max(1, Math.ceil(40 / bw)) === 0 && (
              <text x={bx + w / 2} y={H - 8} textAnchor="middle" className="axis">
                {d.label}
              </text>
            )}
          </g>
        );
      })}
    </svg>
    </div>
  );
}

// ------------------------------------------------------------------ Heatmap
/** Activity heatmap: columns = weeks (Mon–Sun rows). values: date → level 0..4 */
export function Heatmap({ values, weeks = 17, end = todayISO(), ariaLabel, describe }: { values: Record<string, number>; weeks?: number; end?: string; ariaLabel: string; describe?: (date: string, v: number) => string }) {
  const start = addDays(startOfWeek(end), -7 * (weeks - 1));
  const max = Math.max(1, ...Object.values(values));
  const cols: string[][] = [];
  for (let w = 0; w < weeks; w++) cols.push(Array.from({ length: 7 }, (_, d) => addDays(start, w * 7 + d)));
  return (
    <div className="heatmap" role="img" aria-label={ariaLabel}>
      <div className="heatmap-days" aria-hidden>
        {['M', '', 'W', '', 'F', '', 'S'].map((d, i) => (
          <span key={i}>{d}</span>
        ))}
      </div>
      <div className="heatmap-grid" style={{ gridTemplateColumns: `repeat(${weeks}, 1fr)` }}>
        {cols.map((col, ci) => (
          <div key={ci} className="heatmap-col">
            {col.map((d) => {
              const v = values[d] ?? 0;
              const lvl = v <= 0 ? 0 : Math.min(4, Math.ceil((v / max) * 4));
              const future = d > end;
              return <span key={d} className={`hm hm-${future ? 'x' : lvl}`} title={future ? '' : describe ? describe(d, v) : `${fmtDate(d)}: ${v}`} />;
            })}
          </div>
        ))}
      </div>
      <div className="heatmap-months" aria-hidden style={{ gridTemplateColumns: `repeat(${weeks}, 1fr)` }}>
        {cols.map((col, i) => {
          const d = parseISO(col[0]);
          const show = i === 0 || d.getDate() <= 7;
          return <span key={i}>{show ? d.toLocaleDateString(undefined, { month: 'short' }) : ''}</span>;
        })}
      </div>
    </div>
  );
}

/** Horizontal labelled bars (e.g. muscle group split). */
export function HBars({ data, unit = '' }: { data: { label: string; value: number }[]; unit?: string }) {
  if (!data.length) return <p className="muted small">No data yet.</p>;
  const max = Math.max(...data.map((d) => d.value), 1);
  return (
    <ul className="hbars">
      {data.map((d) => (
        <li key={d.label}>
          <span className="hbars-label">{d.label}</span>
          <span className="hbars-track">
            <span className="hbars-fill" style={{ width: `${(d.value / max) * 100}%` }} />
          </span>
          <span className="hbars-val">
            {fmtNum(d.value, 1)}
            {unit}
          </span>
        </li>
      ))}
    </ul>
  );
}
