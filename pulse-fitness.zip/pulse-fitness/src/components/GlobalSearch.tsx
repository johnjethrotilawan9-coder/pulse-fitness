import { useEffect, useMemo, useState } from 'react';
import { Modal } from './ui/Modal';
import { SearchBox } from './ui/Misc';
import { Icon, type IconName } from './Icon';
import { useData } from '../hooks/useData';
import { useExercises } from '../hooks/useExercises';
import { useRouter } from '../router';
import { BUILTIN_PROGRAMS } from '../data/programs';
import { fmtDate } from '../utils/date';

interface Hit {
  id: string;
  title: string;
  sub: string;
  to: string;
  icon: IconName;
}

export function GlobalSearch({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [q, setQ] = useState('');
  const { workouts, tables } = useData();
  const { all: exercises } = useExercises();
  const { navigate } = useRouter();

  useEffect(() => {
    if (!open) setQ('');
  }, [open]);

  // Ctrl/⌘ + K opens search on desktop
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        document.dispatchEvent(new CustomEvent('pulse:search'));
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const groups = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (term.length < 2) return [];
    const has = (...s: (string | null | undefined)[]) => s.some((x) => x && x.toLowerCase().includes(term));
    const limit = <T,>(a: T[]) => a.slice(0, 8);
    const g: { title: string; hits: Hit[] }[] = [
      {
        title: 'Workouts',
        hits: limit(
          [...workouts]
            .sort((a, b) => b.date.localeCompare(a.date))
            .filter((w) => has(w.name, w.notes, w.workout_type, ...w.muscle_groups, ...w.exercises.map((e) => e.name)))
            .map((w) => ({ id: w.id, title: w.name, sub: `${fmtDate(w.date, { month: 'short', day: 'numeric', year: 'numeric' })} · ${w.status.replace('_', ' ')}`, to: `/workouts/${w.id}`, icon: 'dumbbell' as IconName })),
        ),
      },
      {
        title: 'Exercises',
        hits: limit(exercises.filter((e) => has(e.name, e.muscle_group, e.equipment)).map((e) => ({ id: e.key, title: e.name, sub: `${e.muscle_group} · ${e.equipment}`, to: `/exercises?ex=${encodeURIComponent(e.key)}`, icon: 'book' as IconName }))),
      },
      {
        title: 'Runs',
        hits: limit(
          [...tables.running_sessions]
            .sort((a, b) => b.date.localeCompare(a.date))
            .filter((r) => has(r.route_name, r.notes, r.activity_type))
            .map((r) => ({ id: r.id, title: r.route_name || `${r.activity_type} ${fmtDate(r.date)}`, sub: `${fmtDate(r.date)} · ${r.distance_km ?? 0} km`, to: `/run?id=${r.id}`, icon: 'run' as IconName })),
        ),
      },
      {
        title: 'Meals',
        hits: limit([
          ...tables.nutrition_entries.filter((n) => has(n.food_name, n.notes)).map((n) => ({ id: n.id, title: n.food_name, sub: `Logged ${fmtDate(n.date)} · ${n.meal_type.replace('_', ' ')}`, to: `/nutrition?date=${n.date}`, icon: 'utensils' as IconName })),
          ...tables.meal_plans.filter((m) => has(m.title, m.description)).map((m) => ({ id: m.id, title: m.title, sub: `Planned ${fmtDate(m.date)} · ${m.meal_type}`, to: `/meals?date=${m.date}`, icon: 'list' as IconName })),
        ]),
      },
      {
        title: 'Programs',
        hits: limit([...tables.workout_programs, ...BUILTIN_PROGRAMS].filter((p) => has(p.name, p.description, p.goal)).map((p) => ({ id: p.id, title: p.name, sub: `${p.level ?? ''} · ${p.goal ?? ''}`, to: `/programs?id=${encodeURIComponent(p.id)}`, icon: 'layers' as IconName }))),
      },
      {
        title: 'Calendar',
        hits: limit(tables.calendar_events.filter((e) => has(e.title, e.notes)).map((e) => ({ id: e.id, title: e.title, sub: `${fmtDate(e.date)} · ${e.event_type}`, to: `/calendar?date=${e.date}`, icon: 'calendar' as IconName }))),
      },
    ];
    return g.filter((x) => x.hits.length);
  }, [q, workouts, tables, exercises]);

  return (
    <Modal open={open} title="Search" onClose={onClose} size="md">
      <SearchBox value={q} onChange={setQ} placeholder="Exercises, workouts, runs, meals…" />
      {q.trim().length < 2 ? (
        <p className="muted small">Type at least 2 characters.</p>
      ) : groups.length === 0 ? (
        <p className="muted small">No results for “{q}”.</p>
      ) : (
        <div className="search-results">
          {groups.map((g) => (
            <div key={g.title} className="search-group">
              <h3>{g.title}</h3>
              <div className="list">
                {g.hits.map((h) => (
                  <button
                    key={h.id}
                    className="list-item"
                    style={{ paddingLeft: 0, paddingRight: 0 }}
                    onClick={() => {
                      onClose();
                      navigate(h.to);
                    }}
                  >
                    <span className="list-icon tone-accent">
                      <Icon name={h.icon} size={18} />
                    </span>
                    <span className="grow">
                      <span className="list-title" style={{ display: 'block' }}>
                        {h.title}
                      </span>
                      <span className="list-sub" style={{ display: 'block' }}>
                        {h.sub}
                      </span>
                    </span>
                    <Icon name="right" size={18} className="faint" />
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </Modal>
  );
}
