import { useId, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from 'react';

interface Wrap {
  label: string;
  error?: string;
  hint?: ReactNode;
  suffix?: string;
  hideLabel?: boolean;
  className?: string;
}

function Frame({ id, label, error, hint, hideLabel, className = '', children }: Wrap & { id: string; children: ReactNode }) {
  return (
    <div className={`field ${error ? 'field-error' : ''} ${className}`}>
      <label htmlFor={id} className={hideLabel ? 'sr-only' : 'field-label'}>
        {label}
      </label>
      {children}
      {error ? (
        <p className="field-msg" id={`${id}-err`} role="alert">
          {error}
        </p>
      ) : hint ? (
        <p className="field-hint">{hint}</p>
      ) : null}
    </div>
  );
}

export function Input({ label, error, hint, suffix, hideLabel, className, ...rest }: Wrap & InputHTMLAttributes<HTMLInputElement>) {
  const id = useId();
  return (
    <Frame id={id} label={label} error={error} hint={hint} hideLabel={hideLabel} className={className}>
      <div className="input-wrap">
        <input id={id} className="input" aria-invalid={!!error || undefined} aria-describedby={error ? `${id}-err` : undefined} {...rest} />
        {suffix && <span className="input-suffix">{suffix}</span>}
      </div>
    </Frame>
  );
}

/** Numeric input that keeps the raw string (so validation can report bad text). */
export function NumberInput(props: Wrap & Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> & { decimal?: boolean }) {
  const { decimal = true, ...rest } = props;
  return <Input type="text" inputMode={decimal ? 'decimal' : 'numeric'} autoComplete="off" {...rest} />;
}

export function Select({ label, error, hint, hideLabel, className, children, ...rest }: Wrap & SelectHTMLAttributes<HTMLSelectElement>) {
  const id = useId();
  return (
    <Frame id={id} label={label} error={error} hint={hint} hideLabel={hideLabel} className={className}>
      <select id={id} className="input select" aria-invalid={!!error || undefined} {...rest}>
        {children}
      </select>
    </Frame>
  );
}

export function Textarea({ label, error, hint, hideLabel, className, ...rest }: Wrap & TextareaHTMLAttributes<HTMLTextAreaElement>) {
  const id = useId();
  return (
    <Frame id={id} label={label} error={error} hint={hint} hideLabel={hideLabel} className={className}>
      <textarea id={id} className="input textarea" rows={3} aria-invalid={!!error || undefined} {...rest} />
    </Frame>
  );
}

export function Toggle({ label, checked, onChange, description }: { label: string; checked: boolean; onChange: (v: boolean) => void; description?: string }) {
  const id = useId();
  return (
    <div className="toggle-row">
      <div>
        <label htmlFor={id} className="toggle-label">
          {label}
        </label>
        {description && <p className="muted small">{description}</p>}
      </div>
      <button id={id} type="button" role="switch" aria-checked={checked} className={`switch ${checked ? 'on' : ''}`} onClick={() => onChange(!checked)}>
        <span className="switch-knob" />
      </button>
    </div>
  );
}

/** Pill-style single choice. */
export function Segmented<T extends string>({ value, options, onChange, label, size = 'md' }: { value: T; options: { value: T; label: string }[]; onChange: (v: T) => void; label: string; size?: 'sm' | 'md' }) {
  return (
    <div className={`segmented segmented-${size}`} role="radiogroup" aria-label={label}>
      {options.map((o) => (
        <button key={o.value} type="button" role="radio" aria-checked={value === o.value} className={value === o.value ? 'active' : ''} onClick={() => onChange(o.value)}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

/** Multi-select chips. */
export function ChipSelect({ values, options, onChange, label }: { values: string[]; options: string[]; onChange: (v: string[]) => void; label: string }) {
  return (
    <fieldset className="field">
      <legend className="field-label">{label}</legend>
      <div className="chips">
        {options.map((o) => {
          const on = values.includes(o);
          return (
            <button key={o} type="button" className={`chip ${on ? 'chip-on' : ''}`} aria-pressed={on} onClick={() => onChange(on ? values.filter((v) => v !== o) : [...values, o])}>
              {on && <span aria-hidden>✓ </span>}
              {o}
            </button>
          );
        })}
      </div>
    </fieldset>
  );
}

/** 1–N rating buttons. */
export function Rating({ label, value, max, onChange, low, high }: { label: string; value: number | null; max: number; onChange: (v: number | null) => void; low?: string; high?: string }) {
  return (
    <fieldset className="field">
      <legend className="field-label">{label}</legend>
      <div className="rating" role="radiogroup" aria-label={label}>
        {Array.from({ length: max }, (_, i) => i + 1).map((n) => (
          <button key={n} type="button" role="radio" aria-checked={value === n} className={value === n ? 'active' : ''} onClick={() => onChange(value === n ? null : n)}>
            {n}
          </button>
        ))}
      </div>
      {(low || high) && (
        <div className="rating-legend">
          <span>{low}</span>
          <span>{high}</span>
        </div>
      )}
    </fieldset>
  );
}
