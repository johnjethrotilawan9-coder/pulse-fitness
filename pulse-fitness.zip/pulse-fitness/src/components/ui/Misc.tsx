import type { ReactNode } from 'react';
import { Icon, type IconName } from '../Icon';
import type { WorkoutStatus } from '../../types';

export function Card({ title, action, children, className = '', icon, padded = true }: { title?: ReactNode; action?: ReactNode; children: ReactNode; className?: string; icon?: IconName; padded?: boolean }) {
  return (
    <section className={`card ${padded ? '' : 'card-flush'} ${className}`}>
      {(title || action) && (
        <header className="card-head">
          {title && (
            <h2 className="card-title">
              {icon && <Icon name={icon} size={18} />}
              {title}
            </h2>
          )}
          {action && <div className="card-action">{action}</div>}
        </header>
      )}
      {children}
    </section>
  );
}

export function PageHeader({ title, subtitle, actions, back }: { title: string; subtitle?: ReactNode; actions?: ReactNode; back?: ReactNode }) {
  return (
    <header className="page-head">
      <div className="page-head-main">
        {back}
        <div>
          <h1>{title}</h1>
          {subtitle && <p className="page-sub">{subtitle}</p>}
        </div>
      </div>
      {actions && <div className="page-actions">{actions}</div>}
    </header>
  );
}

export function EmptyState({ icon = 'sparkle', title, message, action }: { icon?: IconName; title: string; message?: ReactNode; action?: ReactNode }) {
  return (
    <div className="empty">
      <div className="empty-icon">
        <Icon name={icon} size={26} />
      </div>
      <h3>{title}</h3>
      {message && <p className="muted">{message}</p>}
      {action && <div className="empty-action">{action}</div>}
    </div>
  );
}

export function Spinner({ label = 'Loading' }: { label?: string }) {
  return (
    <div className="center-spinner" role="status">
      <span className="spinner spinner-lg" aria-hidden />
      <span className="sr-only">{label}</span>
    </div>
  );
}

export function Badge({ children, tone = 'neutral', icon }: { children: ReactNode; tone?: 'neutral' | 'accent' | 'success' | 'warning' | 'danger' | 'info' | 'violet'; icon?: IconName }) {
  return (
    <span className={`badge badge-${tone}`}>
      {icon && <Icon name={icon} size={12} strokeWidth={2.5} />}
      {children}
    </span>
  );
}

const STATUS: Record<WorkoutStatus, { label: string; tone: 'info' | 'accent' | 'success' | 'neutral'; icon: IconName }> = {
  planned: { label: 'Planned', tone: 'info', icon: 'clock' },
  in_progress: { label: 'In progress', tone: 'accent', icon: 'play' },
  completed: { label: 'Completed', tone: 'success', icon: 'check' },
  skipped: { label: 'Skipped', tone: 'neutral', icon: 'skip' },
};
export function StatusBadge({ status }: { status: WorkoutStatus }) {
  const s = STATUS[status];
  return (
    <Badge tone={s.tone} icon={s.icon}>
      {s.label}
    </Badge>
  );
}

export function ProgressBar({ value, max, tone = 'accent', label }: { value: number; max: number; tone?: string; label: string }) {
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0;
  return (
    <div className="pbar" role="progressbar" aria-label={label} aria-valuemin={0} aria-valuemax={max} aria-valuenow={Math.round(value)}>
      <div className={`pbar-fill tone-${tone}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

export function Stat({ label, value, unit, icon, sub, tone }: { label: string; value: ReactNode; unit?: string; icon?: IconName; sub?: ReactNode; tone?: string }) {
  return (
    <div className="stat">
      <div className="stat-label">
        {icon && <span className={`stat-icon tone-${tone ?? 'accent'}`}><Icon name={icon} size={15} /></span>}
        {label}
      </div>
      <div className="stat-value">
        {value}
        {unit && <span className="stat-unit">{unit}</span>}
      </div>
      {sub && <div className="stat-sub">{sub}</div>}
    </div>
  );
}

export function Tabs<T extends string>({ value, tabs, onChange, label }: { value: T; tabs: { value: T; label: string; icon?: IconName }[]; onChange: (v: T) => void; label: string }) {
  return (
    <div className="tabs" role="tablist" aria-label={label}>
      {tabs.map((t) => (
        <button key={t.value} role="tab" aria-selected={value === t.value} className={value === t.value ? 'active' : ''} onClick={() => onChange(t.value)} type="button">
          {t.icon && <Icon name={t.icon} size={16} />}
          {t.label}
        </button>
      ))}
    </div>
  );
}

export function SearchBox({ value, onChange, placeholder = 'Search', label = 'Search' }: { value: string; onChange: (v: string) => void; placeholder?: string; label?: string }) {
  return (
    <div className="searchbox">
      <Icon name="search" size={18} />
      <input type="search" value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} aria-label={label} className="searchbox-input" />
      {value && (
        <button type="button" className="searchbox-clear" aria-label="Clear search" onClick={() => onChange('')}>
          <Icon name="x" size={16} />
        </button>
      )}
    </div>
  );
}
