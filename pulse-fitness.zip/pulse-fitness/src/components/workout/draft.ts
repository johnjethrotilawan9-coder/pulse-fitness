import type { WorkoutExercise, WorkoutSet } from '../../types';
import { parseOptionalNumber } from '../../utils/validate';
import { newSet } from '../../utils/workout';

/** Editable form representation of sets (weights in the user's unit, as text). */
export interface DraftSet {
  id: string;
  reps: string;
  weight: string;
  completed: boolean;
  duration_sec: number | null;
  distance_km: number | null;
}
export interface DraftExercise extends Omit<WorkoutExercise, 'sets'> {
  sets: DraftSet[];
}

type Conv = { weight: (kg: number | null | undefined) => number | null; fromWeight: (v: number | null) => number | null };

export function toDraft(ex: WorkoutExercise[], u: Conv): DraftExercise[] {
  return ex.map((e) => ({
    ...e,
    sets: e.sets.map((s) => ({
      id: s.id,
      reps: s.reps == null ? '' : String(s.reps),
      weight: s.weight_kg == null ? '' : String(u.weight(s.weight_kg)),
      completed: s.completed,
      duration_sec: s.duration_sec,
      distance_km: s.distance_km,
    })),
  }));
}

export function fromDraft(ex: DraftExercise[], u: Conv): WorkoutExercise[] {
  return ex.map((e) => ({
    ...e,
    sets: e.sets.map(
      (s): WorkoutSet => ({
        id: s.id,
        reps: (parseOptionalNumber(s.reps) ?? null) as number | null,
        weight_kg: u.fromWeight((parseOptionalNumber(s.weight) ?? null) as number | null),
        completed: s.completed,
        duration_sec: s.duration_sec,
        distance_km: s.distance_km,
      }),
    ),
  }));
}

export function draftSetFrom(prev?: DraftSet): DraftSet {
  const s = newSet();
  return { id: s.id, reps: prev?.reps ?? '', weight: prev?.weight ?? '', completed: false, duration_sec: null, distance_km: null };
}

/** Validation errors keyed by set id. */
export function validateDraft(ex: DraftExercise[]): Record<string, string> {
  const errs: Record<string, string> = {};
  for (const e of ex) {
    if (!e.name.trim()) errs[e.id] = 'Exercise needs a name.';
    for (const s of e.sets) {
      const r = parseOptionalNumber(s.reps);
      const w = parseOptionalNumber(s.weight);
      if (r === undefined || (r !== null && (r < 0 || !Number.isInteger(r) || r > 10000))) errs[s.id] = 'Reps must be a whole number.';
      else if (w === undefined || (w !== null && (w < 0 || w > 2000))) errs[s.id] = 'Weight must be a positive number.';
    }
  }
  return errs;
}
