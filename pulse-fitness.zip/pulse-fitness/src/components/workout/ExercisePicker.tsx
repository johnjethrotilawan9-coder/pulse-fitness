import { useMemo, useState } from 'react';
import { Modal } from '../ui/Modal';
import { SearchBox } from '../ui/Misc';
import { Button } from '../ui/Button';
import { Icon } from '../Icon';
import { useExercises } from '../../hooks/useExercises';
import { MUSCLE_GROUPS } from '../../data/exercises';
import type { Exercise } from '../../types';

export function ExercisePicker({ open, onClose, onPick, multi = true }: { open: boolean; onClose: () => void; onPick: (list: Exercise[]) => void; multi?: boolean }) {
  const { all, favorites } = useExercises();
  const [q, setQ] = useState('');
  const [group, setGroup] = useState<string>('All');
  const [picked, setPicked] = useState<string[]>([]);

  const list = useMemo(() => {
    const term = q.trim().toLowerCase();
    return all
      .filter((e) => (group === 'All' ? true : group === 'Favorites' ? favorites.has(e.key) : e.muscle_group === group))
      .filter((e) => !term || e.name.toLowerCase().includes(term) || e.equipment.toLowerCase().includes(term) || e.muscle_group.toLowerCase().includes(term))
      .slice(0, 200);
  }, [all, q, group, favorites]);

  const custom = q.trim();
  const close = () => {
    setPicked([]);
    setQ('');
    onClose();
  };
  const done = (items: Exercise[]) => {
    onPick(items);
    close();
  };

  return (
    <Modal
      open={open}
      title="Add exercises"
      onClose={close}
      size="md"
      footer={
        multi ? (
          <Button variant="primary" disabled={!picked.length} onClick={() => done(picked.map((k) => all.find((e) => e.key === k)!).filter(Boolean))}>
            Add {picked.length || ''} exercise{picked.length === 1 ? '' : 's'}
          </Button>
        ) : undefined
      }
    >
      <SearchBox value={q} onChange={setQ} placeholder="Search exercises" />
      <div className="chip-scroll" style={{ margin: 0, padding: 0 }}>
        {['All', 'Favorites', ...MUSCLE_GROUPS].map((g) => (
          <button key={g} type="button" className={`chip ${group === g ? 'chip-on' : ''}`} onClick={() => setGroup(g)} aria-pressed={group === g}>
            {g}
          </button>
        ))}
      </div>
      {custom && !all.some((e) => e.name.toLowerCase() === custom.toLowerCase()) && (
        <Button
          icon="plus"
          onClick={() =>
            done([{ key: '', name: custom, muscle_group: group !== 'All' && group !== 'Favorites' ? group : '', secondary_muscles: [], equipment: '', difficulty: '', instructions: '', sets: 3, reps: '10', rest_seconds: 90, mistakes: '', tips: '' }])
          }
        >
          Add “{custom}” as a one-off exercise
        </Button>
      )}
      <div className="list">
        {list.map((e) => {
          const on = picked.includes(e.key);
          return (
            <button
              key={e.key}
              type="button"
              className="list-item"
              style={{ paddingLeft: 0, paddingRight: 0 }}
              aria-pressed={multi ? on : undefined}
              onClick={() => (multi ? setPicked((p) => (on ? p.filter((k) => k !== e.key) : [...p, e.key])) : done([e]))}
            >
              <span className={`list-icon ${on ? 'tone-success' : 'tone-accent'}`}>{on ? <Icon name="check" size={18} /> : <Icon name="dumbbell" size={18} />}</span>
              <span className="grow">
                <span className="list-title" style={{ display: 'block' }}>
                  {e.name} {favorites.has(e.key) && <span aria-label="favorite">★</span>}
                </span>
                <span className="list-sub" style={{ display: 'block' }}>
                  {e.muscle_group} · {e.equipment}
                  {e.custom ? ' · custom' : ''}
                </span>
              </span>
            </button>
          );
        })}
        {!list.length && <p className="muted small">No exercises match.</p>}
      </div>
    </Modal>
  );
}
