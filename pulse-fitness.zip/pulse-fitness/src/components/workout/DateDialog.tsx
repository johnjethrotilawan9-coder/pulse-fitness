import { useState } from 'react';
import { Modal } from '../ui/Modal';
import { Input, Toggle } from '../ui/Field';
import { Button } from '../ui/Button';
import { isValidISO, todayISO } from '../../utils/date';

/** Ask for a date (used for reschedule, duplicate, move). */
export function DateDialog({
  open,
  title,
  initial,
  confirmLabel,
  onClose,
  onConfirm,
  withKeepResults,
  message,
}: {
  open: boolean;
  title: string;
  initial?: string;
  confirmLabel: string;
  onClose: () => void;
  onConfirm: (date: string, keepResults: boolean) => Promise<unknown> | void;
  withKeepResults?: boolean;
  message?: string;
}) {
  const [date, setDate] = useState(initial ?? todayISO());
  const [keep, setKeep] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | undefined>();
  const [lastOpen, setLastOpen] = useState(false);
  if (open !== lastOpen) {
    setLastOpen(open);
    if (open) {
      setDate(initial ?? todayISO());
      setErr(undefined);
      setKeep(false);
    }
  }
  return (
    <Modal
      open={open}
      title={title}
      size="sm"
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button
            variant="primary"
            loading={busy}
            onClick={async () => {
              if (!isValidISO(date)) return setErr('Please choose a valid date.');
              setBusy(true);
              try {
                await onConfirm(date, keep);
              } finally {
                setBusy(false);
              }
            }}
          >
            {confirmLabel}
          </Button>
        </>
      }
    >
      {message && <p className="muted">{message}</p>}
      <Input label="Date" type="date" value={date} onChange={(e) => setDate(e.target.value)} error={err} />
      {withKeepResults && <Toggle label="Copy logged results" description="Off = copy exercises & targets as a new planned workout." checked={keep} onChange={setKeep} />}
    </Modal>
  );
}
