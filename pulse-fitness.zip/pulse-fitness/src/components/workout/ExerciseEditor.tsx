import { Icon } from '../Icon';
import { IconButton, Button } from '../ui/Button';
import { useUnits } from '../../hooks/useUnits';
import { draftSetFrom, type DraftExercise } from './draft';

interface Props {
  ex: DraftExercise;
  index: number;
  count: number;
  errors: Record<string, string>;
  onChange: (ex: DraftExercise) => void;
  onRemove: () => void;
  onMove: (dir: -1 | 1) => void;
}

/** Editable card for one exercise and its sets (used in the workout form). */
export function ExerciseEditor({ ex, index, count, errors, onChange, onRemove, onMove }: Props) {
  const u = useUnits();
  const setField = (id: string, patch: Partial<DraftExercise['sets'][number]>) => onChange({ ...ex, sets: ex.sets.map((s) => (s.id === id ? { ...s, ...patch } : s)) });

  return (
    <div className="ex-card">
      <div className="ex-card-head">
        <span className="set-num" aria-hidden>
          {index + 1}
        </span>
        <input
          className="input grow"
          style={{ height: 40, fontWeight: 650 }}
          value={ex.name}
          aria-label={`Exercise ${index + 1} name`}
          onChange={(e) => onChange({ ...ex, name: e.target.value })}
        />
        <IconButton icon="up" label="Move up" size="sm" disabled={index === 0} onClick={() => onMove(-1)} />
        <IconButton icon="down" label="Move down" size="sm" disabled={index === count - 1} onClick={() => onMove(1)} />
        <IconButton icon="trash" label={`Remove ${ex.name}`} size="sm" onClick={onRemove} />
      </div>
      {errors[ex.id] && <p className="field-msg">{errors[ex.id]}</p>}
      <div className="row-wrap small muted">
        {ex.muscle_group && <span>{ex.muscle_group}</span>}
        {ex.target_reps && <span>· target {ex.target_reps}</span>}
        <label className="row" style={{ gap: 6 }}>
          · rest
          <input
            className="input"
            style={{ width: 70, height: 32, fontSize: 14, textAlign: 'center' }}
            inputMode="numeric"
            value={ex.rest_seconds ?? ''}
            aria-label="Rest seconds"
            onChange={(e) => onChange({ ...ex, rest_seconds: e.target.value === '' ? null : Math.max(0, Math.min(3600, Number(e.target.value.replace(/\D/g, '')) || 0)) })}
          />
          s
        </label>
      </div>
      <div className="set-table" role="table" aria-label={`${ex.name} sets`}>
        <div className="set-row head" role="row">
          <span>Set</span>
          <span className="center">Reps</span>
          <span className="center">Weight ({u.w})</span>
          <span className="center">Done</span>
          <span />
        </div>
        {ex.sets.map((s, i) => (
          <div key={s.id}>
            <div className="set-row" role="row">
              <span className="set-num">{i + 1}</span>
              <input className="input" inputMode="numeric" value={s.reps} aria-label={`Set ${i + 1} reps`} onChange={(e) => setField(s.id, { reps: e.target.value })} placeholder="–" />
              <input className="input" inputMode="decimal" value={s.weight} aria-label={`Set ${i + 1} weight`} onChange={(e) => setField(s.id, { weight: e.target.value })} placeholder="–" />
              <button type="button" className={`check-btn ${s.completed ? 'on' : ''}`} aria-pressed={s.completed} aria-label={`Set ${i + 1} completed`} onClick={() => setField(s.id, { completed: !s.completed })}>
                <Icon name="check" size={18} strokeWidth={3} />
              </button>
              <IconButton icon="x" label={`Delete set ${i + 1}`} size="sm" onClick={() => onChange({ ...ex, sets: ex.sets.filter((x) => x.id !== s.id) })} />
            </div>
            {errors[s.id] && <p className="field-msg">{errors[s.id]}</p>}
          </div>
        ))}
      </div>
      <Button size="sm" icon="plus" onClick={() => onChange({ ...ex, sets: [...ex.sets, draftSetFrom(ex.sets[ex.sets.length - 1])] })}>
        Add set
      </Button>
    </div>
  );
}
