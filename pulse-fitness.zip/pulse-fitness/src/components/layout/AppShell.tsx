import { useEffect, useState, type ReactNode } from 'react';
import { Link, useRouter } from '../../router';
import { Icon, type IconName } from '../Icon';
import { useData } from '../../hooks/useData';
import { useOnline } from '../../hooks/useOnline';
import { useAuth } from '../../hooks/useAuth';
import { useConfirm } from '../ui/Confirm';
import { IconButton } from '../ui/Button';
import { GlobalSearch } from '../GlobalSearch';

export interface NavItem {
  to: string;
  label: string;
  icon: IconName;
}

export const MAIN_NAV: NavItem[] = [
  { to: '/', label: 'Dashboard', icon: 'home' },
  { to: '/workouts', label: 'Workouts', icon: 'dumbbell' },
  { to: '/calendar', label: 'Calendar', icon: 'calendar' },
  { to: '/run', label: 'Run', icon: 'run' },
  { to: '/exercises', label: 'Exercises', icon: 'book' },
  { to: '/programs', label: 'Programs', icon: 'layers' },
  { to: '/nutrition', label: 'Nutrition', icon: 'utensils' },
  { to: '/progress', label: 'Progress', icon: 'trend' },
];

export const MORE_NAV: NavItem[] = [
  { to: '/meals', label: 'Meal Planner', icon: 'list' },
  { to: '/water', label: 'Water', icon: 'droplet' },
  { to: '/habits', label: 'Habits', icon: 'checkSquare' },
  { to: '/stats', label: 'Statistics', icon: 'chart' },
  { to: '/records', label: 'Personal Records', icon: 'trophy' },
  { to: '/timers', label: 'Timers', icon: 'timer' },
  { to: '/settings', label: 'Settings', icon: 'settings' },
];

const BOTTOM: NavItem[] = [
  { to: '/', label: 'Home', icon: 'home' },
  { to: '/workouts', label: 'Workout', icon: 'dumbbell' },
  { to: '/calendar', label: 'Calendar', icon: 'calendar' },
  { to: '/run', label: 'Run', icon: 'run' },
  { to: '/more', label: 'More', icon: 'grid' },
];

function isActive(path: string, to: string) {
  if (to === '/') return path === '/';
  return path === to || path.startsWith(to + '/');
}

export function Brand() {
  return (
    <div className="brand">
      <span className="brand-mark">
        <Icon name="bolt" size={18} strokeWidth={2.5} />
      </span>
      Pulse
    </div>
  );
}

function SyncStatus() {
  const online = useOnline();
  const { pending, syncing, refresh } = useData();
  if (!online)
    return (
      <span className="status-pill offline" role="status">
        <Icon name="wifiOff" size={14} /> Offline{pending ? ` · ${pending} to sync` : ''}
      </span>
    );
  if (pending)
    return (
      <button className="status-pill pending" onClick={() => void refresh()}>
        <Icon name="cloud" size={14} /> {pending} to sync
      </button>
    );
  return (
    <button className="status-pill" onClick={() => void refresh()} aria-label="Sync now" title="Sync now">
      <Icon name="refresh" size={14} className={syncing ? 'spin' : ''} style={syncing ? { animation: 'spin 1s linear infinite' } : undefined} />
      {syncing ? 'Syncing' : 'Synced'}
    </button>
  );
}

export function useSignOut() {
  const { signOut } = useAuth();
  const { pending } = useData();
  const confirm = useConfirm();
  return async () => {
    const ok = await confirm({
      title: 'Log out?',
      message: pending
        ? `You have ${pending} change${pending === 1 ? '' : 's'} that haven't synced yet. Logging out now will discard them. Connect to the internet first to keep them.`
        : 'You can log back in any time — your data stays safely in your account.',
      confirmLabel: 'Log out',
      danger: pending > 0,
    });
    if (ok) await signOut();
  };
}

export function AppShell({ children }: { children: ReactNode }) {
  const { path } = useRouter();
  const online = useOnline();
  const { pending } = useData();
  const [searchOpen, setSearchOpen] = useState(false);
  const signOut = useSignOut();

  useEffect(() => {
    const open = () => setSearchOpen(true);
    document.addEventListener('pulse:search', open);
    return () => document.removeEventListener('pulse:search', open);
  }, []);

  return (
    <div className="app">
      <a href="#main" className="sr-only">
        Skip to content
      </a>
      <nav className="sidebar" aria-label="Main">
        <Brand />
        <button className="searchbox" style={{ marginBottom: 10, cursor: 'pointer' }} onClick={() => setSearchOpen(true)}>
          <Icon name="search" size={18} />
          <span className="muted" style={{ fontSize: 14 }}>
            Search…
          </span>
        </button>
        {MAIN_NAV.map((n) => (
          <Link key={n.to} to={n.to} className={`nav-link ${isActive(path, n.to) ? 'active' : ''}`} aria-current={isActive(path, n.to) ? 'page' : undefined}>
            <Icon name={n.icon} /> {n.label}
          </Link>
        ))}
        <div className="nav-group">More</div>
        {MORE_NAV.map((n) => (
          <Link key={n.to} to={n.to} className={`nav-link ${isActive(path, n.to) ? 'active' : ''}`} aria-current={isActive(path, n.to) ? 'page' : undefined}>
            <Icon name={n.icon} /> {n.label}
          </Link>
        ))}
        <div className="sidebar-foot">
          <SyncStatus />
          <button className="nav-link" style={{ border: 0, background: 'none', cursor: 'pointer', width: '100%' }} onClick={() => void signOut()}>
            <Icon name="logout" /> Log out
          </button>
        </div>
      </nav>

      <header className="topbar">
        <Link to="/" aria-label="Dashboard" style={{ flex: 1 }}>
          <Brand />
        </Link>
        <SyncStatus />
        <IconButton icon="search" label="Search" onClick={() => setSearchOpen(true)} />
      </header>

      <main id="main" className="main">
        <div className="container">
          {!online && (
            <div className="offline-banner" role="status">
              <Icon name="wifiOff" size={18} />
              <span>
                You're offline. New entries are kept on this device and marked “to sync” — they'll upload to your account automatically when you reconnect.
                {pending ? ` (${pending} waiting)` : ''}
              </span>
            </div>
          )}
          {children}
        </div>
      </main>

      <nav className="bottom-nav" aria-label="Primary">
        {BOTTOM.map((n) => {
          const active = n.to === '/more' ? path === '/more' || MORE_NAV.some((m) => isActive(path, m.to)) || ['/exercises', '/programs', '/nutrition', '/progress'].some((p) => isActive(path, p)) : isActive(path, n.to);
          return (
            <Link key={n.to} to={n.to} className={active ? 'active' : ''} aria-current={active ? 'page' : undefined}>
              <Icon name={n.icon} size={22} />
              {n.label}
            </Link>
          );
        })}
      </nav>

      <GlobalSearch open={searchOpen} onClose={() => setSearchOpen(false)} />
    </div>
  );
}
