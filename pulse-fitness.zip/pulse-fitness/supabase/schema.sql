-- =====================================================================
--  PULSE Fitness Tracker — Supabase schema
--  Run this whole file once in Supabase → SQL Editor → New query → Run.
--  Safe to re-run: every statement is idempotent.
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- Shared helpers
-- ---------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- ---------------------------------------------------------------------
-- PROFILES  (one row per user: profile, units, goals, targets, settings)
-- ---------------------------------------------------------------------
create table if not exists public.profiles (
  user_id               uuid primary key references auth.users(id) on delete cascade,
  name                  text,
  height_cm             numeric check (height_cm is null or (height_cm > 0 and height_cm < 300)),
  weight_kg             numeric check (weight_kg is null or (weight_kg > 0 and weight_kg < 500)),
  start_weight_kg       numeric check (start_weight_kg is null or (start_weight_kg > 0 and start_weight_kg < 500)),
  goal_weight_kg        numeric check (goal_weight_kg is null or (goal_weight_kg > 0 and goal_weight_kg < 500)),
  date_of_birth         date,
  sex                   text check (sex is null or sex in ('male','female','other')),
  weight_unit           text not null default 'kg' check (weight_unit in ('kg','lb')),
  distance_unit         text not null default 'km' check (distance_unit in ('km','mi')),
  length_unit           text not null default 'cm' check (length_unit in ('cm','in')),
  goals                 text[] not null default '{}',
  calorie_target        integer not null default 2000 check (calorie_target between 0 and 10000),
  protein_target        integer not null default 120 check (protein_target between 0 and 1000),
  carbs_target          integer not null default 225 check (carbs_target between 0 and 2000),
  fat_target            integer not null default 65 check (fat_target between 0 and 1000),
  fiber_target          integer not null default 25 check (fiber_target between 0 and 500),
  water_target_ml       integer not null default 2500 check (water_target_ml between 0 and 20000),
  weekly_workout_target integer not null default 4 check (weekly_workout_target between 0 and 21),
  weekly_run_km_target  numeric not null default 10 check (weekly_run_km_target >= 0),
  step_target           integer not null default 8000 check (step_target >= 0),
  default_rest_seconds  integer not null default 90 check (default_rest_seconds between 0 and 3600),
  theme                 text not null default 'system' check (theme in ('light','dark','system')),
  notifications_enabled boolean not null default true,
  sound_enabled         boolean not null default true,
  show_meals_in_calendar boolean not null default true,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);

-- Create a profile row automatically when an account is created
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (user_id, name)
  values (new.id, coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)))
  on conflict (user_id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------
-- WORKOUTS → WORKOUT_EXERCISES → WORKOUT_SETS
-- ---------------------------------------------------------------------
create table if not exists public.workouts (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null default auth.uid() references auth.users(id) on delete cascade,
  date           date not null,
  name           text not null check (length(trim(name)) > 0),
  workout_type   text not null default 'strength',
  status         text not null default 'planned' check (status in ('planned','in_progress','completed','skipped')),
  start_time     time,
  end_time       time,
  duration_min   numeric check (duration_min is null or duration_min >= 0),
  muscle_groups  text[] not null default '{}',
  distance_km    numeric check (distance_km is null or distance_km >= 0),
  calories       integer check (calories is null or calories >= 0),
  difficulty     integer check (difficulty is null or difficulty between 1 and 10),
  energy_level   integer check (energy_level is null or energy_level between 1 and 5),
  mood           text,
  notes          text,
  total_volume_kg numeric check (total_volume_kg is null or total_volume_kg >= 0),
  program_name   text,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index if not exists workouts_user_date_idx on public.workouts (user_id, date desc);

create table if not exists public.workout_exercises (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null default auth.uid() references auth.users(id) on delete cascade,
  workout_id    uuid not null references public.workouts(id) on delete cascade,
  position      integer not null default 0,
  exercise_key  text,
  name          text not null check (length(trim(name)) > 0),
  muscle_group  text,
  rest_seconds  integer check (rest_seconds is null or rest_seconds between 0 and 3600),
  target_sets   integer check (target_sets is null or target_sets between 0 and 100),
  target_reps   text,
  notes         text,
  skipped       boolean not null default false,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists workout_exercises_workout_idx on public.workout_exercises (workout_id, position);

create table if not exists public.workout_sets (
  id                  uuid primary key default gen_random_uuid(),
  user_id             uuid not null default auth.uid() references auth.users(id) on delete cascade,
  workout_id          uuid not null references public.workouts(id) on delete cascade,
  workout_exercise_id uuid not null references public.workout_exercises(id) on delete cascade,
  position            integer not null default 0,
  reps                integer check (reps is null or reps between 0 and 10000),
  weight_kg           numeric check (weight_kg is null or (weight_kg >= 0 and weight_kg < 2000)),
  duration_sec        integer check (duration_sec is null or duration_sec >= 0),
  distance_km         numeric check (distance_km is null or distance_km >= 0),
  completed           boolean not null default false,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);
create index if not exists workout_sets_exercise_idx on public.workout_sets (workout_exercise_id, position);

-- Atomically create or replace a workout together with its exercises and sets.
-- Runs as the caller, so Row Level Security still applies to every row.
create or replace function public.save_workout(p jsonb)
returns uuid language plpgsql security invoker set search_path = public as $$
declare
  w_id  uuid := coalesce((p->>'id')::uuid, gen_random_uuid());
  uid   uuid := auth.uid();
  ex    jsonb;
  st    jsonb;
  ex_id uuid;
  ex_pos integer := 0;
  st_pos integer;
begin
  if uid is null then
    raise exception 'Not authenticated' using errcode = '28000';
  end if;
  if exists (select 1 from public.workouts where id = w_id and user_id <> uid) then
    raise exception 'Not allowed' using errcode = '42501';
  end if;

  insert into public.workouts as w (
    id, user_id, date, name, workout_type, status, start_time, end_time, duration_min,
    muscle_groups, distance_km, calories, difficulty, energy_level, mood, notes,
    total_volume_kg, program_name
  ) values (
    w_id, uid, (p->>'date')::date, p->>'name', coalesce(p->>'workout_type','strength'),
    coalesce(p->>'status','planned'), nullif(p->>'start_time','')::time, nullif(p->>'end_time','')::time,
    nullif(p->>'duration_min','')::numeric,
    coalesce(array(select jsonb_array_elements_text(coalesce(p->'muscle_groups','[]'::jsonb))), '{}'),
    nullif(p->>'distance_km','')::numeric, nullif(p->>'calories','')::numeric::integer,
    nullif(p->>'difficulty','')::integer, nullif(p->>'energy_level','')::integer,
    nullif(p->>'mood',''), nullif(p->>'notes',''),
    nullif(p->>'total_volume_kg','')::numeric, nullif(p->>'program_name','')
  )
  on conflict (id) do update set
    date = excluded.date, name = excluded.name, workout_type = excluded.workout_type,
    status = excluded.status, start_time = excluded.start_time, end_time = excluded.end_time,
    duration_min = excluded.duration_min, muscle_groups = excluded.muscle_groups,
    distance_km = excluded.distance_km, calories = excluded.calories,
    difficulty = excluded.difficulty, energy_level = excluded.energy_level,
    mood = excluded.mood, notes = excluded.notes, total_volume_kg = excluded.total_volume_kg,
    program_name = excluded.program_name
  where w.user_id = uid;

  if not found then
    raise exception 'Not allowed' using errcode = '42501';
  end if;

  -- replace children (sets cascade from exercises)
  delete from public.workout_exercises where workout_id = w_id and user_id = uid;

  for ex in select * from jsonb_array_elements(coalesce(p->'exercises','[]'::jsonb)) loop
    ex_id := coalesce((ex->>'id')::uuid, gen_random_uuid());
    insert into public.workout_exercises (
      id, user_id, workout_id, position, exercise_key, name, muscle_group, rest_seconds,
      target_sets, target_reps, notes, skipped
    ) values (
      ex_id, uid, w_id, ex_pos, nullif(ex->>'exercise_key',''), ex->>'name', nullif(ex->>'muscle_group',''),
      nullif(ex->>'rest_seconds','')::integer, nullif(ex->>'target_sets','')::integer,
      nullif(ex->>'target_reps',''), nullif(ex->>'notes',''), coalesce((ex->>'skipped')::boolean, false)
    );
    ex_pos := ex_pos + 1;
    st_pos := 0;
    for st in select * from jsonb_array_elements(coalesce(ex->'sets','[]'::jsonb)) loop
      insert into public.workout_sets (
        id, user_id, workout_id, workout_exercise_id, position, reps, weight_kg,
        duration_sec, distance_km, completed
      ) values (
        coalesce((st->>'id')::uuid, gen_random_uuid()), uid, w_id, ex_id, st_pos,
        nullif(st->>'reps','')::integer, nullif(st->>'weight_kg','')::numeric,
        nullif(st->>'duration_sec','')::integer, nullif(st->>'distance_km','')::numeric,
        coalesce((st->>'completed')::boolean, false)
      );
      st_pos := st_pos + 1;
    end loop;
  end loop;

  return w_id;
end $$;

-- ---------------------------------------------------------------------
-- EXERCISES (built-in library ships with the app; these are yours)
-- ---------------------------------------------------------------------
create table if not exists public.custom_exercises (
  id                uuid primary key default gen_random_uuid(),
  user_id           uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name              text not null check (length(trim(name)) > 0),
  muscle_group      text not null,
  secondary_muscles text[] not null default '{}',
  equipment         text not null default 'Bodyweight',
  difficulty        text not null default 'Beginner',
  instructions      text,
  sets              integer check (sets is null or sets between 0 and 100),
  reps              text,
  rest_seconds      integer check (rest_seconds is null or rest_seconds between 0 and 3600),
  mistakes          text,
  tips              text,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create table if not exists public.favorite_exercises (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null default auth.uid() references auth.users(id) on delete cascade,
  exercise_key text not null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  unique (user_id, exercise_key)
);

-- ---------------------------------------------------------------------
-- PROGRAMS (custom; each day = { name, focus, exercises[] })
-- ---------------------------------------------------------------------
create table if not exists public.workout_programs (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name          text not null check (length(trim(name)) > 0),
  description   text,
  goal          text,
  level         text,
  days_per_week integer check (days_per_week is null or days_per_week between 1 and 7),
  days          jsonb not null default '[]'::jsonb,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- CALENDAR (rest days, notes, planned runs, other activities)
-- Workouts, runs, weigh-ins and meal plans also appear from their own tables.
-- ---------------------------------------------------------------------
create table if not exists public.calendar_events (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  date        date not null,
  title       text not null check (length(trim(title)) > 0),
  event_type  text not null default 'note' check (event_type in ('rest','note','run','activity','other')),
  start_time  time,
  notes       text,
  completed   boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists calendar_events_user_date_idx on public.calendar_events (user_id, date);

-- ---------------------------------------------------------------------
-- RUNNING
-- ---------------------------------------------------------------------
create table if not exists public.running_sessions (
  id                  uuid primary key default gen_random_uuid(),
  user_id             uuid not null default auth.uid() references auth.users(id) on delete cascade,
  date                date not null,
  activity_type       text not null default 'run' check (activity_type in ('run','jog','walk','trail','treadmill')),
  status              text not null default 'completed' check (status in ('planned','completed','skipped')),
  start_time          time,
  end_time            time,
  distance_km         numeric check (distance_km is null or (distance_km >= 0 and distance_km < 1000)),
  duration_sec        integer check (duration_sec is null or duration_sec >= 0),
  avg_pace_sec_per_km numeric check (avg_pace_sec_per_km is null or avg_pace_sec_per_km >= 0),
  calories            integer check (calories is null or calories >= 0),
  route_name          text,
  notes               text,
  gps_used            boolean not null default false,
  route               jsonb,
  splits              jsonb,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);
create index if not exists running_user_date_idx on public.running_sessions (user_id, date desc);

-- ---------------------------------------------------------------------
-- BODY PROGRESS
-- ---------------------------------------------------------------------
create table if not exists public.body_measurements (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null default auth.uid() references auth.users(id) on delete cascade,
  date         date not null,
  weight_kg    numeric check (weight_kg is null or (weight_kg > 0 and weight_kg < 500)),
  body_fat_pct numeric check (body_fat_pct is null or (body_fat_pct >= 0 and body_fat_pct <= 100)),
  waist_cm     numeric check (waist_cm  is null or waist_cm  > 0),
  chest_cm     numeric check (chest_cm  is null or chest_cm  > 0),
  arms_cm      numeric check (arms_cm   is null or arms_cm   > 0),
  thighs_cm    numeric check (thighs_cm is null or thighs_cm > 0),
  hips_cm      numeric check (hips_cm   is null or hips_cm   > 0),
  neck_cm      numeric check (neck_cm   is null or neck_cm   > 0),
  notes        text,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists body_user_date_idx on public.body_measurements (user_id, date);

create table if not exists public.progress_photos (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null default auth.uid() references auth.users(id) on delete cascade,
  date          date not null,
  storage_path  text not null,
  caption       text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table if not exists public.daily_metrics (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null default auth.uid() references auth.users(id) on delete cascade,
  date         date not null,
  steps        integer check (steps is null or (steps >= 0 and steps < 200000)),
  sleep_hours  numeric check (sleep_hours is null or (sleep_hours >= 0 and sleep_hours <= 24)),
  notes        text,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  unique (user_id, date)
);

-- ---------------------------------------------------------------------
-- NUTRITION
-- ---------------------------------------------------------------------
create table if not exists public.nutrition_entries (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null default auth.uid() references auth.users(id) on delete cascade,
  date         date not null,
  meal_type    text not null check (meal_type in ('breakfast','morning_snack','lunch','afternoon_snack','dinner','evening_snack')),
  food_name    text not null check (length(trim(food_name)) > 0),
  serving_size text,
  calories     numeric check (calories  is null or calories  >= 0),
  protein_g    numeric check (protein_g is null or protein_g >= 0),
  carbs_g      numeric check (carbs_g   is null or carbs_g   >= 0),
  fat_g        numeric check (fat_g     is null or fat_g     >= 0),
  fiber_g      numeric check (fiber_g   is null or fiber_g   >= 0),
  sugar_g      numeric check (sugar_g   is null or sugar_g   >= 0),
  notes        text,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists nutrition_user_date_idx on public.nutrition_entries (user_id, date);

create table if not exists public.foods (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name         text not null check (length(trim(name)) > 0),
  serving_size text,
  calories     numeric check (calories  is null or calories  >= 0),
  protein_g    numeric check (protein_g is null or protein_g >= 0),
  carbs_g      numeric check (carbs_g   is null or carbs_g   >= 0),
  fat_g        numeric check (fat_g     is null or fat_g     >= 0),
  fiber_g      numeric check (fiber_g   is null or fiber_g   >= 0),
  sugar_g      numeric check (sugar_g   is null or sugar_g   >= 0),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create table if not exists public.meal_plans (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  date        date not null,
  meal_type   text not null check (meal_type in ('breakfast','lunch','dinner','snack')),
  title       text not null check (length(trim(title)) > 0),
  description text,
  calories    numeric check (calories  is null or calories  >= 0),
  protein_g   numeric check (protein_g is null or protein_g >= 0),
  carbs_g     numeric check (carbs_g   is null or carbs_g   >= 0),
  fat_g       numeric check (fat_g     is null or fat_g     >= 0),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists meal_plans_user_date_idx on public.meal_plans (user_id, date);

create table if not exists public.meal_templates (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  meal_type   text not null check (meal_type in ('breakfast','lunch','dinner','snack')),
  title       text not null check (length(trim(title)) > 0),
  description text,
  calories    numeric check (calories  is null or calories  >= 0),
  protein_g   numeric check (protein_g is null or protein_g >= 0),
  carbs_g     numeric check (carbs_g   is null or carbs_g   >= 0),
  fat_g       numeric check (fat_g     is null or fat_g     >= 0),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- WATER
-- ---------------------------------------------------------------------
create table if not exists public.water_entries (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  date        date not null,
  amount_ml   integer not null check (amount_ml > 0 and amount_ml <= 5000),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists water_user_date_idx on public.water_entries (user_id, date);

-- ---------------------------------------------------------------------
-- HABITS
-- ---------------------------------------------------------------------
create table if not exists public.habits (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name        text not null check (length(trim(name)) > 0),
  icon        text not null default 'check',
  position    integer not null default 0,
  active      boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists public.habit_logs (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  habit_id    uuid not null references public.habits(id) on delete cascade,
  date        date not null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (habit_id, date)
);

-- ---------------------------------------------------------------------
-- PERSONAL RECORDS (manual; automatic PRs are computed from history)
-- ---------------------------------------------------------------------
create table if not exists public.personal_records (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null default auth.uid() references auth.users(id) on delete cascade,
  title         text not null check (length(trim(title)) > 0),
  category      text not null default 'strength',
  value         numeric not null,
  unit          text,
  date          date not null,
  exercise_name text,
  notes         text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- updated_at triggers + Row Level Security for every table
-- ---------------------------------------------------------------------
do $$
declare t text;
begin
  foreach t in array array[
    'profiles','workouts','workout_exercises','workout_sets','custom_exercises','favorite_exercises',
    'workout_programs','calendar_events','running_sessions','body_measurements','progress_photos',
    'daily_metrics','nutrition_entries','foods','meal_plans','meal_templates','water_entries',
    'habits','habit_logs','personal_records'
  ] loop
    execute format('drop trigger if exists set_updated_at on public.%I', t);
    execute format('create trigger set_updated_at before update on public.%I for each row execute function public.set_updated_at()', t);
    execute format('alter table public.%I enable row level security', t);
    execute format('alter table public.%I force row level security', t);
    execute format('drop policy if exists "own rows" on public.%I', t);
    execute format(
      'create policy "own rows" on public.%I for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid())', t);
    execute format('revoke all on public.%I from anon', t);
    execute format('grant select, insert, update, delete on public.%I to authenticated', t);
  end loop;
end $$;

-- Child rows may only point at parents you own
drop policy if exists "own parent" on public.workout_exercises;
create policy "own parent" on public.workout_exercises as restrictive for all to authenticated
  with check (exists (select 1 from public.workouts w where w.id = workout_id and w.user_id = auth.uid()));

drop policy if exists "own parent" on public.workout_sets;
create policy "own parent" on public.workout_sets as restrictive for all to authenticated
  with check (exists (select 1 from public.workout_exercises e where e.id = workout_exercise_id and e.user_id = auth.uid()));

drop policy if exists "own parent" on public.habit_logs;
create policy "own parent" on public.habit_logs as restrictive for all to authenticated
  with check (exists (select 1 from public.habits h where h.id = habit_id and h.user_id = auth.uid()));

revoke all on function public.save_workout(jsonb) from public, anon;
grant execute on function public.save_workout(jsonb) to authenticated;

-- ---------------------------------------------------------------------
-- STORAGE: private bucket for progress photos (folder = your user id)
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('progress-photos', 'progress-photos', false)
on conflict (id) do nothing;

drop policy if exists "progress photos: own folder read"   on storage.objects;
drop policy if exists "progress photos: own folder insert" on storage.objects;
drop policy if exists "progress photos: own folder delete" on storage.objects;

create policy "progress photos: own folder read" on storage.objects for select to authenticated
  using (bucket_id = 'progress-photos' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "progress photos: own folder insert" on storage.objects for insert to authenticated
  with check (bucket_id = 'progress-photos' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "progress photos: own folder delete" on storage.objects for delete to authenticated
  using (bucket_id = 'progress-photos' and (storage.foldername(name))[1] = auth.uid()::text);
